<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB error");
}

$data = json_decode(file_get_contents("php://input"), true);

$topic = $data['topic'];
$course_id = $data['course_id'];
$email = $_SESSION['user_email'];

// GET USER ID
$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$res = $getUser->get_result();
$user = $res->fetch_assoc();

if(!$user){
    echo json_encode(["status"=>"error"]);
    exit();
}

$user_id = $user['id'];

// CHECK DUPLICATE (IMPORTANT)
$check = $conn->prepare("
SELECT * FROM topic_progress 
WHERE user_id=? AND course_id=? AND topic_name=?
");
$check->bind_param("iis", $user_id, $course_id, $topic);
$check->execute();
$resCheck = $check->get_result();

if($resCheck->num_rows == 0){

    // INSERT TOPIC
    $stmt = $conn->prepare("
    INSERT INTO topic_progress (user_id, course_id, topic_name)
    VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iis", $user_id, $course_id, $topic);
    $stmt->execute();
}

// COUNT COMPLETED TOPICS
$countStmt = $conn->prepare("
SELECT COUNT(*) as total 
FROM topic_progress 
WHERE user_id=? AND course_id=?
");
$countStmt->bind_param("ii", $user_id, $course_id);
$countStmt->execute();
$resCount = $countStmt->get_result();
$dataCount = $resCount->fetch_assoc();

$completed = (int)$dataCount['total'];

// GET TOTAL TOPICS
$getTotal = $conn->prepare("
SELECT total_topics FROM course_progress 
WHERE user_id=? AND course_id=?
");
$getTotal->bind_param("ii", $user_id, $course_id);
$getTotal->execute();
$resTotal = $getTotal->get_result();
$totalData = $resTotal->fetch_assoc();

$total = (int)$totalData['total_topics'];

// CALCULATE PERCENTAGE
$percent = ($total > 0) ? round(($completed / $total) * 100) : 0;

// UPDATE COURSE PROGRESS
$update = $conn->prepare("
UPDATE course_progress 
SET completed_topics=?, progress_percent=? 
WHERE user_id=? AND course_id=?
");
$update->bind_param("iiii", $completed, $percent, $user_id, $course_id);
$update->execute();

echo json_encode([
    "status"=>"success",
    "completed"=>$completed,
    "percent"=>$percent
]);
?>