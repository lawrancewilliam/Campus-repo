<?php
session_start();
include 'db.php';

// GET FORM DATA
$id = $_POST['id'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$bio = $_POST['bio'];
$username = $_POST['username'];
$dob = $_POST['dob'];
$address = $_POST['address'];
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$old_password = $_POST['old_password'] ?? '';

// GET OLD IMAGE
$sql2 = "SELECT profile_pic FROM users WHERE id=?";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("i", $id);
$stmt2->execute();
$res2 = $stmt2->get_result();
$row2 = $res2->fetch_assoc();

$profile_pic_name = $row2['profile_pic'];

// IMAGE UPLOAD
if(isset($_FILES['profile_pic']) && $_FILES['profile_pic']['name'] != ""){

    $file_name = $_FILES['profile_pic']['name'];
    $tmp_name = $_FILES['profile_pic']['tmp_name'];

    $allowed = ['jpg','jpeg','png'];
    $ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if(!in_array($ext, $allowed)){
        die("Invalid file type");
    }

    $unique_name = time() . "_" . $file_name;
    move_uploaded_file($tmp_name, "uploads/" . $unique_name);

    // delete old image
    if($profile_pic_name && file_exists("uploads/" . $profile_pic_name)){
        unlink("uploads/" . $profile_pic_name);
    }

    $profile_pic_name = $unique_name;
}

// 🔥 CHECK DUPLICATE USERNAME / EMAIL / PHONE

$check = $conn->prepare("
SELECT id FROM users 
WHERE (username=? OR email=? OR phone=?) AND id != ?
");

$check->bind_param("sssi", $username, $email, $phone, $id);
$check->execute();
$resCheck = $check->get_result();

if($resCheck->num_rows > 0){
header("Location: dashboard.php?status=duplicate");
exit();
}

// PASSWORD LOGIC
if(!empty($password)){

    // 🔥 OLD PASSWORD CHECK
    $checkPass = $conn->prepare("SELECT password FROM users WHERE id=?");
    $checkPass->bind_param("i", $id);
    $checkPass->execute();
    $resPass = $checkPass->get_result();
    $rowPass = $resPass->fetch_assoc();

    $dbPassword = $rowPass['password'];

    // verify old password
    if(!password_verify($old_password, $dbPassword)){
        die("Old password is incorrect");
    }

    // new password match check
    if($password !== $confirm_password){
        die("New passwords do not match");
    }

    // hash new password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $sql = "UPDATE users 
    SET fname=?, lname=?, email=?, phone=?, bio=?, username=?, dob=?, address=?, password=?, profile_pic=? 
    WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssssi",
        $fname, $lname, $email, $phone, $bio,
        $username, $dob, $address, $hashedPassword, $profile_pic_name, $id
    );

} else {

    $sql = "UPDATE users 
    SET fname=?, lname=?, email=?, phone=?, bio=?, username=?, dob=?, address=?, profile_pic=? 
    WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssi",
        $fname, $lname, $email, $phone, $bio,
        $username, $dob, $address, $profile_pic_name, $id
    );
}

// EXECUTE
if($stmt->execute()){
    $_SESSION['user_email'] = $email;
    header("Location: dashboard.php?status=success");
    exit();
} else {
        header("Location: dashboard.php?status=error");
        exit();
}
?>