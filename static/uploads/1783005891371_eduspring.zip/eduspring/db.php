<?php
$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB Connection Failed: " . $conn->connect_error);
}
?>