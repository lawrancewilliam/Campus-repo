<?php
session_start();

// 🔥 PREVENT BROWSER CACHING SO BACK BUTTON RELOADS DB STATE
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// ✅ Check login (ONLY user_id use pannuvom)
if(!isset($_SESSION['user_id'])){
    header("Location: /eduspring/signin.php?error=login_required");
    exit();
}

// ✅ DB Connection
include("db.php");

if ($conn->connect_error) {
    die("DB connection failed");
}

// ✅ Get user_id directly from session
 $user_id = $_SESSION['user_id'];

// ✅ (Optional) Verify user exists in DB
 $stmt = $conn->prepare("SELECT id FROM users WHERE id=?");
 $stmt->bind_param("i", $user_id);
 $stmt->execute();
 $res = $stmt->get_result();
 $userData = $res->fetch_assoc();

if(!$userData){
    session_destroy();
    header("Location: /eduspring/signin.php?error=invalid_session");
    exit();
}

// ✅ Check python course enrollment
 $checkPython = $conn->prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? LIMIT 1");
 $course_id = 1; // Python
 $checkPython->bind_param("ii", $user_id, $course_id);
 $checkPython->execute();
 $resultPython = $checkPython->get_result();
 $isEnrolledPython = ($resultPython->num_rows > 0);

// ✅ Check Java enrollment
 $checkJava = $conn->prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? LIMIT 1");
 $course_id = 2; // Java
 $checkJava->bind_param("ii", $user_id, $course_id);
 $checkJava->execute();
 $resultJava = $checkJava->get_result();
 $isEnrolledJava = ($resultJava->num_rows > 0);

// ✅ Check Fullstack enrollment
 $checkFS = $conn->prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? LIMIT 1");
 $course_id = 3; // Fullstack
 $checkFS->bind_param("ii", $user_id, $course_id);
 $checkFS->execute();
 $resultFS = $checkFS->get_result();
 $isEnrolledFS = ($resultFS->num_rows > 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learnify - Course Catalog</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        html { scroll-behavior: smooth; }
        body { font-family: 'Inter', sans-serif; }
        
        .text-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .bg-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }
        
        .btn-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            transition: all 0.3s ease;
            cursor: pointer; /* ✅ Added cursor pointer */
        }
        
        .btn-vibrant:hover {
            background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%);
            box-shadow: 0 4px 14px 0 rgba(139, 92, 246, 0.39);
            transform: translateY(-1px);
        }
        
        .glass-tag {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .bg-java { background: linear-gradient(135deg, #f59e0b, #ea580c); }
        .bg-aws { background: linear-gradient(135deg, #f97316, #ea580c); }
        .bg-python { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .bg-react { background: linear-gradient(135deg, #06b6d4, #0369a1); }
        .bg-security { background: linear-gradient(135deg, #ef4444, #b91c1c); }
        .bg-database { background: linear-gradient(135deg, #6366f1, #4338ca); }
        
        @keyframes fadeUp {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-up { animation: fadeUp 0.8s cubic-bezier(0.22, 1, 0.36, 1) forwards; }
        
        .reveal-on-scroll {
            opacity: 0;
            transform: translateY(40px);
            transition: opacity 0.8s cubic-bezier(0.22, 1, 0.36, 1), transform 0.8s cubic-bezier(0.22, 1, 0.36, 1);
        }
        .reveal-on-scroll.is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        /* HERO GRADIENT ANIMATION */
        .hero-animated {
            background: linear-gradient(-45deg, #0f172a, #134e5e, #22c1c3, #0f172a);
            background-size: 400% 400%;
            animation: gradientMove 10s ease infinite;
        }
        @keyframes gradientMove {
            0% {background-position:0% 50%;}
            50% {background-position:100% 50%;}
            100% {background-position:0% 50%;}
        }

        /* HEADING GLOW */
        .glow-text {
            text-shadow: 0 0 10px rgba(59,130,246,0.8), 0 0 20px rgba(139,92,246,0.6);
            animation: glowPulse 2s infinite alternate;
        }
        @keyframes glowPulse {
            from { text-shadow: 0 0 5px #3b82f6; }
            to { text-shadow: 0 0 25px #8b5cf6; }
        }

        /* TYPING EFFECT */
        .typing {
            display: inline-block;
            overflow: hidden;
            white-space: nowrap;
            width: 0;
            margin: 0 auto;
            border-right: 3px solid white;
            animation: typing 3s steps(20,end) forwards, blink 0.7s step-end 4;
        }
        @keyframes typing { from { width: 0ch; } to { width: 20ch; } }
        @keyframes blink { 50% { border-color: transparent; } }
        .typing.done { border-right: none; }

        /* BUTTON SHINE */
        .btn-shine {
            position: relative;
            overflow: hidden;
        }
        .btn-shine::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 50%;
            height: 100%;
            background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
            transform: skewX(-20deg);
        }
        .btn-shine:hover::before { animation: shine 0.8s forwards; }
        @keyframes shine { 100% { left: 120%; } }

        /* RIPPLE EFFECT */
        .ripple {
            position: absolute;
            border-radius: 50%;
            transform: scale(0);
            animation: rippleAnim 0.6s linear;
            background: rgba(255,255,255,0.6);
            pointer-events: none; /* ✅ Important so ripple doesn't block click */
        }
        @keyframes rippleAnim {
            to { transform: scale(4); opacity: 0; }
        }

        /* CARD INTERACTION */
        .course-card { transition: all 0.3s ease; }
        .course-card:hover { transform: translateY(-10px) scale(1.03); box-shadow: 0 20px 40px rgba(59,130,246,0.2); }

        /* SEARCH BAR EFFECT */
        .search-glow:focus { box-shadow: 0 0 15px rgba(59,130,246,0.5); transform: scale(1.02); }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

<?php include 'navbar.php'; ?>

    <section class="relative hero-animated py-24 overflow-hidden">
        <!-- Decorative background blobs -->
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        
        <div class="container mx-auto px-4 relative z-10 text-center pb-12">
            <h1 class="text-4xl md:text-6xl font-extrabold text-white mb-6 tracking-tight mt-8 glow-text typing">
                Explore Our Courses
            </h1>
            <p class="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
                Enhance your skills with structured learning paths, quizzes, and automated certifications designed for modern educational needs.
            </p>
        </div>
    </section>

    <!-- The Learnify Advantage Section -->
    <section class="relative z-20 -mt-20 mb-16 container mx-auto px-4">
        <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-8 md:p-12 max-w-6xl mx-auto">
            <div class="text-center mb-10 reveal-on-scroll">
                <h2 class="text-3xl font-extrabold text-gray-900 mb-4">The <span class="text-vibrant">Learnify</span> Advantage</h2>
                <p class="text-gray-500 max-w-3xl mx-auto text-base leading-relaxed">A state-of-the-art, cloud-enabled web application developed to deliver structured online learning, assessment, and automated certification in a secure and scalable environment.</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <!-- Feature 1 -->
                <div class="group reveal-on-scroll" style="transition-delay: 0.1s;">
                    <div class="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform duration-300">
                        <i class="fab fa-aws"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Cloud-Native Scale</h3>
                    <p class="text-gray-500 text-sm leading-relaxed">Powered by Amazon EC2 and S3 for high availability and reliable delivery of course materials globally.</p>
                </div>
                
                <!-- Feature 2 -->
                <div class="group reveal-on-scroll" style="transition-delay: 0.2s;">
                    <div class="w-14 h-14 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-certificate"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Auto-Certification</h3>
                    <p class="text-gray-500 text-sm leading-relaxed">Complete assessments and instantly obtain verifiable digital certificates securely stored on the cloud.</p>
                </div>
                
                <!-- Feature 3 -->
                <div class="group reveal-on-scroll" style="transition-delay: 0.3s;">
                    <div class="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-database"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Secure Data</h3>
                    <p class="text-gray-500 text-sm leading-relaxed">Robust relational database management using Amazon RDS and strict AWS IAM access controls.</p>
                </div>
                
                <!-- Feature 4 -->
                <div class="group reveal-on-scroll" style="transition-delay: 0.4s;">
                    <div class="w-14 h-14 bg-cyan-50 text-cyan-600 rounded-2xl flex items-center justify-center text-2xl mb-5 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Structured Paths</h3>
                    <p class="text-gray-500 text-sm leading-relaxed">Curated learning materials, interactive quizzes, and logical progression designed for modern education.</p>
                </div>
            </div>
            
            <div class="mt-10 pt-8 border-t border-gray-100 flex flex-wrap justify-center gap-3 text-sm font-semibold text-gray-600 reveal-on-scroll" style="transition-delay: 0.5s;">
                <div class="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full border border-gray-100 transition hover:bg-blue-50 hover:text-blue-600 cursor-default"><i class="fas fa-check-circle text-blue-500"></i> Seamless Video Playback</div>
                <div class="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full border border-gray-100 transition hover:bg-blue-50 hover:text-blue-600 cursor-default"><i class="fas fa-check-circle text-blue-500"></i> Real-time Assessments</div>
                <div class="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full border border-gray-100 transition hover:bg-blue-50 hover:text-blue-600 cursor-default"><i class="fas fa-check-circle text-blue-500"></i> Cost-Effective Access</div>
                <div class="flex items-center gap-2 px-4 py-2 bg-gray-50 rounded-full border border-gray-100 transition hover:bg-blue-50 hover:text-blue-600 cursor-default"><i class="fas fa-check-circle text-blue-500"></i> Cross-device Support</div>
            </div>
        </div>
    </section>

    <!-- Guided Career Paths (What to Learn) -->
    <section class="py-24 bg-gray-50 border-t border-gray-100">
        <div class="container mx-auto px-4 max-w-6xl">
            <div class="text-center mb-16 reveal-on-scroll">
                <span class="text-blue-600 font-bold tracking-wider uppercase text-sm mb-2 block">Career Tracks</span>
                <h2 class="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4">Not Sure <span class="text-vibrant">What to Learn?</span></h2>
                <p class="text-gray-500 max-w-2xl mx-auto text-lg leading-relaxed">Follow our structured, industry-aligned career paths designed to take you from beginner to job-ready professional without the guesswork.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <!-- Path 1: Python -->
                <div class="bg-white rounded-2xl p-8 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 reveal-on-scroll" style="transition-delay: 0.1s;">
                    <div class="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center text-2xl mb-6">
                        <i class="fab fa-python"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Python Programming</h3>
                    <p class="text-gray-500 text-sm mb-8 leading-relaxed">Build scalable backend systems, automate tasks, and analyze data. Master Python, Django, Flask, and APIs.</p>
                    <div class="space-y-4 mb-8 border-t border-gray-50 pt-6">
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-layer-group text-emerald-500 mr-3 text-lg w-5 text-center"></i> 6 Structured Courses</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-clock text-emerald-500 mr-3 text-lg w-5 text-center"></i> 110 Hours of Content</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-server text-emerald-500 mr-3 text-lg w-5 text-center"></i> Real-world APIs</div>
                    </div><br>
                    <!-- ✅ Added type="button" and checked logic -->
                    <?php if($isEnrolledPython): ?>
                    <button type="button" onclick="handlePythonClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-green-100 text-green-600 font-bold rounded-xl hover:bg-emerald-600 hover:text-white transition cursor-pointer">
                        Continue Learning &rarr;
                    </button>
                    <?php else: ?>
                    <button type="button" onclick="handlePythonClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-emerald-50 text-emerald-600 font-bold rounded-xl hover:bg-emerald-600 hover:text-white transition cursor-pointer">
                        Explore Path &rarr;
                    </button>
                    <?php endif; ?>
                </div>
                
                <!-- Path 2: Java -->
                <div class="bg-white rounded-2xl p-8 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border-2 border-orange-100 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden transform md:-translate-y-4 reveal-on-scroll" style="transition-delay: 0.2s;">
                    <div class="absolute top-0 right-0 bg-java text-white text-xs font-bold px-4 py-1.5 rounded-bl-xl shadow-md">MOST POPULAR</div>
                    <div class="w-14 h-14 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center text-2xl mb-6">
                        <i class="fab fa-java"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Java Programming</h3>
                    <p class="text-gray-500 text-sm mb-8 leading-relaxed">Master enterprise application development. Dive deep into Core Java, Spring Boot, microservices, and database integration.</p>
                    <div class="space-y-4 mb-8 border-t border-gray-50 pt-6">
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-layer-group text-orange-500 mr-3 text-lg w-5 text-center"></i> 5 Structured Courses</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-clock text-orange-500 mr-3 text-lg w-5 text-center"></i> 95 Hours of Content</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-certificate text-orange-500 mr-3 text-lg w-5 text-center"></i> Java Certification Prep</div>
                    </div>
                    <!-- ✅ Added type="button" -->
                    <?php if($isEnrolledJava): ?>
                    <button type="button" onclick="handleJavaClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-green-100 text-green-600 font-bold rounded-xl hover:bg-emerald-600 hover:text-white transition cursor-pointer">
                        Continue Learning &rarr;
                    </button>
                    <?php else: ?>
                    <button type="button" onclick="handleJavaClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-java text-white font-bold rounded-xl hover:bg-emerald-600 hover:text-white transition cursor-pointer">
                        Explore Path &rarr;
                    </button>
                    <?php endif; ?>
                </div>
                
                <!-- Path 3: Fullstack -->
                <div class="bg-white rounded-2xl p-8 shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 reveal-on-scroll" style="transition-delay: 0.3s;">
                    <div class="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl mb-6">
                        <i class="fas fa-code"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Full-Stack Development</h3>
                    <p class="text-gray-500 text-sm mb-8 leading-relaxed">Master frontend interfaces and backend APIs. Learn React, Node.js, and modern database management systems.</p>
                    <div class="space-y-4 mb-8 border-t border-gray-50 pt-6">
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-layer-group text-blue-500 mr-3 text-lg w-5 text-center"></i> 6 Structured Courses</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-clock text-blue-500 mr-3 text-lg w-5 text-center"></i> 120 Hours of Content</div>
                        <div class="flex items-center text-sm font-medium text-gray-700"><i class="fas fa-project-diagram text-blue-500 mr-3 text-lg w-5 text-center"></i> 4 Capstone Projects</div>
                    </div>
                    <!-- ✅ Added type="button" -->
                    <?php if($isEnrolledFS): ?>
                    <button type="button" onclick="handleFSClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-green-100 text-green-600 font-bold rounded-xl hover:bg-emerald-600 hover:text-white transition cursor-pointer">
                        Continue Learning &rarr;
                    </button>
                    <?php else: ?>
                    <button type="button" onclick="handleFSClick()" class="inline-flex items-center justify-center w-full py-3 px-4 bg-blue-50 text-blue-600 font-bold rounded-xl hover:bg-blue-600 hover:text-white transition cursor-pointer">
                        Explore Path &rarr;
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Flexible Learning (Where to Learn) -->
    <section class="py-24 bg-white relative overflow-hidden">
        <!-- Decorative background element -->
        <div class="absolute -right-64 -top-64 w-96 h-96 bg-blue-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70"></div>
        <div class="absolute -left-64 -bottom-64 w-96 h-96 bg-purple-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70"></div>
        
        <div class="container mx-auto px-4 max-w-6xl relative z-10">
            <div class="flex flex-col lg:flex-row items-center gap-16">
                <div class="flex-1 space-y-8 reveal-on-scroll">
                    <div>
                        <span class="text-blue-600 font-bold tracking-wider uppercase text-sm mb-2 block">Learning Modalities</span>
                        <h2 class="text-3xl md:text-5xl font-extrabold text-gray-900 leading-tight mb-6">Learn <span class="text-vibrant">Anywhere, Anytime</span> on Any Device</h2>
                        <p class="text-gray-500 text-lg leading-relaxed">
                            Your education shouldn't be tied to a desk. Whether you're commuting on a train, relaxing at a cafe, or focused in your home office, Learnify's cloud-powered architecture automatically adapts to your lifestyle.
                        </p>
                    </div>
                    
                    <ul class="space-y-6">
                        <li class="flex items-start bg-gray-50 p-4 rounded-2xl border border-gray-100">
                            <div class="flex-shrink-0 w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mr-4 shadow-sm">
                                <i class="fas fa-mobile-alt text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 text-lg mb-1">Mobile-Optimized Experience</h4>
                                <p class="text-sm text-gray-500 leading-relaxed">Watch high-definition video lectures and read rich-text materials perfectly scaled for your smartphone or tablet screen.</p>
                            </div>
                        </li>
                        <li class="flex items-start bg-gray-50 p-4 rounded-2xl border border-gray-100">
                            <div class="flex-shrink-0 w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mr-4 shadow-sm">
                                <i class="fas fa-laptop text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 text-lg mb-1">Interactive Desktop Workspaces</h4>
                                <p class="text-sm text-gray-500 leading-relaxed">Tackle complex coding exercises, utilize split-screen project modes, and access automated cloud-testing environments on your PC.</p>
                            </div>
                        </li>
                        <li class="flex items-start bg-gray-50 p-4 rounded-2xl border border-gray-100">
                            <div class="flex-shrink-0 w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mr-4 shadow-sm">
                                <i class="fas fa-wifi text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-900 text-lg mb-1">Cloud-Synced Progress</h4>
                                <p class="text-sm text-gray-500 leading-relaxed">Start a module on your phone during your commute and seamlessly resume exactly where you left off on your laptop at home.</p>
                            </div>
                        </li>
                    </ul>
                </div>
                
                <div class="flex-1 w-full relative perspective-1000 reveal-on-scroll" style="transition-delay: 0.2s;">
                    <!-- Abstract UI Mockup -->
                    <div class="bg-white rounded-3xl p-4 md:p-8 aspect-square relative overflow-hidden border border-gray-100 shadow-[0_20px_50px_rgb(0,0,0,0.05)] transform rotate-y-[-5deg] rotate-x-[5deg] hover:rotate-y-0 hover:rotate-x-0 transition-transform duration-700 ease-out">
                        <div class="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50"></div>
                        
                        <!-- Desktop mockup -->
                        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-[60%] w-[85%] h-2/3 bg-white rounded-xl shadow-2xl border border-gray-200 z-10 flex flex-col overflow-hidden">
                            <div class="h-8 bg-slate-100 border-b border-gray-200 flex items-center px-4 gap-2">
                                <div class="w-3 h-3 rounded-full bg-red-400"></div>
                                <div class="w-3 h-3 rounded-full bg-yellow-400"></div>
                                <div class="w-3 h-3 rounded-full bg-green-400"></div>
                                <div class="ml-4 h-4 bg-white rounded flex-1 max-w-[50%]"></div>
                            </div>
                            <div class="flex-1 p-5 flex gap-4">
                                <div class="w-1/3 flex flex-col gap-3">
                                    <div class="w-full h-24 bg-blue-50 rounded-lg border border-blue-100"></div>
                                    <div class="w-3/4 h-3 bg-gray-200 rounded"></div>
                                    <div class="w-1/2 h-3 bg-gray-100 rounded"></div>
                                </div>
                                <div class="w-2/3 flex flex-col gap-3">
                                    <div class="w-full h-8 bg-gray-100 rounded"></div>
                                    <div class="w-full h-full bg-slate-800 rounded-lg p-3 flex flex-col gap-2">
                                        <div class="w-1/2 h-2 bg-green-400/50 rounded"></div>
                                        <div class="w-3/4 h-2 bg-blue-400/50 rounded"></div>
                                        <div class="w-2/3 h-2 bg-purple-400/50 rounded"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Mobile mockup -->
                        <div class="absolute bottom-8 right-8 w-1/3 aspect-[9/19] bg-white rounded-[2rem] shadow-[0_20px_40px_rgba(0,0,0,0.2)] border-8 border-slate-800 z-20 flex flex-col overflow-hidden">
                            <div class="h-5 bg-slate-800 w-1/2 mx-auto rounded-b-xl absolute top-0 left-1/2 transform -translate-x-1/2 z-30"></div>
                            <div class="flex-1 bg-gray-50 flex flex-col pt-8 px-3 gap-3">
                                <div class="w-full aspect-video bg-purple-100 rounded-lg border border-purple-200"></div>
                                <div class="w-3/4 h-4 bg-gray-200 rounded"></div>
                                <div class="w-full h-2 bg-gray-200 rounded"></div>
                                <div class="w-5/6 h-2 bg-gray-200 rounded"></div>
                                
                                <div class="mt-auto mb-4 w-full h-10 bg-blue-500 rounded-lg"></div>
                            </div>
                        </div>
                        
                        <!-- Floating badges -->
                        <div class="absolute top-1/4 -left-4 bg-white py-2 px-4 rounded-xl shadow-lg border border-gray-100 z-30 flex items-center gap-3 animate-bounce" style="animation-duration: 3s;">
                            <div class="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center"><i class="fas fa-check"></i></div>
                            <div>
                                <div class="text-xs text-gray-500 font-bold">Progress Saved</div>
                                <div class="text-sm font-extrabold text-gray-900">Cloud Sync Active</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <main class="flex-1 container mx-auto px-4 pb-12">
        <div class="flex items-center justify-between mb-8 max-w-6xl mx-auto reveal-on-scroll">
            <h2 class="text-2xl font-bold text-gray-900">Available Courses</h2>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 mb-10 flex flex-col md:flex-row gap-4 max-w-6xl mx-auto reveal-on-scroll" style="transition-delay: 0.1s;">
            <div class="relative flex-1">
                <i class="fas fa-search absolute left-5 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input type="text" id="searchInput" placeholder="Search courses by title or keyword..." class="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition text-gray-700 font-medium">
            </div>
            <div class="relative">
                <select id="categoryFilter" class="w-full md:w-64 px-5 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 text-gray-700 font-medium cursor-pointer appearance-none pr-10">
                <option value="all">All Categories</option>
                <option value="programming">Programming</option>
                <option value="cloud">Cloud Computing</option>
                <option value="data">Data & Databases</option>
                <option value="security">Cyber Security</option>
            </select>
                <i class="fas fa-chevron-down absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none text-sm"></i>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16 max-w-6xl mx-auto" id="courseGrid">
            
            <!-- JavaScript Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="programming" style="transition-delay: 0.1s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-java overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fab fa-js relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Programming</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">JavaScript Deep Dive</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Master modern JavaScript (ES6+). Learn closures, promises, async/await, and DOM manipulation to build interactive web apps.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Beginner to Pro</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 40 Hours</span>
                    </div>
                    <!-- ✅ Added type="button" to prevent form submission -->
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>

            <!-- AWS Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="cloud" style="transition-delay: 0.2s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-aws overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fab fa-aws relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Cloud</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">AWS Solutions Architect</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Master Amazon Web Services. Learn EC2, S3, RDS, IAM, and best practices for building scalable cloud infrastructure.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Intermediate</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 55 Hours</span>
                    </div>
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>

            <!-- Go Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="programming" style="transition-delay: 0.3s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-python overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fab fa-golang relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Programming</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">Go (Golang) Fundamentals</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Build fast, reliable, and efficient software at scale. Master Go's concurrency model, goroutines, and channels.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Intermediate</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 35 Hours</span>
                    </div>
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>

            <!-- Database Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="data" style="transition-delay: 0.1s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-database overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fas fa-database relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Data</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">SQL & Database Design</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Understand relational databases. Learn complex queries, joins, indexing, and normalization using MySQL on Cloud.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Intermediate</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 25 Hours</span>
                    </div>
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>

            <!-- Security Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="security" style="transition-delay: 0.2s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-security overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fas fa-shield-alt relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Security</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">Cloud Security Fundamentals</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Protect cloud infrastructure. Deep dive into IAM policies, encryption in transit/rest, and AWS security best practices.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Advanced</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 30 Hours</span>
                    </div>
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>
            
            <!-- React Course -->
            <div class="group bg-white rounded-2xl shadow-sm hover:shadow-xl hover:shadow-blue-500/10 border border-gray-100 transition-all duration-300 overflow-hidden flex flex-col course-card hover:-translate-y-1 reveal-on-scroll" data-category="programming" style="transition-delay: 0.3s;">
                <div class="h-48 flex items-center justify-center text-6xl text-white relative bg-react overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors duration-300"></div>
                    <i class="fab fa-react relative z-10 drop-shadow-md group-hover:scale-110 transition-transform duration-300"></i>
                    <span class="absolute top-4 right-4 glass-tag text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide uppercase">Frontend</span>
                </div>
                <div class="p-7 flex flex-col flex-1">
                    <h3 class="text-xl font-bold text-gray-900 mb-3 course-title leading-tight">React & Frontend Web Dev</h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 course-desc leading-relaxed">Build dynamic single-page applications using modern React, Hooks, Context API, and state management.</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 border-t border-gray-100 pt-5 mb-6 font-medium">
                        <span class="flex items-center gap-2"><i class="fas fa-signal text-blue-500"></i> Intermediate</span>
                        <span class="flex items-center gap-2"><i class="fas fa-clock text-blue-500"></i> 45 Hours</span>
                    </div>
                    <button type="button" onclick="alert('This course is coming soon!');" class="block w-full text-center btn-vibrant btn-shine text-white font-semibold py-3.5 px-4 rounded-xl shadow-md cursor-pointer">Coming Soon</button>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-12 mt-auto reveal-on-scroll">
        <div class="container mx-auto px-4 text-center">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 text-left mb-10">
                <!-- Brand -->
                <div>
                    <div class="flex items-center gap-2 mb-4">
                        <i class="fas fa-layer-group text-blue-500 text-xl"></i>
                        <span class="text-xl font-bold text-white tracking-tight">Learnify</span>
                    </div>
                    <p class="text-sm leading-relaxed mb-4">Empowering modern education with scalable cloud technology. Secure, structured, and globally accessible.</p>
                </div>
                
                <!-- About Us -->
                <div>
                    <h3 class="text-white font-bold mb-4 uppercase text-sm tracking-wider">About Us</h3>
                    <ul class="space-y-2 text-sm">
                        <li><a href="#" class="hover:text-blue-400 transition-colors">Our Story</a></li>
                        <li><a href="#" class="hover:text-blue-400 transition-colors">Leadership Team</a></li>
                        <li><a href="#" class="hover:text-blue-400 transition-colors">Careers</a></li>
                        <li><a href="#" class="hover:text-blue-400 transition-colors">Cloud Infrastructure</a></li>
                    </ul>
                </div>
                
                <!-- Contact & Enquiry -->
                <div>
                    <h3 class="text-white font-bold mb-4 uppercase text-sm tracking-wider">Contact & Enquiry</h3>
                    <ul class="space-y-3 text-sm">
                        <li class="flex items-center gap-3"><i class="fas fa-envelope text-blue-500 w-4"></i> support@learnify.com</li>
                        <li class="flex items-center gap-3"><i class="fas fa-phone text-blue-500 w-4"></i> +1 (800) 123-4567</li>
                        <li class="flex items-center gap-3"><i class="fas fa-map-marker-alt text-blue-500 w-4"></i> AWS Cloud Node, Global</li>
                        <li class="pt-2"><a href="contact.php" class="inline-block py-2 px-4 rounded-lg bg-slate-800 text-blue-400 hover:bg-slate-700 hover:text-blue-300 font-semibold transition-colors border border-slate-700 text-xs">Submit an Enquiry &rarr;</a></li>
                    </ul>
                </div>
                
                <!-- Achievements -->
                <div>
                    <h3 class="text-white font-bold mb-4 uppercase text-sm tracking-wider">Our Achievements</h3>
                    <ul class="space-y-4 text-sm">
                        <li class="flex items-start gap-3">
                            <i class="fas fa-award text-yellow-500 mt-1 text-lg w-5"></i>
                            <div>
                                <strong class="text-white block">1M+ Active Learners</strong>
                                <span class="text-xs">Across 150+ countries</span>
                            </div>
                        </li>
                        <li class="flex items-start gap-3">
                            <i class="fas fa-certificate text-purple-400 mt-1 text-lg w-5"></i>
                            <div>
                                <strong class="text-white block">500k+ Certifications</strong>
                                <span class="text-xs">Auto-generated securely</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
                <p class="text-sm text-slate-500">© 2026 Learnify. All rights reserved.</p>
                <div class="flex gap-4">
                    <a href="#" class="text-slate-400 hover:text-white transition-colors text-lg"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-slate-400 hover:text-white transition-colors text-lg"><i class="fab fa-linkedin"></i></a>
                    <a href="#" class="text-slate-400 hover:text-white transition-colors text-lg"><i class="fab fa-github"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <!-- ✅ Added script tags correctly -->
    <script>
        // ✅ Force reload if page is loaded from BFCache (Back/Forward Cache)
        window.addEventListener("pageshow", function(event) {
            if (event.persisted) {
                window.location.reload();
            }
        });

        // Pass PHP variables to JS safely
        let isEnrolledPython = <?php echo $isEnrolledPython ? 'true' : 'false'; ?>;
        let isEnrolledJava = <?php echo $isEnrolledJava ? 'true' : 'false'; ?>;
        let isEnrolledFS = <?php echo $isEnrolledFS ? 'true' : 'false'; ?>;
        let selectedCourseId = null;

        function handlePythonClick() {
            if (isEnrolledPython) {
                window.location.href = "/eduspring/courses/Python_Courses/python_programming_course_overview.php";
            } else {
                openEnrollModal(1);
            }
        }

        function handleJavaClick() {
            if (isEnrolledJava) {
                window.location.href = "/eduspring/courses/Java_Courses/java_programming_course_overview.php";
            } else {
                openEnrollModal(2);
            }
        }

        function handleFSClick() {
            if (isEnrolledFS) {
                window.location.href = "/eduspring/courses/Full-Stack_Courses/fullstack_course_overview.php";
            } else {
                openEnrollModal(3);
            }
        }

        // Modal Functions
        function openEnrollModal(courseId) {
            selectedCourseId = courseId;
            const modal = document.getElementById("enrollModal");
            if (modal) {
                modal.classList.remove("hidden");
                modal.classList.add("flex");
                document.body.style.overflow = "hidden"; // Prevent background scrolling
            }
        }

        function closeModal() {
            const modal = document.getElementById("enrollModal");
            if (modal) {
                modal.classList.add("hidden");
                modal.classList.remove("flex");
                document.body.style.overflow = "auto";
            }
        }

        function confirmEnroll() {
            if (selectedCourseId) {
                window.location.href = "/eduspring/enroll.php?course_id=" + selectedCourseId;
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById("enrollModal");
            if (event.target == modal) {
                closeModal();
            }
        }

        // Simple JS for filtering courses
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        const courseCards = document.querySelectorAll('.course-card');

        if (searchInput && categoryFilter && courseCards.length > 0) {
            function filterCourses() {
                const searchTerm = searchInput.value.toLowerCase();
                const category = categoryFilter.value;

                courseCards.forEach(card => {
                    const title = card.querySelector('.course-title').textContent.toLowerCase();
                    const desc = card.querySelector('.course-desc').textContent.toLowerCase();
                    const cardCategory = card.getAttribute('data-category');
                    
                    const matchesSearch = title.includes(searchTerm) || desc.includes(searchTerm);
                    const matchesCategory = category === 'all' || category === cardCategory;

                    if (matchesSearch && matchesCategory) {
                        card.style.display = 'flex';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }

            searchInput.addEventListener('keyup', filterCourses);
            categoryFilter.addEventListener('change', filterCourses);
        }

        // Scroll reveal animation using Intersection Observer
        document.addEventListener("DOMContentLoaded", function() {
            const observerOptions = {
                root: null,
                rootMargin: '0px',
                threshold: 0.1
            };

            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            document.querySelectorAll('.reveal-on-scroll').forEach((elem) => {
                observer.observe(elem);
            });
            
            // Typing effect cleanup
            setTimeout(() => {
                const typingEl = document.querySelector(".typing");
                if(typingEl) typingEl.classList.add("done");
            }, 3000);

            // Ripple Effect Logic
            document.querySelectorAll(".btn-vibrant").forEach(btn => {
                btn.addEventListener("click", function(e) {
                    // Prevent double firing if necessary (though onclick usually handles this)
                    // Logic handled inside CSS/animation, but we ensure the click passes through
                    const circle = document.createElement("span");
                    circle.classList.add("ripple");

                    const rect = btn.getBoundingClientRect();
                    const size = Math.max(rect.width, rect.height);
                    
                    circle.style.width = circle.style.height = size + "px";
                    circle.style.left = e.clientX - rect.left - size / 2 + "px";
                    circle.style.top = e.clientY - rect.top - size / 2 + "px";

                    btn.appendChild(circle);

                    setTimeout(() => circle.remove(), 600);
                });
            });
        });
    </script>

    <!-- 🔥 ENROLL MODAL -->
    <!-- ✅ Added higher z-index (9999) to sit above everything -->
    <div id="enrollModal" class="fixed inset-0 bg-black bg-opacity-60 hidden z-[9999] items-center justify-center backdrop-blur-sm">
        <div class="bg-white rounded-2xl p-8 w-[90%] max-w-md text-center shadow-2xl transform transition-all scale-100">
            <h2 class="text-2xl font-bold mb-4 text-gray-900">Enroll in Course</h2>
            <p class="text-gray-500 mb-6">Do you want to enroll in this course and start your journey?</p>

            <div class="flex justify-center gap-4">
                <button type="button" onclick="confirmEnroll()" class="bg-blue-600 text-white px-6 py-2.5 rounded-lg hover:bg-blue-700 transition shadow-md font-semibold">
                    Yes, Enroll
                </button>

                <button type="button" onclick="closeModal()" class="bg-gray-200 text-gray-800 px-6 py-2.5 rounded-lg hover:bg-gray-300 transition font-semibold">
                    Cancel
                </button>
            </div>
        </div>
    </div>

</body>
</html>