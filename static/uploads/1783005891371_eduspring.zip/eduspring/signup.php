<?php
// ---------- DATABASE CONNECTION ----------

$conn = new mysqli(
    "127.0.0.1",   // hostname
    "root",        // username
    "",            // password
    "eduspring_db",// database name
    3306           // PORT (Workbench la irukura port)
);


if ($conn->connect_error) {
    die("DB Failed: " . $conn->connect_error);
}


// ---------- FORM SUBMIT LOGIC ----------
// ---------- FORM SUBMIT LOGIC ----------
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fname     = $_POST['fname'];
    $lname     = $_POST['lname'];
    $dob       = $_POST['dob'];
    $phone     = $_POST['phone'];
    $address   = $_POST['address'];
    $username  = $_POST['username'];
    $email     = $_POST['email'];
    $password  = $_POST['password'];
    $confirm   = $_POST['confirm_password'];

    // Username already exists check
    $checkUser = $conn->prepare("SELECT username,email,phone FROM users WHERE username=? OR email=? OR phone=?");
$checkUser->bind_param("sss", $username, $email, $phone);
$checkUser->execute();

$result = $checkUser->get_result();

if ($result->num_rows > 0) {

$row = $result->fetch_assoc();

    $error = "";

if ($row['username'] == $username) {
    $error = "Username already exists";
}
elseif ($row['email'] == $email) {
    $error = "Email already registered";
}
elseif ($row['phone'] == $phone) {
    $error = "Phone number already registered";
}
}
    else {

        // Strong password backend check
        if (!preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/', $password)) {
    echo "<script>alert('Password is weak');</script>";
}

        else {

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO users
                    (fname, lname, dob, phone, address, username, email, password)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssss",
                $fname,
                $lname,
                $dob,
                $phone,
                $address,
                $username,
                $email,
                $hashedPassword
            );

            if ($stmt->execute()) {
    echo "<script>
            alert('Signup successful ✅');
            window.location.href='courses.php';
          </script>";
} else {
                echo "<script>alert('Signup failed');</script>";
            }

            $stmt->close();
        }
    }
    $checkUser->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learnify - Create Account</title>

<style>
.password-group{
grid-column: span 1;
}

.confirm-group{
grid-column: span 1;
}

.confirm-group input{
width:100%;
}

@media (min-width:768px){

.password-group{
grid-column:1;
}

.confirm-group{
grid-column:2;
}

}

body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(120deg, #0f172a, #134e5e, #22c1c3);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px 15px;
}
.register-container {
    background-color: #ffffff;
    padding: 35px 25px;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
    width: 100%;
    max-width: 700px;

}
h2 {
    text-align: center;
    color: #0f172a;
    margin-bottom: 30px;
}
form {
    display: grid;
    grid-template-columns: 1fr;
    gap: 15px;
}
@media (min-width: 768px) {
    form { grid-template-columns: 1fr 1fr; }
    .full-width { grid-column: span 2; }
}
.form-group {
    display: flex;
    flex-direction: column;
}
label {
    margin-bottom: 8px;
    font-weight: 600;
}
input {
    padding: 14px;
    padding-right:40px;
    border-radius: 12px;
    border: 2px solid #e1e1e1;
    width:100%;
    box-sizing:border-box;
}
button {
    background: #22c1c3;
    color: white;
    padding: 16px;
    border: none;
    border-radius: 50px;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
}
span{
    font-size:13px;
    margin-top:5px;
}
@media (min-width: 768px) {
    button { grid-column: span 2; }
}

.password-wrapper{
position:relative;
width:100%;
}

.password-wrapper input{
width:100%;
}

.confirm-group div{
width:100%;
}

.password-tooltip{
position:absolute;
left:0;
top:55px;
width:220px;
background:#fff;
border-radius:10px;
padding:12px;
box-shadow:0 5px 15px rgba(0,0,0,0.2);
font-size:13px;
display:none;
z-index:10;
}

.password-tooltip p{
margin:4px 0;
transition:0.3s;
}

.password-wrapper:focus-within .password-tooltip{
display:block;
opacity:1;
}
</style>
<script>

function checkAvailability(type){

let value = document.getElementById(type).value;

fetch("check_user.php?type="+type+"&value="+value)
.then(response=>response.text())
.then(data=>{

let msgBox = document.getElementById(type+"Msg");

if(data=="exists"){
msgBox.innerHTML = "❌ Already taken";
msgBox.style.color="red";
}else{
msgBox.innerHTML = "✅ Available";
msgBox.style.color="green";
}

});

}

function validateForm() {

    // Name regex (letters, dot, space)
    const nameRegex = /^[A-Za-z.\s]+$/;

    // Phone numbers only
    const phoneRegex = /^[0-9]+$/;

    // Strong password regex
    const passwordRegex =
    /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/;

    let fname = document.forms["signupForm"]["fname"].value;
    let lname = document.forms["signupForm"]["lname"].value;
    let phone = document.forms["signupForm"]["phone"].value;
    let address = document.forms["signupForm"]["address"].value;
    let password = document.forms["signupForm"]["password"].value;
    let confirm = document.forms["signupForm"]["confirm_password"].value;

    if (!nameRegex.test(fname)) {
        alert("First name: letters, dot, spaces only");
        return false;
    }

    if (!nameRegex.test(lname)) {
        alert("Last name: letters, dot, spaces only");
        return false;
    }

    if (!phoneRegex.test(phone)) {
        alert("Phone number: numbers only");
        return false;
    }

    if (address.length > 100) {
        alert("Address max 100 characters only");
        return false;
    }

    if (!passwordRegex.test(password)) {
        alert(
  "Password must contain:\n• 1 uppercase\n• 1 lowercase\n• 1 number\n• 1 special character\n• Min 8 characters"
);

        return false;
    }

    if (password !== confirm) {
        alert("Passwords do not match");
        return false;
    }

    return true;
}

function togglePassword(){

let pwd=document.getElementById("password");

if(pwd.type==="password"){
pwd.type="text";
}else{
pwd.type="password";
}

}

function toggleConfirmPassword(){

let pwd=document.getElementById("confirm_password");

if(pwd.type==="password"){
pwd.type="text";
}else{
pwd.type="password";
}

}


function checkPassword(){

let pwd=document.getElementById("password").value;

let upper=/[A-Z]/.test(pwd);
let lower=/[a-z]/.test(pwd);
let number=/[0-9]/.test(pwd);
let special=/[\W_]/.test(pwd);
let length=pwd.length>=8;

document.getElementById("upper").innerHTML =
upper ? "✅ 1 Uppercase letter" : "❌ 1 Uppercase letter";

document.getElementById("lower").innerHTML =
lower ? "✅ 1 Lowercase letter" : "❌ 1 Lowercase letter";

document.getElementById("number").innerHTML =
number ? "✅ 1 Number" : "❌ 1 Number";

document.getElementById("special").innerHTML =
special ? "✅ 1 Special character" : "❌ 1 Special character";

document.getElementById("length").innerHTML =
length ? "✅ Minimum 8 characters" : "❌ Minimum 8 characters";

let strength=0;
if(upper) strength++;
if(lower) strength++;
if(number) strength++;
if(special) strength++;
if(length) strength++;

let bar=document.getElementById("strengthBar");

if(strength<=2){
bar.style.width="30%";
bar.style.background="red";
}
else if(strength<=4){
bar.style.width="65%";
bar.style.background="orange";
}
else{
bar.style.width="100%";
bar.style.background="green";
}

}

function checkMatch(){

let pwd=document.getElementById("password").value;
let confirm=document.getElementById("confirm_password").value;
let msg=document.getElementById("matchMsg");

if(confirm.length===0){
msg.innerHTML="";
return;
}

if(pwd===confirm){
msg.innerHTML="✅ Passwords match";
msg.style.color="green";
}else{
msg.innerHTML="❌ Passwords do not match";
msg.style.color="red";
}

}

</script>

</head>

<body>

<div class="register-container">
<h2>Create Account</h2>

    <?php if(!empty($error)){ ?>
    <p style="color:red; text-align:center; font-weight:bold;">
    <?php echo $error; ?>
    </p>
    <?php } ?>

<form method="POST" name="signupForm" onsubmit="return validateForm()">
    

    <div class="form-group">
        <label>First Name</label>
        <input type="text" name="fname" required>
    </div>

    <div class="form-group">
        <label>Last Name</label>
        <input type="text" name="lname" required>
    </div>

    <div class="form-group">
        <label>Date of Birth</label>
        <input type="date" name="dob" required>
    </div>

    <div class="form-group">
        <label>Phone</label>
        <input type="text" name="phone" id="phone"
        maxlength="10"
        onkeyup="checkAvailability('phone')">

<span id="phoneMsg"></span>
    </div>

    <div class="form-group full-width">
        <label>Address</label>
        <input type="text" name="address" required>
    </div>

    <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" id="username"
        onkeyup="checkAvailability('username')" required>

        <span id="usernameMsg"></span>
    </div>

    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" id="email"
        onkeyup="checkAvailability('email')" required>

        <span id="emailMsg"></span>
    </div>

    <div class="form-group password-group">
        <label>Password</label>

        <div class="password-wrapper">

            <div style="position:relative;">
                <input type="password" name="password" id="password" onkeyup="checkPassword()" required>
                <span onclick="togglePassword()" style="position:absolute;right:12px;top:12px;cursor:pointer;">👁</span>
            </div>

        <div class="password-tooltip">

            <b>Password must contain</b>

            <p id="upper">❌ 1 Uppercase letter</p>
            <p id="lower">❌ 1 Lowercase letter</p>
            <p id="number">❌ 1 Number</p>
            <p id="special">❌ 1 Special character</p>
            <p id="length">❌ Minimum 8 characters</p>

            <!-- Strength Bar -->
            <div style="height:8px;background:#eee;border-radius:10px;margin-top:8px;">
                <div id="strengthBar"
                    style="height:8px;width:0%;background:red;border-radius:10px;transition:0.3s;">
                </div>
            </div>
        </div>
        </div>
    </div>


    <div class="form-group confirm-group">
<label>Confirm Password</label>

<div style="position:relative;">

<input type="password"
name="confirm_password"
id="confirm_password"
onkeyup="checkMatch()"
required>

<span onclick="toggleConfirmPassword()"
style="position:absolute;right:12px;top:12px;cursor:pointer;">👁</span>

</div>

<p id="matchMsg" style="font-size:13px;"></p>

</div>

<button type="submit">Join Learnify</button>

</form>
</div>

</body>
</html>