<?php
session_start();
include("db.php"); // ✅ use common DB connection

$errorMsg = "";

// Show message if redirected
if (isset($_GET['error'])) {
    $errorMsg = "Please Login First To See The Courses!!!";
}

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check username OR email
    $sql = "SELECT * FROM users WHERE username=? OR email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        $row = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $row['password'])) {

            // ✅ Store session properly
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['username'] = $row['username'];

            // Redirect
            header("Location: courses.php");
            exit();

        } else {
            $errorMsg = "Wrong Password ❌";
        }

    } else {
        $errorMsg = "Username / Email not found ❌";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learnify - Login</title>

<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(120deg, #0f172a, #134e5e, #22c1c3);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 15px;
}

@keyframes blurIn {
    from {
        filter: blur(20px);
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        filter: blur(0);
        opacity: 1;
        transform: scale(1);
    }
}

.login-container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.3);
    width: 100%;
    max-width: 400px;
    animation: blurIn 0.8s ease-out;
}

h2 {
    text-align: center;
    color: #0f172a;
    margin-bottom: 30px;
    font-size: 32px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

label {
    margin-bottom: 8px;
    font-weight: 600;
    font-size: 14px;
}

input {
    width: 100%;
    padding: 14px 45px 14px 14px;
    border: 2px solid #e1e1e1;
    border-radius: 12px;
    font-size: 16px;
    box-sizing: border-box;
}

button {
    padding: 16px;
    background: #22c1c3;
    color: white;
    border: none;
    border-radius: 50px;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #0f172a;
}

.links {
    text-align: center;
    margin-top: 20px;
    font-size: 0.95rem;
}

.links a {
    color: #22c1c3;
    font-weight: bold;
    text-decoration: none;
}

.emoji-btn {
    position: absolute;
    right: 15px;
    top: 60%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 18px;
}

.form-group {
    position: relative;
}

.form-group input[type="password"] {
    padding-right: 45px;
}
</style>
</head>

<body>

<div class="login-container">
    <h2>Welcome Back</h2>

    <?php if($errorMsg != ""){ ?>
    <div style="color:red; text-align:center; margin-bottom:15px; font-weight:bold;">
        <?php echo $errorMsg; ?>
    </div>
    <?php } ?>

    <form action="signin.php" method="POST">

        <div class="form-group">
            <label>Username / Email</label>
            <input type="text" name="username" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" id="password" required>
            <span class="emoji-btn" id="togglePass">🔒</span>
        </div>

        <!-- ✅ FIXED BUTTON -->
        <button type="submit" name="login">Login to Learnify</button>

        <div class="links">
            Don't have an account? <a href="signup.php">Sign Up</a>
        </div>

    </form>
</div>

<script>
const togglePass = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');

togglePass.addEventListener('click', () => {
    const isPass = passwordInput.type === 'password';
    passwordInput.type = isPass ? 'text' : 'password';
    togglePass.textContent = isPass ? '🔓' : '🔒';
});
</script>

</body>
</html>