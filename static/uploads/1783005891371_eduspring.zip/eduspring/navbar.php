<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}

$current = basename($_SERVER['PHP_SELF']);
?>

<header id="navbar" class="bg-blue-900/40 backdrop-blur-xl border-b border-blue-400/20 text-white sticky top-0 z-50 shadow-lg">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<div class="nav-container">
<h2 class="logo-text">
    <img src="/eduspring/assets/logo.png" class="glow-logo">
    <span class="brand-name">Learnify</span>
</h2>

<nav class="nav-center">

<a href="/eduspring/home.php" 
class="nav-link <?php if($current=='home.php') echo 'active-link'; ?>">Home</a>

<a href="/eduspring/courses.php" 
class="nav-link <?php if($current=='courses.php') echo 'active-link'; ?>">Courses</a>

<a href="/eduspring/about.php" 
class="nav-link <?php if($current=='about.php') echo 'active-link'; ?>">About Us</a>

<a href="/eduspring/contact.php" 
class="nav-link <?php if($current=='contact.php') echo 'active-link'; ?>">Contact Us</a>

</nav>

    <?php if(isset($_SESSION['user_email']) && $current != 'home.php'){ ?>

<div class="nav-right">
    <button id="userMenuBtn"
    class="user-btn">
        <?php echo htmlspecialchars($_SESSION['user_email']); ?>
    </button>

    <!-- DROPDOWN -->
    <div id="userDropdown" 
    class="dropdown-menu">

        <a href="/eduspring/dashboard.php" 
        class="block px-4 py-3 text-sm text-white hover:bg-blue-500/20 transition">
            Dashboard
        </a>

        <a href="/eduspring/logout.php" 
        class="block px-4 py-3 text-sm text-red-400 hover:bg-red-500/20 transition">
            Logout
        </a>

    </div>
</div>

    <?php } else { ?>

    <a href="/eduspring/signin.php"
    class="signin-btn">
        Sign In
    </a>

    <?php } ?>
        </div>
    </div>
</header>
<style>
body {
    font-family: 'Poppins', sans-serif;
}
/* ===== GLOBAL NAVBAR ===== */
#navbar {
    height: 75px;
    position: sticky;
    top: 0;
    z-index: 1000;
    background: rgba(15, 23, 42, 0.75);
    backdrop-filter: blur(15px);
    border-bottom: 1px solid rgba(59,130,246,0.2);
    box-shadow: 0 6px 25px rgba(0,0,0,0.4);
    transition: 0.3s ease;
    padding-top: 10px !important;
    padding-bottom: 10px !important;
}

/* CONTAINER */
.nav-container {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
    padding: 12px 50px;
}

/* LOGO */
.logo-text {
    display: flex;
    align-items: center;
    gap: 10px;
}

.brand-name {
    font-size: 22px;
    font-weight: 800;
    background: linear-gradient(90deg, #60a5fa, #a78bfa);
    -webkit-background-clip: text;
    color: transparent;
}

/* LOGO EFFECT */
.glow-logo {
    width: 50px;
    height: 50px;
    filter: drop-shadow(0 0 8px #3b82f6);
    transition: 0.4s;
}

.glow-logo:hover {
    transform: scale(1.1) rotate(5deg);
}

/* NAV CENTER */
.nav-center {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 35px;
    margin: 0 auto;
}

/* NAV LINKS */
.nav-link {
    letter-spacing: 0.4px;
    position: relative;
    padding: 8px 14px;
    font-size: 15px;
    font-weight: 600;
    color: #e2e8f0;
    text-decoration: none;
    transition: 0.3s;
}

/* HOVER EFFECT */
.nav-link:hover {
    text-shadow: 0 0 12px rgba(59,130,246,0.8);
    color: white;
}

/* UNDERLINE ANIMATION */
.nav-link::after {
    content: "";
    position: absolute;
    left: 50%;
    bottom: -5px;
    width: 0%;
    height: 2px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6);
    transition: 0.3s;
    transform: translateX(-50%);
}

.nav-link:hover::after {
    width: 80%;
}

/* ACTIVE LINK */
.active-link {
    color: white;
}

.active-link::after {
    width: 80%;
}

/* RIGHT SIDE */
.nav-right {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    min-width: 220px;
    position: relative;
}

/* USER BUTTON */
.user-btn {
    padding: 8px 18px;
    border-radius: 25px;

    /* SAME FONT AS NAV 🔥 */
    font-family: 'Poppins', sans-serif;
    font-size: 14px;
    font-weight: 600;

    color: #e2e8f0;

    /* GLASS STYLE */
    background: rgba(255,255,255,0.08);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.2);

    cursor: pointer;
    transition: 0.3s ease;

    box-shadow: 0 0 10px rgba(59,130,246,0.2);
}

/* HOVER */
.user-btn:hover {
    color: white;
    background: rgba(59,130,246,0.2);
    border-color: rgba(59,130,246,0.5);
    box-shadow: 0 0 20px rgba(59,130,246,0.5);
    transform: translateY(-2px);
}

/* DROPDOWN */
.dropdown-menu {
    position: absolute;
    right: 0;
    top: 50px;
    background: #0f172a;
    border-radius: 12px;
    width: 160px;
    overflow: hidden;
    display: none;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}

.dropdown-menu a {
    display: block;
    padding: 12px;
    color: white;
    text-decoration: none;
    transition: 0.3s;
}

.dropdown-menu a:hover {
    background: #3b82f6;
}

/* SHOW */
.dropdown-menu.show {
    display: block;
}

/* SIGN IN BUTTON */
.signin-btn {
    padding: 8px 18px;
    border-radius: 25px;
    border: 1px solid rgba(255,255,255,0.2);
    color: white;
    text-decoration: none;
    transition: 0.3s;
}

.signin-btn:hover {
    background: white;
    color: #0f172a;
}

/* SCROLL EFFECT */
.navbar-scrolled {
    background: rgba(15, 23, 42, 0.95);
    padding-top: 8px;
    padding-bottom: 8px;
}

/* ===== 1. LOGO FLOATING (SMOOTH) ===== */
.glow-logo {
    animation: floatLogo 3s ease-in-out infinite;
}

@keyframes floatLogo {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
}

/* ===== 2. NAV LINK HOVER (LIFT + GLOW) ===== */
.nav-link:hover {
    transform: translateY(-4px) scale(1.05);
    text-shadow: 0 0 10px rgba(59,130,246,0.9);
}

/* ===== 3. ACTIVE LINK (DARK PULSE 🔥) ===== */
.active-link {
    position: relative;
    background: rgba(30, 41, 59, 0.8);
    border-radius: 10px;
}

.active-link::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: 10px;
    box-shadow: 0 0 12px rgba(59,130,246,0.5);
    animation: darkPulse 2s infinite alternate;
}

@keyframes darkPulse {
    from {
        box-shadow: 0 0 10px rgba(59,130,246,0.4);
    }
    to {
        box-shadow: 0 0 25px rgba(99,102,241,0.9);
    }
}

/* ===== 4. DROPDOWN SMOOTH ZOOM ===== */
.dropdown-menu {
    transform: scale(0.85) translateY(-10px);
    opacity: 0;
    transition: 0.25s ease;
}

.dropdown-menu.show {
    transform: scale(1) translateY(0);
    opacity: 1;
}

/* ===== 5. BUTTON SHINE EFFECT ===== */
.user-btn, .signin-btn {
    position: relative;
    overflow: hidden;
}

.user-btn::before, .signin-btn::before {
    content: "";
    position: absolute;
    top: 0;
    left: -120%;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
    transition: 0.6s;
}

.user-btn:hover::before,
.signin-btn:hover::before {
    left: 120%;
}

/* ===== DROPDOWN ITEM COLORS 🔥 ===== */
.dropdown-menu a:first-child:hover {
    background: rgba(59,130,246,0.9); /* Dashboard blue */
    color: white;
}

.dropdown-menu a:last-child:hover {
    background: rgba(239,68,68,0.9); /* Logout red */
    color: white;
}

/* EXTRA: dropdown hover smooth feel */
.dropdown-menu a {
    transition: 0.25s;
}

/* ===== EXTRA PREMIUM TOUCH ===== */

/* NAVBAR subtle glow */
#navbar:hover {
    box-shadow: 0 10px 40px rgba(0,0,0,0.7);
}

/* LINK CLICK FEEDBACK */
.nav-link:active {
    transform: scale(0.95);
}

/* BUTTON CLICK FEEDBACK */
.user-btn:active, .signin-btn:active {
    transform: scale(0.92);
}
</style>

    <script>

// NAVBAR SCROLL
window.addEventListener("scroll", function () {
    const navbar = document.getElementById("navbar");

    if (window.scrollY > 50) {
        navbar.classList.add("navbar-scrolled");
    } else {
        navbar.classList.remove("navbar-scrolled");
    }
});

// DROPDOWN TOGGLE
const btn = document.getElementById("userMenuBtn");
const dropdown = document.getElementById("userDropdown");

if(btn && dropdown){
    btn.addEventListener("click", function () {
        dropdown.classList.toggle("show");
    });

    document.addEventListener("click", function (e) {
        if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.remove("show");
        }
    });
}
</script>