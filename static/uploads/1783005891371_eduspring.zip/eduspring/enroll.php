<?php
session_start();

include("db.php");

if ($conn->connect_error) {
    die("DB connection failed: " . $conn->connect_error);
}

if(!isset($_SESSION['user_id'])){
    header("Location: signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;

if($course_id == 0){
    die("Invalid course");
}


// check duplicate
$check = $conn->prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? LIMIT 1");

if(!$check){
    die("Prepare failed: " . $conn->error);
}

$check->bind_param("ii", $user_id, $course_id);
$check->execute();
$result = $check->get_result();

if($result->num_rows == 0){

    // insert into enrollments
    $stmt = $conn->prepare("INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $course_id);
    $stmt->execute();

    // 🔥 set total topics based on course
$topicsMap = [
    1 => 23, // Python
    2 => 28, // Java
    3 => 14  // Fullstack
];

$total_topics = $topicsMap[$course_id] ?? 10;

    // 🔥 check progress already exists
    $checkProgress = $conn->prepare("SELECT 1 FROM course_progress WHERE user_id=? AND course_id=? LIMIT 1");
    $checkProgress->bind_param("ii", $user_id, $course_id);
    $checkProgress->execute();
    $resProgress = $checkProgress->get_result();

    if($resProgress->num_rows == 0){

        // 🔥 insert progress
        $insertProgress = $conn->prepare("
        INSERT INTO course_progress 
        (user_id, course_id, total_topics, completed_topics, progress_percent)
        VALUES (?, ?, ?, 0, 0)
        ");

        $insertProgress->bind_param("iii", $user_id, $course_id, $total_topics);
        $insertProgress->execute();
    }
}

// 🔥 redirect to course page
switch($course_id){
    case 1:
        header("Location: /eduspring/courses/Python_Courses/python_programming_course_overview.php");
        break;
    case 2:
        header("Location: /eduspring/courses/Java_Courses/java_programming_course_overview.php");
        break;
    case 3:
        header("Location: /eduspring/courses/Full-Stack_Courses/fullstack_course_overview.php");
        break;
    default:
        header("Location: /eduspring/courses.php");
}
exit();
?>