<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learnify - About Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: #f4f7fb;
            scroll-behavior: smooth;
            overflow-x: hidden;
        }
        
        /* MOBILE MENU TOGGLE */
        .menu-toggle {
            display: none;
            flex-direction: column;
            cursor: pointer;
            gap: 5px;
        }
        .menu-toggle span {
            width: 25px;
            height: 3px;
            background: white;
            border-radius: 5px;
            transition: 0.3s;
        }
        
        /* NAV BUTTONS */
        .btn {
            background: #22c1c3;
            color: white;
            padding: 10px 20px;
            border-radius: 30px;
            transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .btn:hover {
            background: white;
            color: #0f172a;
            transform: scale(1.1);
        }
        
        /* HERO SECTION */
.hero {
    min-height: calc(60vh - 70px);
    padding: 100px 10% 0;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    background: linear-gradient(-45deg, #0f172a, #134e5e, #22c1c3, #0f172a);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}
        
.hero h1 {
    font-size: clamp(36px, 6vw, 56px);
    color: white;
    margin-bottom: 20px;

    white-space: nowrap;
    overflow: hidden;
    border-right: 3px solid #22c1c3;

    animation: typing 3s steps(30, end), blink 0.7s infinite;
    text-shadow: 0 0 10px #22c1c3, 0 0 20px #22c1c3;
}

@keyframes typing {
    from { width: 0 }
    to { width: 100% }
}

@keyframes blink {
    50% { border-color: transparent }
}

        .hero p {
            width: 100%;
            max-width: 800px;
            font-size: 20px;
            color: #e2e8f0;
            line-height: 1.6;
            opacity: 0;
            transform: translateY(40px);
            animation: fadeUp 1s ease forwards 0.3s;
        }
        
        @keyframes fadeUp {
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* GENERAL SECTIONS */
        section { padding: 90px 8%; text-align: center; }
        .alt { background: white; }
        
        h2 {
            font-size: 36px;
            color: #0f172a;
            margin-bottom: 30px;
            position: relative;
            display: inline-block;
        }
        h2::after {
            content: '';
            position: absolute;
            width: 60%;
            height: 4px;
            background: #22c1c3;
            bottom: -10px;
            left: 20%;
            border-radius: 2px;
        }
        .section-desc {
            max-width: 800px;
            margin: 0 auto 60px auto;
            color: #475569;
            font-size: 18px;
            line-height: 1.7;
        }
        
        /* STORY / MISSION SECTION */
        .story-container {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 50px;
            text-align: left;
        }
        .story-text { flex: 1; min-width: 300px; }
        .story-text p {
            color: #475569;
            font-size: 18px;
            line-height: 1.8;
            margin-bottom: 20px;
        }
        .story-image { 
            flex: 1; 
            min-width: 300px; 
            display: flex; 
            justify-content: center;
        }
        .story-image .blob {
            width: 350px;
            height: 350px;
            background: linear-gradient(135deg, #22c1c3, #134e5e);
            border-radius: 40% 60% 70% 30% / 40% 50% 60% 50%;
            animation: morph 8s ease-in-out infinite alternate;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 100px;
            box-shadow: 0 20px 50px rgba(34, 193, 195, 0.3);
        }
        @keyframes morph {
            0% { border-radius: 40% 60% 70% 30% / 40% 50% 60% 50%; }
            100% { border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%; transform: translateY(-15px); }
        }
        
        /* FEATURES CARDS */
        .cards {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 30px;
        }
        .card {
            background: white;
            padding: 40px 30px;
            width: 100%;
            max-width: 340px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-sizing: border-box;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: linear-gradient(135deg, #134e5e, #22c1c3);
            z-index: -1;
            transform: scaleY(0);
            transform-origin: bottom;
            transition: transform 0.4s ease;
            border-radius: 20px;
        }
        .card:hover::before { transform: scaleY(1); }
        .card:hover { transform: translateY(-15px); box-shadow: 0 20px 40px rgba(34, 193, 195, 0.2); }
        .card:hover h3, .card:hover p, .card:hover .icon { color: white; }
        
.card .icon {
    font-size: 50px;
    color: #22c1c3;
    margin-bottom: 20px;
    transition: all 0.4s ease;
}

.card:hover .icon {
    transform: scale(1.3);
    text-shadow: 0 0 10px #22c1c3, 0 0 20px #22c1c3;
}
        .card h3 { color: #0f172a; font-size: 22px; margin-bottom: 15px; transition: 0.4s; }
        .card p { color: #64748b; font-size: 16px; line-height: 1.6; margin: 0; transition: 0.4s; }
        
        /* STATS STRIP */
        .stats-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 30px;
            margin-top: 60px;
            padding: 50px 20px;
            background: #0f172a;
            border-radius: 24px;
            color: white;
            box-shadow: 0 20px 40px rgba(15, 23, 42, 0.3);
        }
        .stat-box h3 { color: #22c1c3; font-size: 48px; margin: 0 0 10px 0; }
        .stat-box h3::after { display: none; }
        .stat-box p { font-size: 16px; color: #94a3b8; margin: 0; font-weight: 600; letter-spacing: 1px;}
        
        /* SCROLL ANIMATION CLASSES */
        .hidden-up { opacity: 0; transform: translateY(60px); transition: opacity 0.8s ease, transform 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .hidden-left { opacity: 0; transform: translateX(-60px); transition: opacity 0.8s ease, transform 0.8s ease-out; }
        .hidden-right { opacity: 0; transform: translateX(60px); transition: opacity 0.8s ease, transform 0.8s ease-out; }
        .show { opacity: 1; transform: translate(0,0); }
        
        /* CTA SECTION */
        .cta {
            background: linear-gradient(120deg, #134e5e, #22c1c3);
            color: white;
            padding: 100px 8%;
        }
        .cta h2 { color: white; margin-bottom: 40px; }
        .cta h2::after { display: none; }
        
        .pulse-btn {
            padding: 18px 45px;
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
            background: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            box-shadow: 0 0 0 0 rgba(255, 255, 255, 0.7);
            animation: pulse 2s infinite cubic-bezier(0.66, 0, 0, 1);
            transition: 0.3s;
        }
        .pulse-btn:hover {
            transform: scale(1.05);
            color: #22c1c3;
            animation: none;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }
        @keyframes pulse {
            to { box-shadow: 0 0 0 20px rgba(255, 255, 255, 0); }
        }
        
.cards .card {
    opacity: 0;
    transform: translateY(40px);
    animation: cardFade 0.8s ease forwards;
}

.cards .card:nth-child(1){ animation-delay: 0.2s; }
.cards .card:nth-child(2){ animation-delay: 0.4s; }
.cards .card:nth-child(3){ animation-delay: 0.6s; }
.cards .card:nth-child(4){ animation-delay: 0.8s; }
.cards .card:nth-child(5){ animation-delay: 1s; }
.cards .card:nth-child(6){ animation-delay: 1.2s; }

@keyframes cardFade {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.card {
    transform-style: preserve-3d;
    perspective: 1000px;
}

        /* FOOTER */
        footer {
            background: #0f172a;
            color: #94a3b8;
            text-align: center;
            padding: 40px;
            font-size: 15px;
        }
        footer a { color: #22c1c3; text-decoration: none; font-weight: 600; }
        
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

    <div class="hero">
        <h1>Revolutionizing Digital Education</h1>
        <p>
            We blend cutting-edge cloud infrastructure with expertly crafted curriculums to deliver a seamless, globally scalable, and secure learning experience for the modern developer.
        </p>
    </div>

    <section class="alt">
        <h2 class="hidden-up">Our Mission</h2>
        <p class="section-desc hidden-up" style="transition-delay: 0.1s;">
            Learnify was built to bridge the gap between traditional learning and modern industry demands. By utilizing cloud-native environments, we ensure that technical education is accessible, structured, and verifiable everywhere.
        </p>
        <div class="story-container">
            <div class="story-text hidden-left" style="transition-delay: 0.2s;">
                <p><strong>Cloud-Powered Availability:</strong> Hosted entirely on Amazon AWS, Learnify ensures near 100% uptime, fast content delivery networks, and cross-device syncing.</p>
                <p><strong>Cost-Effective Innovation:</strong> By leveraging serverless architectures and smart databases (Amazon RDS), we keep operational costs low and pass the value directly to our learners.</p>
                <p><strong>Trust & Security:</strong> Your data and progress are protected with strict IAM access controls, ensuring that your automated certifications remain tamper-proof and verifiable by employers globally.</p>
            </div>
            <div class="story-image hidden-right" style="transition-delay: 0.4s;">
                <div class="blob">
                    <i class="fas fa-graduation-cap"></i>
                </div>
            </div>
        </div>
    </section>

    <section>
        <h2 class="hidden-up">The Learnify Advantage</h2>
        <p class="section-desc hidden-up" style="transition-delay: 0.1s;">Experience a platform engineered from the ground up to support continuous learning, practical assessments, and verifiable achievements.</p>
        
        <div class="cards">
            <div class="card hidden-up" style="transition-delay: 0.1s;">
                <i class="fas fa-layer-group icon"></i>
                <h3>Structured Paths</h3>
                <p>Curated curriculums with logical progression, taking you from fundamentals to advanced concepts without the guesswork.</p>
            </div>
            <div class="card hidden-up" style="transition-delay: 0.2s;">
                <i class="fas fa-certificate icon"></i>
                <h3>Auto-Certification</h3>
                <p>Pass your final assessments and instantly generate verifiable digital certificates safely stored in the cloud.</p>
            </div>
            <div class="card hidden-up" style="transition-delay: 0.3s;">
                <i class="fas fa-tasks icon"></i>
                <h3>Real-time Quizzes</h3>
                <p>Test your knowledge immediately with interactive assessments that reinforce memory retention and skill application.</p>
            </div>
            <div class="card hidden-up" style="transition-delay: 0.4s;">
                <i class="fas fa-mobile-alt icon"></i>
                <h3>Cross-device Sync</h3>
                <p>Start a module on your phone during a commute and seamlessly resume exactly where you left off on your desktop.</p>
            </div>
            <div class="card hidden-up" style="transition-delay: 0.5s;">
                <i class="fas fa-shield-alt icon"></i>
                <h3>Secure Storage</h3>
                <p>Robust database management and encrypted connections ensure your personal progress and data remain strictly private.</p>
            </div>
            <div class="card hidden-up" style="transition-delay: 0.6s;">
                <i class="fab fa-aws icon"></i>
                <h3>Scalable System</h3>
                <p>No more crashing servers during peak times. Our elastic infrastructure adapts dynamically to traffic demands.</p>
            </div>
        </div>

        <div class="stats-container hidden-up" style="transition-delay: 0.3s;">
            <div class="stat-box">
                <h3>1M+</h3>
                <p>Active Learners</p>
            </div>
            <div class="stat-box">
                <h3>500k+</h3>
                <p>Certifications</p>
            </div>
            <div class="stat-box">
                <h3>99.9%</h3>
                <p>Platform Uptime</p>
            </div>
            <div class="stat-box">
                <h3>150+</h3>
                <p>Countries Reached</p>
            </div>
        </div>
    </section>

    <section class="cta">
        <h2 class="hidden-up">Ready to Transform Your Career?</h2>
        <button class="pulse-btn hidden-up" onclick="location.href='signup.php'" style="transition-delay: 0.2s;">
            Create Your Free Account
        </button>
    </section>

    <footer>
        © 2026 Learnify | Cloud Learning Platform <br>
        Need help? Contact us at <a href="mailto:support@learnify.com">support@learnify.com</a>
    </footer>

    <script>
        // Scroll Animation Logic
        const observerOptions = {
            threshold: 0.15,
            rootMargin: "0px 0px -50px 0px"
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("show");
                    // Optional: Unobserve after animating if you only want it to animate once
                    // observer.unobserve(entry.target); 
                }
            });
        }, observerOptions);

        document.querySelectorAll(".hidden-up, .hidden-left, .hidden-right").forEach(el => {
            observer.observe(el);
        });

        // Mobile Menu Logic
        const menuToggle = document.getElementById('mobile-menu');
        const navList = document.getElementById('nav-list');
        
        menuToggle.addEventListener('click', () => {
            navList.classList.toggle('active');
        });

        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', () => {
                navList.classList.remove('active');
            });
        });

// CARD TILT EFFECT
document.querySelectorAll(".card").forEach(card => {
    card.addEventListener("mousemove", (e) => {
        let rect = card.getBoundingClientRect();
        let x = e.clientX - rect.left;
        let y = e.clientY - rect.top;

        let centerX = rect.width / 2;
        let centerY = rect.height / 2;

        let rotateX = -(y - centerY) / 10;
        let rotateY = (x - centerX) / 10;

        card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05)`;
    });

    card.addEventListener("mouseleave", () => {
        card.style.transform = "rotateX(0) rotateY(0) scale(1)";
    });
});

    </script>
</body>
</html>