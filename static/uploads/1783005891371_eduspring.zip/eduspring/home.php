<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learnify</title>

<style>
body{
    margin:0;
    padding: 0;
    font-family:'Segoe UI',sans-serif;
    background:#f4f7fb;
    scroll-behavior:smooth;
    overflow-x: hidden;
}

/* NAV BUTTONS */
.btn{
    background:#22c1c3;
    color:white;
    padding:10px 20px;
    border-radius:30px;
    transition:0.3s;
}
.btn:hover{
    background:white;
    color:#0f172a;
    transform:scale(1.1);
}
/* HERO */
.hero{
    min-height: calc(70vh - 50px);
    padding: 10px 10% 0;

    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items:center;
    text-align:center;

    background: linear-gradient(-45deg, #0f172a, #134e5e, #22c1c3, #0f172a);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove{
    0%{background-position:0% 50%;}
    50%{background-position:100% 50%;}
    100%{background-position:0% 50%;}
}

.hero h1{
    font-size: clamp(32px, 8vw, 52px);
    color:white;

    white-space: nowrap;
    overflow: hidden;
    border-right: 3px solid #22c1c3;

    animation: typing 3s steps(25), blink 0.7s infinite;
    text-shadow: 0 0 10px #22c1c3, 0 0 20px #22c1c3;
}

@keyframes typing{
    from{width:0}
    to{width:100%}
}

@keyframes blink{
    50%{border-color:transparent}
}

.hero p{
    width: 100%;
    max-width: 700px;
    font-size:18px;
    color:white;
    opacity:0;
    transform:translateY(40px);
    animation:fadeUp 1.2s ease forwards;
    animation-delay:.3s;
}
@keyframes fadeUp{
    to{
        opacity:1;
        transform:translateY(0);
    }
}
.hero-buttons{
    display:flex;
    flex-wrap: wrap;
    justify-content: center;
    gap:20px;
    margin-top:20px;
}
button{
    padding:15px 35px;
    border:none;
    border-radius:50px;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;

    position: relative;
    overflow: hidden;
}

button::before{
    content:"";
    position:absolute;
    top:0;
    left:-100%;
    width:100%;
    height:100%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
    transition:0.5s;
}

button:hover::before{
    left:100%;
}
.signup,.signin,.signupend{
    background:white;
    color:black;
}
button:hover{
    transform:scale(1.1);
    background:#22c1c3;
    color:white;
}
/* SECTIONS */
section{
    padding: 60px 8%;
    text-align:center;
}
.alt{background:white;}
h2{
    font-size:30px;
    color:#0f172a;
}
/* CARDS */
.cards{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:20px;
}
.card{
    background:white;
    padding:25px;
    width: 100%;
    max-width: 280px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
    transition:0.3s;
    font-weight:600;
    color:#0f172a;
    box-sizing: border-box;
}
.card:hover{
    background:#22c1c3;
    color:white;
    transform:translateY(-10px);
}
/* SCROLL ANIMATION */
.hidden{
    opacity:0;
    transform:translateY(50px);
    transition:1s;
}
.show{
    opacity:1;
    transform:translateY(0);
}
/* CTA */
.cta{
    background:linear-gradient(120deg,#134e5e,#22c1c3);
    color:white;
}
/* FOOTER */
footer{
    background:#0f172a;
    color:white;
    text-align:center;
    padding:40px;
}
/* MOBILE RESPONSIVE QUERIES */

    .menu-toggle {
        display: flex;
    }


    nav.active {
        display: flex;
    }

    .btn {
        width: 80%;
        text-align: center;
    }

</style>
</head>
<body>
<?php
include 'navbar.php';
?>
<div class="hero">
    <h1>Learn Without Limits</h1>
    <p>
        Learnify is a cloud-powered platform where students
        learn, take assessments, and earn certifications
        from anywhere in the world.
    </p>
<div class="hero-buttons">

<button class="signup" onclick="location.href='signup.php'">Get Started</button>
<button class="signin" onclick="location.href='signin.php'">Login</button>

</div>
</div>
<section class="hidden alt">
    <h2>About Learnify</h2>
    <p>
        Learnify delivers structured online education using
        cloud technology.
    </p>
</section>
<section class="hidden">
    <h2>Popular Courses</h2>
    <div class="cards">
        <div class="card">💻 Web Development</div>
        <div class="card">☁️ Cloud Computing</div>
        <div class="card">📊 Data Science</div>
        <div class="card">🤖 AI & Machine Learning</div>
        <div class="card">📱 App Development</div>
        <div class="card">🔐 Cyber Security</div>
    </div>
</section>
<section class="hidden alt">
    <h2>Platform Features</h2>
    <div class="cards">
        <div class="card">📚 Structured Courses</div>
        <div class="card">📜 Auto Certification</div>
        <div class="card">📈 Progress Tracking</div>
        <div class="card">🔒 Secure Storage</div>
        <div class="card">⚡ Scalable System</div>
        <div class="card">😊 Easy Interface</div>
    </div>
</section>
<section class="cta hidden">
    <h2>Start Your Learning Journey Today</h2>
    <button class="signupend" onclick="location.href='signup.php'">
        Join Learnify
    </button>
</section>
<footer>
    © 2026 Learnify | Cloud Learning Platform  
    <br>support@learnify.com
</footer>
<script>
const observer = new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
        if(entry.isIntersecting){
            entry.target.classList.add("show");
        }
    });
});
document.querySelectorAll(".hidden").forEach(el=>observer.observe(el));

</script>
</body>
</html>