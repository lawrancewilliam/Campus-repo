<?php
include 'db.php';

// ✅ GET VALUES
$type  = $_GET['type'] ?? '';
$value = $_GET['value'] ?? '';
$current = $_GET['current'] ?? ''; // current logged user email

// ✅ CLEAN INPUT
$type = strtolower(trim($type));
$value = trim($value);

// 🔥 ALLOWED FIELDS
$allowed = ["username", "email", "phone"];

if (!in_array($type, $allowed)) {
    echo "invalid";
    exit();
}

// ❌ EMPTY VALUE
if ($value === "") {
    echo "";
    exit();
}

// 🔥 GET CURRENT USER ID
$current_id = 0;

if($current != ""){
    $stmtUser = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmtUser->bind_param("s", $current);
    $stmtUser->execute();
    $resUser = $stmtUser->get_result();

    if($resUser->num_rows > 0){
        $user = $resUser->fetch_assoc();
        $current_id = $user['id'];
    }
}

// 🔥 MAIN QUERY (IGNORE CURRENT USER)
$sql = "SELECT id FROM users WHERE $type = ? AND id != ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo "error";
    exit();
}

$stmt->bind_param("si", $value, $current_id);
$stmt->execute();
$result = $stmt->get_result();

// ✅ OUTPUT
if ($result->num_rows > 0) {
    echo "exists";     // ❌ already used by others
} else {
    echo "available";  // ✅ free or own value
}

$stmt->close();
$conn->close();
?>