<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB connection failed");
}

// User email from session
$user_email = $_SESSION['user_email'];

// Fetch user details
$stmt = $conn->prepare("SELECT fname, lname, email, phone, bio, profile_pic FROM users WHERE email=?");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// ✅ ADD THIS
$user_id_query = $conn->prepare("SELECT id FROM users WHERE email=?");
$user_id_query->bind_param("s", $user_email);
$user_id_query->execute();
$res_id = $user_id_query->get_result();
$user_row = $res_id->fetch_assoc();

$user_id = $user_row['id'];

// 🔥 Get enrolled courses
$enrollQuery = $conn->prepare("
SELECT c.id, c.course_name, c.slug,
IFNULL(cp.progress_percent, 0) AS progress 
FROM enrollments e
JOIN courses c ON e.course_id = c.id
LEFT JOIN course_progress cp 
ON cp.course_id = c.id AND cp.user_id = e.user_id
WHERE e.user_id=?
");

$enrollQuery->bind_param("i", $user_id);
$enrollQuery->execute();
$enrolledCourses = $enrollQuery->get_result();

// 🔥 Get completed courses (progress 100%)
$completedQuery = $conn->prepare("
SELECT cp.course_id, c.course_name 
FROM course_progress cp
JOIN courses c ON cp.course_id = c.id
WHERE cp.user_id=? AND cp.progress_percent=100
");
$completedQuery->bind_param("i", $user_id);
$completedQuery->execute();
$completedCourses = $completedQuery->get_result();

// 🔥 Get certificates
$certQuery = $conn->prepare("
SELECT c.course_name, cert.certificate_url 
FROM certificates cert
JOIN courses c ON cert.course_id = c.id
WHERE cert.user_id=?
");
$certQuery->bind_param("i", $user_id);
$certQuery->execute();
$certificates = $certQuery->get_result();

// 🔥 Counts
$totalCourses = $enrolledCourses->num_rows;
$totalCerts = $certificates->num_rows;

// Format name properly
$fullName = ucwords(strtolower($user['fname'] . " " . $user['lname']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learnify - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .text-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .bg-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
        }
        
        .btn-vibrant {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            transition: all 0.3s ease;
        }
        
        .btn-vibrant:hover {
            background: linear-gradient(135deg, #2563eb 0%, #7c3aed 100%);
            box-shadow: 0 4px 14px 0 rgba(139, 92, 246, 0.39);
            transform: translateY(-1px);
        }
        
        .glass-tag {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .bg-java { background: linear-gradient(135deg, #f59e0b, #ea580c); }
        .bg-python { background: linear-gradient(135deg, #10b981, #047857); }
        .bg-fullstack { background: linear-gradient(135deg, #4f46e5, #7c3aed); }

        #modalImg {
    transition: transform 0.3s ease;
}
#modalImg:hover {
    transform: scale(1.05);
}
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

<?php include 'navbar.php'; ?>

<div id="toast"
style="position:fixed;
top:20px;
left:50%;
transform:translateX(-50%);
padding:14px 20px;
border-radius:10px;
color:white;
font-weight:bold;
display:none;
z-index:999;">
</div>

    <!-- Hero / Profile Banner -->
    <section class="relative bg-slate-900 pt-20 pb-32 overflow-hidden">
        <!-- Decorative background blobs -->
        <div class="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        
        <div class="container mx-auto px-4 relative z-10">
            <div class="flex flex-col md:flex-row items-center gap-8">
                <!-- Profile Avatar -->
                <div class="relative group">
                    <div class="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-slate-800 overflow-hidden bg-slate-800 flex items-center justify-center shadow-[0_0_40px_rgba(59,130,246,0.3)]">
<img 
id="profileImage"
src="<?php echo $user['profile_pic'] ? 'uploads/'.$user['profile_pic'] : 'https://ui-avatars.com/api/?name='.urlencode($fullName); ?>" 
class="w-full h-full object-cover cursor-pointer">
                    </div>
                    <a href="profile_settings.php" class="absolute bottom-2 right-2 w-10 h-10 bg-blue-500 rounded-full text-white flex items-center justify-center hover:bg-blue-600 transition shadow-lg border-2 border-slate-900">
                        <i class="fas fa-camera"></i>
                    </a>
                </div>
                
                <!-- Profile Info -->
                <div class="text-center md:text-left flex-1">
                    <h1 class="text-3xl md:text-5xl font-extrabold text-white mb-2 tracking-tight" id="profileName"><?php echo htmlspecialchars($fullName); ?></h1>
                    <p class="text-blue-400 text-lg font-medium mb-4 flex items-center justify-center md:justify-start gap-2">
                        <i class="fas fa-check-circle text-blue-500"></i> Verified Learner
                    </p>
                    <div class="flex flex-wrap items-center justify-center md:justify-start gap-3 text-sm font-semibold text-slate-300">
                        <span class="glass-tag px-4 py-2 rounded-full text-white flex items-center shadow-sm"><i class="fas fa-map-marker-alt mr-2 text-blue-400"></i> Global Cloud Node</span>
                        <span class="glass-tag px-4 py-2 rounded-full text-white flex items-center shadow-sm"><i class="fas fa-calendar-alt mr-2 text-purple-400"></i> Active Member</span>
                    </div>
                </div>
                
                <!-- Quick Stats Box -->
                <div class="flex gap-4 w-full md:w-auto justify-center md:justify-end mt-6 md:mt-0">
                    <div class="bg-white/5 border border-white/10 rounded-2xl p-5 text-center min-w-[110px] backdrop-blur-md shadow-xl hover:bg-white/10 transition-colors cursor-default">
                        <div class="text-4xl font-bold text-white mb-1" id="statCompleted"><?php echo $totalCourses; ?></div>
                        <div class="text-xs text-slate-400 uppercase tracking-wider font-bold">Courses</div>
                    </div>
                    <div class="bg-white/5 border border-white/10 rounded-2xl p-5 text-center min-w-[110px] backdrop-blur-md shadow-xl hover:bg-white/10 transition-colors cursor-default">
                        <div class="text-4xl font-bold text-white mb-1" id="statCerts"><?php echo $totalCerts; ?></div>
                        <div class="text-xs text-slate-400 uppercase tracking-wider font-bold">Certificates</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <main class="container mx-auto px-4 -mt-20 relative z-20 pb-16 flex-1">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <!-- Left Column: Details & Unique Frames -->
            <div class="space-y-8">
                <!-- Personal Details Frame -->
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-8">
                    <div class="flex items-center justify-between mb-6 border-b border-gray-50 pb-4">
                        <h3 class="text-xl font-bold text-gray-900">Personal Details</h3>
                        <a href="profile_settings.php" class="text-blue-500 hover:text-blue-700 text-sm font-semibold transition bg-blue-50 px-3 py-1.5 rounded-lg"><i class="fas fa-edit mr-1"></i> Edit</a>
                    </div>
                    <ul class="space-y-6 text-sm">
                        <li class="flex items-start">
                            <div class="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center shrink-0 mr-4">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div>
                                <p class="text-gray-400 font-medium mb-0.5 text-xs uppercase tracking-wider">Email Address</p>
                                <p class="text-gray-900 font-semibold text-base" id="profileEmail"><?php echo htmlspecialchars($user['email']); ?></p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <div class="w-10 h-10 rounded-full bg-purple-50 text-purple-500 flex items-center justify-center shrink-0 mr-4">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div>
                                <p class="text-gray-400 font-medium mb-0.5 text-xs uppercase tracking-wider">Phone Number</p>
                                <p class="text-gray-900 font-semibold text-base" id="profilePhone"><?php echo htmlspecialchars($user['phone']); ?></p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <div class="w-10 h-10 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center shrink-0 mr-4">
                                <i class="fas fa-bullseye"></i>
                            </div>
                            <div>
                                <p class="text-gray-400 font-medium mb-0.5 text-xs uppercase tracking-wider">Learning Goal</p>
                                <p class="text-gray-900 font-semibold text-base" id="profileBio"><?php echo htmlspecialchars($user['bio']); ?></p>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Skills Radar / Badges Frame -->
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-8">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 border-b border-gray-50 pb-4">Acquired Skills</h3>
                    <div class="flex flex-wrap gap-2" id="skillsContainer">
                        <!-- Populated dynamically -->
                    </div>
                </div>
            </div>

            <!-- Right Column: Courses & Certificates -->
            <div class="lg:col-span-2 space-y-8">
                
                <!-- Courses in Progress Frame -->
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-8">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-3 border-b border-gray-50 pb-4">
                        <div class="w-8 h-8 rounded-full bg-blue-100 text-blue-500 flex items-center justify-center text-sm"><i class="fas fa-spinner animate-spin-slow"></i></div>
                        In Progress
                    </h3>
                    <div class="space-y-4" id="inProgressContainer">
<?php if($enrolledCourses->num_rows > 0): ?>

    <?php while($course = $enrolledCourses->fetch_assoc()): ?>

        <?php
$slug = $course['slug'];

if($slug == "python"){
    $path = "courses/Python_Courses/python_programming_course_overview.php";
}
elseif($slug == "java"){
    $path = "courses/Java_Courses/java_programming_course_overview.php";
}
elseif($slug == "fullstack"){
    $path = "courses/Full-Stack_Courses/fullstack_course_overview.php";
}
?>

<a href="<?php echo $path; ?>">

        <div class="flex items-center gap-5 p-5 rounded-2xl border hover:shadow-md transition bg-white">

            <!-- Icon -->
            <?php
            $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/code/code-original.svg";

            if(stripos($course['course_name'], 'python') !== false){
                $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg";
            }
            elseif(stripos($course['course_name'], 'java') !== false){
                $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg";
            }
            elseif(stripos($course['course_name'], 'full') !== false){
                $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg";
            }
            ?>

            <div class="w-14 h-14 rounded-xl bg-white flex items-center justify-center shadow">
                <img src="<?php echo $icon; ?>" class="w-10 h-10 object-contain">
            </div>

            <!-- Content -->
            <div class="flex-1">
                <div class="flex justify-between items-center mb-2">
                    <h4 class="font-bold text-gray-800">
                        <?php echo $course['course_name']; ?>
                    </h4>

                    <span class="text-sm font-bold text-blue-600">
                        <?php echo $course['progress']; ?>%
                    </span>
                </div>

                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div class="bg-orange-500 h-2 rounded-full"
                         style="width: <?php echo $course['progress']; ?>%">
                    </div>
                </div>
            </div>

        </div>

        </a>

    <?php endwhile; ?>

<?php else: ?>

<p class="text-gray-500 text-center py-10 bg-gray-50 rounded-xl border border-dashed">
    No courses in progress
</p>

<?php endif; ?>
                        <!-- Dynamic items here -->
                    </div>
                </div>

                <!-- Completed Courses & Certificates Frame -->
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 p-8">
                    <h3 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-3 border-b border-gray-50 pb-4">
                        <div class="w-8 h-8 rounded-full bg-yellow-100 text-yellow-500 flex items-center justify-center text-sm"><i class="fas fa-award"></i></div>
                        Completed & Certificates
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5" id="completedContainer">
                        <?php if($certificates->num_rows > 0): ?>
    <?php while($cert = $certificates->fetch_assoc()): ?>
<div class="border rounded-2xl p-6 shadow-sm hover:shadow-lg transition bg-white flex flex-col justify-between">

    <div class="flex items-center gap-3 mb-4">
<div class="w-14 h-14 rounded-xl bg-white flex items-center justify-center shadow">

    <?php
$icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/code/code-original.svg";

if(stripos($cert['course_name'], 'python') !== false){
    $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg";
}
elseif(stripos($cert['course_name'], 'java') !== false){
    $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg";
}
elseif(stripos($cert['course_name'], 'full') !== false){
    $icon = "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg";
}
?>

<img src="<?php echo $icon; ?>" class="w-10 h-10 object-contain">

</div>
        <h4 class="font-bold text-gray-800">
            <?php echo $cert['course_name']; ?>
        </h4>
    </div>

    <?php
$certPath = "";

if(stripos($cert['course_name'], 'python') !== false){
    $certPath = "courses/Python_Courses/";
}
elseif(stripos($cert['course_name'], 'java') !== false){
    $certPath = "courses/Java_Courses/";
}
elseif(stripos($cert['course_name'], 'full') !== false){
    $certPath = "courses/Full-Stack_Courses/";
}
?>

<a href="<?php echo $certPath . $cert['certificate_url']; ?>" 
       class="mt-auto bg-gradient-to-r from-blue-500 to-purple-600 text-white text-center py-2 rounded-lg font-bold hover:opacity-90">
        View Certificate
    </a>

</div>
    <?php endwhile; ?>
<?php else: ?>
    <p class="col-span-full text-gray-500 text-center py-10 bg-gray-50 rounded-xl border border-dashed">
    No completed courses yet
</p>
<?php endif; ?>
                        <!-- Dynamic items here -->
                    </div>
                </div>

            </div>
        </div>
    </main>

    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 mt-auto text-center">
        <div class="container mx-auto px-4">
            <p class="text-sm">© 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {

        // 🔥 PROFILE IMAGE CLICK PREVIEW
const profileImage = document.getElementById("profileImage");
const modal = document.getElementById("imageModal");
const modalImg = document.getElementById("modalImg");
const closeModal = document.getElementById("closeModal");

profileImage.addEventListener("click", () => {
    modal.classList.remove("hidden");
modal.classList.add("flex");
    modalImg.src = profileImage.src;
});

closeModal.addEventListener("click", () => {
    modal.classList.add("hidden");
modal.classList.remove("flex");
});

// click outside image close
modal.addEventListener("click", (e) => {
    if(e.target === modal){
        modal.classList.add("hidden");
modal.classList.remove("flex");
    }
});
            
            document.getElementById('profileName').textContent = userName;
            document.getElementById('profileEmail').textContent = userEmail;
            document.getElementById('profilePhone').textContent = userPhone;
            document.getElementById('profileBio').textContent = userBio;
            
            // Auto-generate avatar based on name
            const encodedName = encodeURIComponent(userName);
            document.getElementById('profileAvatar').src = `https://ui-avatars.com/api/?name=${encodedName}&background=3b82f6&color=fff&size=150&bold=true`;

            let completedCount = 0;
            let certCount = 0;
            let inProgressCount = 0;
            
            const inProgressContainer = document.getElementById('inProgressContainer');
            const completedContainer = document.getElementById('completedContainer');
            const skillsContainer = document.getElementById('skillsContainer');
            
            let acquiredSkills = new Set();

            // Handle Empty States
            if (inProgressCount === 0) {
                document.getElementById('noInProgress').classList.remove('hidden');
            }
            if (completedCount === 0) {
                document.getElementById('noCompleted').classList.remove('hidden');
            }

            // Populate Skills Radar
            if (acquiredSkills.size > 0) {
                acquiredSkills.forEach(skill => {
                    const skillHTML = `<span class="px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-colors cursor-default shadow-sm">${skill}</span>`;
                    skillsContainer.insertAdjacentHTML('beforeend', skillHTML);
                });
            } else {
                skillsContainer.innerHTML = '<p class="text-sm text-gray-500 font-medium">Complete courses and earn certificates to unlock skills on your profile.</p>';
            }
        });

        const urlParams = new URLSearchParams(window.location.search);
const status = urlParams.get("status");

const toast = document.getElementById("toast");

if(status){

toast.style.display = "block";

if(status === "success"){
    toast.innerHTML = "✅ Profile Updated Successfully";
    toast.style.background = "green";
}
else if(status === "error"){
    toast.innerHTML = "❌ Update Failed";
    toast.style.background = "red";
}
else if(status === "duplicate"){
    toast.innerHTML = "❌ Username / Email / Phone already taken";
    toast.style.background = "red";
}

setTimeout(()=>{
    toast.style.display = "none";
},3000);

}

    </script>

<!-- 🔥 IMAGE PREVIEW MODAL -->
<div id="imageModal" class="fixed inset-0 bg-black bg-opacity-80 hidden items-center justify-center z-50">
    
    <span id="closeModal" class="absolute top-5 right-8 text-white text-4xl cursor-pointer">&times;</span>
    
    <img id="modalImg" class="max-w-[90%] max-h-[90%] rounded-xl shadow-2xl">

</div>

</body>
</html>