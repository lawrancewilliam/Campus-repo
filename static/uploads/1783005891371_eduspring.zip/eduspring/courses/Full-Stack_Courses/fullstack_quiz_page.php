<?php

session_start();

if(!isset($_SESSION['user_email'])){
    header("Location: ../../signin.php");
    exit();
}

include("../../db.php");

$email = $_SESSION['user_email'];

$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$resUser = $getUser->get_result();
$user = $resUser->fetch_assoc();

$user_id = $user['id'];

$slug = "fullstack";

$stmt = $conn->prepare("SELECT id FROM courses WHERE slug=?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$res = $stmt->get_result();
$course = $res->fetch_assoc();

$course_id = $course['id'];

$check = $conn->prepare("SELECT * FROM quiz_results WHERE user_id=? AND course_id=? AND passed=1");
$check->bind_param("ii", $user_id, $course_id);
$check->execute();
$resCheck = $check->get_result();

$already_done = $resCheck->num_rows > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full-Stack Web Development Quiz</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #4f46e5; 
            --secondary-color: #ec4899; 
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-color: #f3f4f6;
            --dark-color: #1f2937;
            --text-color: #374151;
            --border-color: #e5e7eb;
            --shadow: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 30px rgba(0,0,0,0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* Top Header Bar */
        .top-header {
            background: white;
            padding: 1rem 2rem;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .test-info {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .test-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .test-details {
            display: flex;
            gap: 1.5rem;
            font-size: 0.9rem;
        }

        .test-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
        }

        .test-detail i {
            color: var(--primary-color);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        #timer {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--light-color);
            border-radius: 20px;
            font-weight: bold;
        }

        #timer.warning {
            background: #fef3c7;
            color: #b45309;
        }

        #timer.danger {
            background: #fee2e2;
            color: #b91c1c;
        }

        .help-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s;
        }

        .help-btn:hover {
            transform: scale(1.1);
        }

        /* Main Content Area */
        .main-container {
            flex: 1;
            display: flex;
            padding: 2rem;
            gap: 2rem;
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
        }

        /* Question Area */
        .question-area {
            flex: 1;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .question-number {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .question-type {
            background: var(--primary-color);
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }

        .question-text {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 2rem;
            color: var(--dark-color);
        }

        .answers-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .answer-option {
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .answer-option:hover {
            border-color: var(--primary-color);
            background: #eef2ff;
            transform: translateX(5px);
        }

        .answer-option.selected {
            border-color: var(--primary-color);
            background: #e0e7ff;
        }

        .answer-marker {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: var(--light-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: var(--primary-color);
        }

        .answer-option.selected .answer-marker {
            background: var(--primary-color);
            color: white;
        }

        .answer-text {
            flex: 1;
        }

        /* Input Styles */
        .fill-blank-input, .code-input {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        .fill-blank-input:focus, .code-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .code-input {
            min-height: 200px;
            font-family: 'Courier New', monospace;
            resize: vertical;
        }

        /* Rearrange Container */
        .rearrange-container {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .rearrange-item {
            padding: 1rem;
            background: var(--light-color);
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 2px solid transparent;
            transition: all 0.3s;
        }

        .rearrange-item:hover {
            border-color: var(--primary-color);
        }

        .rearrange-controls {
            display: flex;
            gap: 0.5rem;
        }

        .rearrange-controls button {
            width: 30px;
            height: 30px;
            border: none;
            background: var(--primary-color);
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .rearrange-controls button:hover:not(:disabled) {
            background: #4338ca;
        }

        .rearrange-controls button:disabled {
            background: #d1d5db;
            cursor: not-allowed;
        }

        /* Right Sidebar - Question Navigator */
        .right-sidebar {
            width: 280px;
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .navigator-title {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 1rem;
            color: var(--dark-color);
            text-align: center;
        }

        .navigator-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .nav-item {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--light-color);
            border: 2px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-item:hover {
            border-color: var(--primary-color);
            transform: scale(1.1);
        }

        .nav-item.current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .nav-item.answered {
            background: var(--success-color);
            color: white;
            border-color: var(--success-color);
        }

        .navigator-legend {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        .legend-box {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid var(--border-color);
        }

        .legend-box.current {
            background: var(--primary-color);
            border-color: var(--primary-color);
        }

        .legend-box.answered {
            background: var(--success-color);
            border-color: var(--success-color);
        }

        /* Bottom Navigation */
        .bottom-navigation {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-buttons {
            display: flex;
            gap: 1rem;
        }

        .nav-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-btn.prev {
            background: var(--light-color);
            color: var(--text-color);
        }

        .nav-btn.prev:hover:not(:disabled) {
            background: #d1d5db;
        }

        .nav-btn.next {
            background: var(--primary-color);
            color: white;
        }

        .nav-btn.next:hover {
            background: #4338ca;
        }

        .nav-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .progress-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .progress-bar-container {
            width: 200px;
            height: 8px;
            background: var(--light-color);
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: var(--primary-color);
            transition: width 0.5s;
        }

        .progress-text {
            font-size: 0.9rem;
            color: #666;
        }

        /* Intro Screen */
        .intro-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .intro-card {
            background: white;
            border-radius: 16px;
            padding: 3rem;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }

        .intro-icon {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .intro-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .intro-description {
            color: #666;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .intro-instructions {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            text-align: left;
        }

        .intro-instructions h3 {
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .intro-instructions ul {
            list-style: none;
            padding-left: 0;
        }

        .intro-instructions li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .intro-instructions li i {
            color: var(--success-color);
        }

        .start-btn {
            padding: 1rem 3rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }

        .start-btn:hover {
            background: #4338ca;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(79, 70, 229, 0.3);
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background: var(--dark-color);
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 1rem;
            opacity: 0;
            transition: all 0.3s;
            z-index: 1000;
        }

        .toast.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }

        .toast.success {
            background: var(--success-color);
        }

        .toast.error {
            background: var(--danger-color);
        }

        .toast.info {
            background: var(--primary-color);
        }

        /* Results Section */
        .results-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 3rem;
            box-shadow: var(--shadow-lg);
            text-align: center;
            max-width: 800px;
            margin: 2rem auto;
        }

        .results-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
        }

        .results-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .results-score {
            font-size: 3rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .results-message {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }

        .results-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .results-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .action-btn.primary {
            background: var(--primary-color);
            color: white;
        }

        .action-btn.primary:hover {
            background: #4338ca;
        }

        .action-btn.secondary {
            background: var(--light-color);
            color: var(--text-color);
        }

        .action-btn.secondary:hover {
            background: #d1d5db;
        }

        /* Review Section */
        .review-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            max-width: 1000px;
            margin: 2rem auto;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .review-title {
            font-size: 1.8rem;
            color: var(--dark-color);
        }

        .back-btn {
            padding: 0.6rem 1.2rem;
            background: var(--light-color);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #d1d5db;
        }

        .review-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .review-question {
            padding: 1.5rem;
            border-radius: 8px;
            border: 2px solid var(--border-color);
        }

        .review-question.correct {
            border-color: var(--success-color);
            background: #ecfdf5;
        }

        .review-question.incorrect {
            border-color: var(--danger-color);
            background: #fef2f2;
        }

        .review-question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .review-question-number {
            font-weight: bold;
            color: var(--dark-color);
        }

        .review-status {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .review-status.correct {
            background: var(--success-color);
            color: white;
        }

        .review-status.incorrect {
            background: var(--danger-color);
            color: white;
        }

        .review-explanation {
            margin-top: 1rem;
            padding: 1rem;
            background: white;
            border-radius: 6px;
            border-left: 4px solid var(--primary-color);
        }

        .review-explanation-title {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .main-container {
                flex-direction: column;
            }

            .right-sidebar {
                width: 100%;
                position: static;
            }

            .navigator-grid {
                grid-template-columns: repeat(10, 1fr);
            }
        }

        @media (max-width: 768px) {
            .top-header {
                flex-direction: column;
                gap: 1rem;
            }

            .test-details {
                flex-direction: column;
                gap: 0.5rem;
            }

            .navigator-grid {
                grid-template-columns: repeat(8, 1fr);
            }

            .results-stats {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .navigator-grid {
                grid-template-columns: repeat(6, 1fr);
            }

            .progress-bar-container {
                width: 100px;
            }

            .nav-buttons {
                flex-direction: column;
                width: 100%;
            }

            .nav-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <?php if($already_done): ?>
<script>
alert("You already completed this quiz!");
window.location.href = "fullstack_final_page.php";
</script>
<?php endif; ?>
</head>
<body>
    <!-- Top Header Bar -->
    <header class="top-header">
        <div class="test-info">
            <h1 class="test-title">Full-Stack Web Dev Quiz</h1>
            <div class="test-details">
                <div class="test-detail">
                    <i class="fas fa-question-circle"></i>
                    <span>50 Questions</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-clock"></i>
                    <span>90 Minutes</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-percentage"></i>
                    <span>70% to Pass</span>
                </div>
            </div>
        </div>
        <div class="header-actions">
            <div id="timer">
                <i class="fas fa-hourglass-half"></i>
                <span id="timerText">90:00</span>
            </div>
            <button class="help-btn" onclick="showHelp()">
                <i class="fas fa-question"></i>
            </button>
        </div>
    </header>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Question Area -->
        <div class="question-area">
            <div class="question-header">
                <div class="question-number" id="questionNumber">Question 1</div>
                <div class="question-type" id="questionType">Multiple Choice</div>
            </div>
            <div class="question-text" id="questionText">
                Loading question...
            </div>
            <div class="answers-container" id="answersContainer">
                <!-- Answers will be loaded here -->
            </div>
        </div>

        <!-- Right Sidebar - Question Navigator -->
        <aside class="right-sidebar">
            <div class="navigator-title">Question Navigator</div>
            <div class="navigator-grid" id="navigatorGrid">
                <!-- Question numbers will be generated here -->
            </div>
            <div class="navigator-legend">
                <div class="legend-item">
                    <div class="legend-box"></div>
                    <span>Not Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box answered"></div>
                    <span>Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box current"></div>
                    <span>Current</span>
                </div>
            </div>
        </aside>
    </div>

    <!-- Bottom Navigation -->
    <footer class="bottom-navigation">
        <div class="nav-buttons">
            <button class="nav-btn prev" id="prevBtn" onclick="previousQuestion()">
                <i class="fas fa-arrow-left"></i>
                Previous
            </button>
            <button class="nav-btn next" id="nextBtn" onclick="nextQuestion()">
                Next
                <i class="fas fa-arrow-right"></i>
            </button>
        </div>
        <div class="progress-container">
            <div class="progress-bar-container">
                <div class="progress-bar" id="progressBar" style="width: 2%"></div>
            </div>
            <div class="progress-text" id="progressText">Question 1 of 50</div>
        </div>
    </footer>

    <!-- Intro Screen -->
    <div class="intro-screen" id="introScreen">
        <div class="intro-card">
            <div class="intro-icon">
                <i class="fas fa-code"></i>
            </div>
            <h2 class="intro-title">Full-Stack Web Dev Quiz</h2>
            <p class="intro-description">
                Test your knowledge of Full-Stack Web Development, covering HTML, CSS, JavaScript, React, Node.js, Express, and MongoDB.
            </p>
            <div class="intro-instructions">
                <h3>Instructions:</h3>
                <ul>
                    <li><i class="fas fa-check"></i> You have 90 minutes to complete 50 questions</li>
                    <li><i class="fas fa-check"></i> Minimum 70% score required to pass</li>
                    <li><i class="fas fa-check"></i> Questions include multiple choice, true/false, fill in the blank, code writing, and rearrange</li>
                    <li><i class="fas fa-check"></i> Use the question navigator on the right to jump between questions</li>
                    <li><i class="fas fa-check"></i> Your progress is automatically saved</li>
                    <li><i class="fas fa-check"></i> Stay on this page - leaving may result in automatic submission</li>
                </ul>
            </div>
            <button class="start-btn" onclick="startQuiz()">
                Start Quiz
            </button>
        </div>
    </div>

    <!-- Results Section -->
    <div class="results-section" id="resultsSection">
        <div class="results-icon" id="resultsIcon">
            <i class="fas fa-trophy"></i>
        </div>
        <h2 class="results-title" id="resultsTitle">Quiz Completed!</h2>
        <div class="results-score" id="resultsScore">85%</div>
        <p class="results-message" id="resultsMessage">Great job! You've passed the quiz!</p>
        
        <div class="results-stats">
            <div class="stat-card">
                <div class="stat-label">Correct Answers</div>
                <div class="stat-value" id="correctAnswers">42</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Incorrect Answers</div>
                <div class="stat-value" id="incorrectAnswers">8</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Time Taken</div>
                <div class="stat-value" id="timeTaken">45:32</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Accuracy</div>
                <div class="stat-value" id="accuracy">84%</div>
            </div>
        </div>
        
        <div class="results-actions">
            <button class="action-btn primary" onclick="reviewAnswers()">
                <i class="fas fa-eye"></i>
                Review Answers
            </button>
            <button class="action-btn secondary" onclick="retakeQuiz()">
                <i class="fas fa-redo"></i>
                Retake Quiz
            </button>
            <button class="action-btn secondary" onclick="downloadCertificate()">
                <i class="fas fa-download"></i>
                Download Certificate
            </button>
            <button class="action-btn secondary" onclick="shareResults()">
                <i class="fas fa-share"></i>
                Share Results
            </button>
        </div>
    </div>

    <!-- Review Section -->
    <div class="review-section" id="reviewSection">
        <div class="review-header">
            <h2 class="review-title">Answer Review</h2>
            <button class="back-btn" onclick="backToResults()">
                <i class="fas fa-arrow-left"></i>
                Back to Results
            </button>
        </div>
        <div class="review-container" id="reviewContainer">
            <!-- Review items will be generated here -->
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <i class="toast-icon fas fa-info-circle"></i>
        <span id="toastMessage">Notification message</span>
    </div>

    <script>
        // Full-Stack Quiz Data
        const quizData = [
            { id: 1, type: 'multiple', question: 'What does HTML stand for?', options: ['Hyper Text Markup Language', 'Hyperlinks and Text Markup Language', 'Home Tool Markup Language', 'Hyper Text Makeup Language'], correct: 0, explanation: 'HTML stands for Hyper Text Markup Language, the standard markup language for creating Web pages.' },
            { id: 2, type: 'multiple', question: 'Which CSS property is used to control the text size?', options: ['text-style', 'font-size', 'text-size', 'font-style'], correct: 1, explanation: 'The font-size property is used to set the size of text in CSS.' },
            { id: 3, type: 'truefalse', question: 'In CSS, the "#" symbol is used to select an element by its ID.', options: ['True', 'False'], correct: 0, explanation: 'True. The hash (#) is the ID selector in CSS.' },
            { id: 4, type: 'fillblank', question: 'CSS stands for ______ Style Sheets.', correct: 'Cascading', explanation: 'CSS stands for Cascading Style Sheets.' },
            { id: 5, type: 'multiple', question: 'Which is the correct HTML element for the largest heading?', options: ['<h6>', '<head>', '<heading>', '<h1>'], correct: 3, explanation: '<h1> defines the most important and largest heading.' },
            { id: 6, type: 'rearrange', question: 'Order the CSS box model components from inside out:', options: ['Margin', 'Content', 'Padding', 'Border'], correct: ['Content', 'Padding', 'Border', 'Margin'], explanation: 'The box model is: Content (inner), Padding, Border, and Margin (outer).' },
            { id: 7, type: 'truefalse', question: 'Applying "display: none;" to an element removes it from the document flow completely.', options: ['True', 'False'], correct: 0, explanation: 'True. Unlike visibility: hidden, display: none removes the element from the layout flow entirely.' },
            { id: 8, type: 'code', question: 'Write a simple CSS rule to make all <p> element text red.', correct: 'p { color: red; }', explanation: 'You target the p tag and use the color property.' },
            { id: 9, type: 'multiple', question: 'Which HTML attribute specifies an alternate text for an image, if the image cannot be displayed?', options: ['title', 'alt', 'src', 'longdesc'], correct: 1, explanation: 'The alt attribute provides alternative information for an image.' },
            { id: 10, type: 'fillblank', question: 'To create a flexbox container, you must set the "display" CSS property to ____.', correct: 'flex', explanation: 'Setting display: flex creates a flex container.' },
            { id: 11, type: 'multiple', question: 'Which keyword is used to declare a block-scoped variable in ES6?', options: ['var', 'let', 'def', 'int'], correct: 1, explanation: 'The let (and const) keyword declares block-scoped local variables.' },
            { id: 12, type: 'truefalse', question: 'JavaScript is a statically typed language.', options: ['True', 'False'], correct: 1, explanation: 'False. JavaScript is dynamically typed.' },
            { id: 13, type: 'multiple', question: 'What does the "===" operator do in JavaScript?', options: ['Checks for value equality only', 'Assigns a value', 'Checks for strict equality (value and type)', 'Compares memory addresses'], correct: 2, explanation: '"===" is the strict equality operator that checks both the value and the type.' },
            { id: 14, type: 'code', question: 'Write an ES6 arrow function named "add" that takes parameters "a" and "b" and returns their sum.', correct: 'const add = (a, b) => a + b;', explanation: 'An arrow function allows concise syntax and implicit returns.' },
            { id: 15, type: 'fillblank', question: 'The ______ array method creates a new array populated with the results of calling a provided function on every element.', correct: 'map', explanation: 'The map() method creates a new array transformed by the callback function.' },
            { id: 16, type: 'rearrange', question: 'Order the typical states/steps of an API Promise resolution:', options: ['Promise Resolved', 'Data Processed', 'Call API', 'Promise Pending'], correct: ['Call API', 'Promise Pending', 'Promise Resolved', 'Data Processed'], explanation: 'You call the API, the promise is Pending, then it is Resolved, and finally the Data is Processed.' },
            { id: 17, type: 'multiple', question: 'How do you write "Hello World" in an alert box in JS?', options: ['msgBox("Hello World");', 'alert("Hello World");', 'msg("Hello World");', 'alertBox("Hello World");'], correct: 1, explanation: 'The alert() method displays an alert box.' },
            { id: 18, type: 'truefalse', question: 'In JavaScript, `NaN === NaN` evaluates to true.', options: ['True', 'False'], correct: 1, explanation: 'False. NaN is the only value in JS that is not equal to itself.' },
            { id: 19, type: 'fillblank', question: 'The ______ operator (denoted by three dots) allows an iterable to be expanded in places where zero or more arguments are expected.', correct: 'spread', explanation: 'The spread operator (...) unpacks iterables.' },
            { id: 20, type: 'multiple', question: 'Which function is used to parse a JSON string into a JavaScript object?', options: ['JSON.stringify()', 'JSON.parse()', 'JSON.toObject()', 'JSON.convert()'], correct: 1, explanation: 'JSON.parse() is used to parse JSON strings.' },
            { id: 21, type: 'multiple', question: 'What is JSX in React?', options: ['A new JavaScript version', 'A database query language', 'A syntax extension for JavaScript', 'A CSS preprocessor'], correct: 2, explanation: 'JSX is a syntax extension that looks like HTML but works inside JavaScript.' },
            { id: 22, type: 'truefalse', question: 'In React, state can be updated directly like this: `state.count = 1`.', options: ['True', 'False'], correct: 1, explanation: 'False. You must use the state updater function (e.g., setState or setCount) to trigger re-renders.' },
            { id: 23, type: 'fillblank', question: 'The ______ hook allows you to perform side effects (like data fetching) in functional components.', correct: 'useEffect', explanation: 'useEffect is the hook used for side effects.' },
            { id: 24, type: 'multiple', question: 'How do you pass data from a parent component to a child component in React?', options: ['State', 'Props', 'Context', 'Redux'], correct: 1, explanation: 'Props (properties) are the standard way to pass data downwards.' },
            { id: 25, type: 'rearrange', question: 'Order the React component lifecycle events (Conceptual):', options: ['Component Did Mount', 'Component Will Unmount', 'Render', 'Constructor / Init'], correct: ['Constructor / Init', 'Render', 'Component Did Mount', 'Component Will Unmount'], explanation: 'Initialization happens first, then it renders, then it mounts, and finally it unmounts.' },
            { id: 26, type: 'code', question: 'Write a simple React functional component named "Hello" that returns a div with the text "Hi".', correct: 'const Hello = () => <div>Hi</div>;', explanation: 'A basic functional component returning JSX.' },
            { id: 27, type: 'truefalse', question: 'In React, "keys" are required when rendering a list of elements.', options: ['True', 'False'], correct: 0, explanation: 'True. Keys help React identify which items have changed, are added, or are removed.' },
            { id: 28, type: 'multiple', question: 'What is the Virtual DOM in React?', options: ['A direct reference to the browser DOM', 'A lightweight copy of the actual DOM', 'A database structure', 'A testing framework'], correct: 1, explanation: 'The Virtual DOM is an in-memory representation of the real DOM elements.' },
            { id: 29, type: 'fillblank', question: 'The useState hook returns an array containing the state value and a ______ to update it.', correct: 'function', explanation: 'It returns [state, setStateFunction].' },
            { id: 30, type: 'multiple', question: 'Which of the following is NOT a built-in hook in React?', options: ['useState', 'useEffect', 'useContext', 'useStore'], correct: 3, explanation: 'useStore is not a built-in React hook (though it might exist in external libraries).' },
            { id: 31, type: 'multiple', question: 'What is Node.js?', options: ['A web browser', 'A frontend framework', 'A JavaScript runtime built on Chrome\'s V8 engine', 'A relational database'], correct: 2, explanation: 'Node.js allows you to run JS on the server via the V8 engine.' },
            { id: 32, type: 'truefalse', question: 'Node.js execution is completely multi-threaded for JavaScript code.', options: ['True', 'False'], correct: 1, explanation: 'False. Node.js uses a single-threaded event loop for JavaScript execution.' },
            { id: 33, type: 'fillblank', question: 'The default package manager for Node.js is ____.', correct: 'npm', explanation: 'npm stands for Node Package Manager.' },
            { id: 34, type: 'multiple', question: 'In an Express.js POST request, where do you typically find the submitted data payload?', options: ['req.params', 'req.query', 'req.body', 'req.headers'], correct: 2, explanation: 'req.body contains key-value pairs of data submitted in the request body.' },
            { id: 35, type: 'rearrange', question: 'Order the typical flow of an HTTP Request in Express:', options: ['Route matches', 'Middleware runs', 'Response sent', 'Client sends request', 'Controller handles logic'], correct: ['Client sends request', 'Middleware runs', 'Route matches', 'Controller handles logic', 'Response sent'], explanation: 'Request comes in, hits middleware, matches route, controller processes it, and sends the response.' },
            { id: 36, type: 'code', question: 'Write the Express code to define a GET route for "/api" that sends the text "Hello". Assume `app` is defined.', correct: 'app.get("/api", (req, res) => res.send("Hello"));', explanation: 'Use app.get(), provide the path, and a callback with req and res.' },
            { id: 37, type: 'truefalse', question: 'Middleware functions in Express have access to the request object, response object, and the next() function.', options: ['True', 'False'], correct: 0, explanation: 'True. They can modify req/res or pass control to the next middleware.' },
            { id: 38, type: 'multiple', question: 'Which core Node.js module is used to interact with the file system?', options: ['path', 'http', 'os', 'fs'], correct: 3, explanation: 'The "fs" (File System) module allows you to work with the file system.' },
            { id: 39, type: 'fillblank', question: 'In Express, you use the `app.____()` method to mount middleware functions at the application level.', correct: 'use', explanation: 'app.use() binds middleware to your application.' },
            { id: 40, type: 'multiple', question: 'What does CORS stand for in web development?', options: ['Cross-Origin Resource Sharing', 'Cross-Origin Request Security', 'Central-Origin Resource System', 'Control-Origin Request Sharing'], correct: 0, explanation: 'CORS is a mechanism that allows restricted resources on a web page to be requested from another domain.' },
            { id: 41, type: 'multiple', question: 'What type of database is MongoDB?', options: ['Relational / SQL', 'Graph', 'Document-oriented / NoSQL', 'Key-Value store'], correct: 2, explanation: 'MongoDB is a NoSQL document database that stores data in JSON-like documents.' },
            { id: 42, type: 'truefalse', question: 'MongoDB strictly stores data in tables and rows.', options: ['True', 'False'], correct: 1, explanation: 'False. It stores data in collections and documents.' },
            { id: 43, type: 'fillblank', question: 'An elegant Object Data Modeling (ODM) library commonly used with MongoDB and Node.js is ____.', correct: 'Mongoose', explanation: 'Mongoose provides a straight-forward, schema-based solution to model application data.' },
            { id: 44, type: 'multiple', question: 'In Mongoose, what defines the structure of the document and its data types?', options: ['Model', 'Schema', 'Query', 'Connection'], correct: 1, explanation: 'A Schema defines the structure and data types of a document.' },
            { id: 45, type: 'rearrange', question: 'Match the CRUD operations to standard HTTP Methods in this order (Create, Read, Update, Delete):', options: ['GET', 'DELETE', 'POST', 'PUT'], correct: ['POST', 'GET', 'PUT', 'DELETE'], explanation: 'Create = POST, Read = GET, Update = PUT, Delete = DELETE.' },
            { id: 46, type: 'code', question: 'Write a basic Mongoose schema definition for a User with a `name` of type String.', correct: 'const userSchema = new mongoose.Schema({ name: String });', explanation: 'You instantiate a new mongoose.Schema object passing the configuration.' },
            { id: 47, type: 'truefalse', question: 'REST API stands for REpresentational State Transfer.', options: ['True', 'False'], correct: 0, explanation: 'True. REST is an architectural style for distributed hypermedia systems.' },
            { id: 48, type: 'multiple', question: 'Which HTTP status code represents "Not Found"?', options: ['200', '400', '404', '500'], correct: 2, explanation: '404 is the standard HTTP status code for a resource not found.' },
            { id: 49, type: 'fillblank', question: 'In MongoDB, every document requires a unique identifier which is automatically generated as an `_id` field of type ____.', correct: 'ObjectId', explanation: 'ObjectId is the default data type for MongoDB _id fields.' },
            { id: 50, type: 'multiple', question: 'What is the typical data flow of a Full-Stack request?', options: ['Server -> DB -> Client', 'Client -> DB -> Server', 'Client -> Server -> Database -> Server -> Client', 'DB -> Server -> Client -> Server'], correct: 2, explanation: 'Client requests the Server, Server queries the DB, DB responds to Server, Server responds to Client.' }
        ];

        // Quiz State
        let currentQuestion = 0;
        let userAnswers = {};
        let startTime = Date.now();
        let timerInterval;
        let timeRemaining = 90 * 60; // 90 minutes in seconds
        let quizCompleted = false;
        let isQuizStarted = false;
        let warningsCount = 0;
        const MAX_WARNINGS = 3;

        function startQuiz() {
            document.getElementById('introScreen').style.display = 'none';
            isQuizStarted = true;
            initQuiz();
            startTimer();
        }

        function initQuiz() {
            renderQuestion();
            renderNavigator();
            updateProgress();
        }

        function renderQuestion() {
            const question = quizData[currentQuestion];
            
            document.getElementById('questionNumber').textContent = `Question ${currentQuestion + 1}`;
            document.getElementById('questionType').textContent = getQuestionTypeText(question.type);
            document.getElementById('questionText').textContent = question.question;
            
            const answersContainer = document.getElementById('answersContainer');
            answersContainer.innerHTML = '';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                question.options.forEach((option, index) => {
                    const answerOption = document.createElement('div');
                    answerOption.className = 'answer-option';
                    answerOption.onclick = () => selectAnswer(index);
                    
                    const isCorrect = userAnswers[question.id] === index;
                    if (isCorrect) answerOption.classList.add('selected');
                    
                    answerOption.innerHTML = `
                        <div class="answer-marker">${String.fromCharCode(65 + index)}</div>
                        <div class="answer-text">${option}</div>
                    `;
                    answersContainer.appendChild(answerOption);
                });
            } else if (question.type === 'fillblank') {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'fill-blank-input';
                input.placeholder = 'Type your answer here...';
                input.value = userAnswers[question.id] || '';
                input.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Answer saved!', 'success');
                };
                answersContainer.appendChild(input);
            } else if (question.type === 'code') {
                const textarea = document.createElement('textarea');
                textarea.className = 'code-input';
                textarea.placeholder = 'Write your code here...';
                textarea.value = userAnswers[question.id] || '';
                textarea.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Code saved!', 'success');
                };
                answersContainer.appendChild(textarea);
            } else if (question.type === 'rearrange') {
                const container = document.createElement('div');
                container.className = 'rearrange-container';
                
                if (!userAnswers[question.id]) {
                    userAnswers[question.id] = [...question.options];
                }
                
                const currentOrder = userAnswers[question.id];
                
                currentOrder.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'rearrange-item';
                    div.innerHTML = `
                        <div class="rearrange-text">${item}</div>
                        <div class="rearrange-controls">
                            <button onclick="moveItem(${question.id}, ${index}, -1)" ${index === 0 ? 'disabled' : ''} title="Move Up"><i class="fas fa-chevron-up"></i></button>
                            <button onclick="moveItem(${question.id}, ${index}, 1)" ${index === currentOrder.length - 1 ? 'disabled' : ''} title="Move Down"><i class="fas fa-chevron-down"></i></button>
                        </div>
                    `;
                    container.appendChild(div);
                });
                answersContainer.appendChild(container);
            }
            
            updateNavigationButtons();
        }

        function getQuestionTypeText(type) {
            const types = {
                'multiple': 'Multiple Choice',
                'truefalse': 'True/False',
                'fillblank': 'Fill in the Blank',
                'code': 'Code Writing',
                'rearrange': 'Rearrange the Order'
            };
            return types[type] || 'Question';
        }

        function selectAnswer(index) {
            const question = quizData[currentQuestion];
            userAnswers[question.id] = index;
            
            const answerOptions = document.querySelectorAll('.answer-option');
            answerOptions.forEach((option, i) => {
                option.classList.remove('selected');
                if (i === index) option.classList.add('selected');
            });
            
            showToast('Answer selected!', 'success');
            updateNavigator();
        }

        function moveItem(questionId, index, direction) {
            const arr = userAnswers[questionId];
            const temp = arr[index];
            arr[index] = arr[index + direction];
            arr[index + direction] = temp;
            renderQuestion();
            updateNavigator();
        }

        function nextQuestion() {
            if (currentQuestion < quizData.length - 1) {
                currentQuestion++;
                renderQuestion();
                updateNavigator();
                updateProgress();
            } else {
                finishQuiz();
            }
        }

        function previousQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                renderQuestion();
                updateNavigator();
                updateProgress();
            }
        }

        function updateNavigationButtons() {
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            
            prevBtn.disabled = currentQuestion === 0;
            
            if (currentQuestion === quizData.length - 1) {
                nextBtn.innerHTML = '<i class="fas fa-flag-checkered"></i> Finish';
            } else {
                nextBtn.innerHTML = 'Next <i class="fas fa-arrow-right"></i>';
            }
        }

        function updateProgress() {
            const progress = ((currentQuestion + 1) / quizData.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressText').textContent = `Question ${currentQuestion + 1} of ${quizData.length}`;
        }

        function renderNavigator() {
            const navigatorGrid = document.getElementById('navigatorGrid');
            navigatorGrid.innerHTML = '';
            
            for (let i = 0; i < quizData.length; i++) {
                const navItem = document.createElement('div');
                navItem.className = 'nav-item';
                navItem.textContent = i + 1;
                
                if (i === currentQuestion) navItem.classList.add('current');
                if (userAnswers[quizData[i].id] !== undefined) navItem.classList.add('answered');
                
                navItem.onclick = () => goToQuestion(i);
                navigatorGrid.appendChild(navItem);
            }
        }

        function updateNavigator() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach((item, index) => {
                item.classList.remove('current');
                if (index === currentQuestion) item.classList.add('current');
                if (userAnswers[quizData[index].id] !== undefined) item.classList.add('answered');
            });
        }

        function goToQuestion(index) {
            currentQuestion = index;
            renderQuestion();
            updateNavigator();
            updateProgress();
        }

        function startTimer() {
            timerInterval = setInterval(() => {
                timeRemaining--;
                updateTimerDisplay();
                
                if (timeRemaining <= 0) {
                    clearInterval(timerInterval);
                    finishQuiz();
                }
            }, 1000);
        }

        function updateTimerDisplay() {
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            const timerText = document.getElementById('timerText');
            const timer = document.getElementById('timer');
            
            timerText.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeRemaining <= 300) timer.classList.add('warning');
            if (timeRemaining <= 60) {
                timer.classList.remove('warning');
                timer.classList.add('danger');
            }
        }

        function finishQuiz() {
            if (quizCompleted) return;
            quizCompleted = true;
            
            clearInterval(timerInterval);
            
            document.querySelector('.main-container').style.display = 'none';
            document.querySelector('.bottom-navigation').style.display = 'none';
            document.querySelector('.top-header').style.display = 'none';
            
            const results = calculateResults();
            showResults(results);
        }

        function calculateResults() {
            let correct = 0;
            let total = quizData.length;
            
            quizData.forEach(question => {
                const userAnswer = userAnswers[question.id];
                
                if (question.type === 'multiple' || question.type === 'truefalse') {
                    if (userAnswer === question.correct) correct++;
                } else if (question.type === 'fillblank') {
                    if (userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase()) correct++;
                } else if (question.type === 'code') {
                    if (userAnswer && userAnswer.length > 5) correct++;
                } else if (question.type === 'rearrange') {
                    if (userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct)) correct++;
                }
            });
            
            const percentage = Math.round((correct / total) * 100);
            const timeTaken = Math.floor((Date.now() - startTime) / 1000);
            
            return { correct, incorrect: total - correct, total, percentage, timeTaken, passed: percentage >= 70 };
        }

        function showResults(results) {
            document.getElementById('resultsSection').style.display = 'block';
            
            const resultsIcon = document.getElementById('resultsIcon');
            const resultsTitle = document.getElementById('resultsTitle');
            const resultsScore = document.getElementById('resultsScore');
            const resultsMessage = document.getElementById('resultsMessage');
            
            if (results.percentage >= 90) {
                resultsIcon.innerHTML = '<i class="fas fa-trophy" style="color: #10b981;"></i>';
                resultsTitle.textContent = 'Excellent!';
                resultsMessage.textContent = 'Outstanding performance! You\'re a Full-Stack expert!';
            } else if (results.percentage >= 70) {
                resultsIcon.innerHTML = '<i class="fas fa-star" style="color: #f59e0b;"></i>';
                resultsTitle.textContent = 'Well Done!';
                resultsMessage.textContent = 'Great job! You\'ve passed the quiz!';
            } else {
                resultsIcon.innerHTML = '<i class="fas fa-redo" style="color: #ef4444;"></i>';
                resultsTitle.textContent = 'Keep Practicing!';
                resultsMessage.textContent = 'You didn\'t pass this time, but keep coding and try again!';
            }
            
            if (results.percentage >= 70) {
                localStorage.setItem('fullstackQuizPassed', 'true');
            }
            
            resultsScore.textContent = results.percentage + '%';
            
            document.getElementById('correctAnswers').textContent = results.correct;
            document.getElementById('incorrectAnswers').textContent = results.incorrect;
            document.getElementById('timeTaken').textContent = formatTime(results.timeTaken);
            document.getElementById('accuracy').textContent = results.percentage + '%';

fetch("../../save_quiz.php", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        course_slug: "fullstack",
        answers: userAnswers,
        score: results.correct,
        total: results.total,
        percentage: results.percentage
    })
})
.then(res => res.text())
.then(data => {
    console.log(data);
});
        }

        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${minutes}:${secs.toString().padStart(2, '0')}`;
        }

        function reviewAnswers() {
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'block';
            
            const reviewContainer = document.getElementById('reviewContainer');
            reviewContainer.innerHTML = '';
            
            quizData.forEach((question, index) => {
                const userAnswer = userAnswers[question.id];
                const isCorrect = checkAnswer(question, userAnswer);
                
                const reviewItem = document.createElement('div');
                reviewItem.className = `review-question ${isCorrect ? 'correct' : 'incorrect'}`;
                
                reviewItem.innerHTML = `
                    <div class="review-question-header">
                        <div class="review-question-number">Question ${index + 1}</div>
                        <div class="review-status ${isCorrect ? 'correct' : 'incorrect'}">
                            <i class="fas fa-${isCorrect ? 'check' : 'times'}"></i>
                            ${isCorrect ? 'Correct' : 'Incorrect'}
                        </div>
                    </div>
                    <p style="margin-bottom: 1rem;">${question.question}</p>
                    <div style="margin-bottom: 1rem;">
                        <strong>Your answer:</strong> ${formatUserAnswer(question, userAnswer)}
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <strong>Correct answer:</strong> ${formatCorrectAnswer(question)}
                    </div>
                    <div class="review-explanation">
                        <div class="review-explanation-title">Explanation</div>
                        ${question.explanation}
                    </div>
                `;
                
                reviewContainer.appendChild(reviewItem);
            });
        }

        function checkAnswer(question, userAnswer) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return userAnswer === question.correct;
            } else if (question.type === 'fillblank') {
                return userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase();
            } else if (question.type === 'code') {
                return userAnswer && userAnswer.length > 5;
            } else if (question.type === 'rearrange') {
                return userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct);
            }
            return false;
        }

        function formatUserAnswer(question, userAnswer) {
            if (userAnswer === undefined || userAnswer === null || userAnswer === '') return 'Not answered';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[userAnswer] || 'Invalid answer';
            } else if (question.type === 'fillblank') {
                return userAnswer;
            } else if (question.type === 'code') {
                return '<code>' + userAnswer.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + (userAnswer.length > 100 ? '...' : '') + '</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + userAnswer.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return userAnswer;
        }

        function formatCorrectAnswer(question) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[question.correct];
            } else if (question.type === 'fillblank') {
                return question.correct;
            } else if (question.type === 'code') {
                return '<code>' + question.correct.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + '...</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + question.correct.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return question.correct;
        }

        function backToResults() {
            document.getElementById('reviewSection').style.display = 'none';
            document.getElementById('resultsSection').style.display = 'block';
        }

        function retakeQuiz() {
            currentQuestion = 0;
            userAnswers = {};
            startTime = Date.now();
            timeRemaining = 90 * 60;
            quizCompleted = false;
            warningsCount = 0;
            
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'none';
            document.querySelector('.main-container').style.display = 'flex';
            document.querySelector('.bottom-navigation').style.display = 'flex';
            document.querySelector('.top-header').style.display = 'flex';
            
            initQuiz();
            startTimer();
        }

        function downloadCertificate() {
            window.location.href = "certificate_fullstack.php";
        }

        function shareResults() {
            const results = calculateResults();
            const text = `I scored ${results.percentage}% on the Full-Stack Web Development Quiz on Learnify! 🚀🎉`;
            
            if (navigator.share) {
                navigator.share({ title: 'Full-Stack Quiz Results', text: text, url: window.location.href });
            } else {
                navigator.clipboard.writeText(text);
                showToast('Results copied to clipboard!', 'success');
            }
        }

        function showHelp() {
            showToast('Use the question navigator on the right to jump between questions. You have 90 minutes to complete the quiz.', 'info');
        }

        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            const toastIcon = toast.querySelector('.toast-icon i');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type} show`;
            
            if (type === 'success') toastIcon.className = 'fas fa-check-circle';
            else if (type === 'error') toastIcon.className = 'fas fa-times-circle';
            else toastIcon.className = 'fas fa-info-circle';
            
            setTimeout(() => { toast.classList.remove('show'); }, 3000);
        }

        window.addEventListener('beforeunload', function(e) {
            if (!quizCompleted && isQuizStarted && Object.keys(userAnswers).length > 0) {
                e.preventDefault();
                e.returnValue = 'Your quiz progress will be lost. Are you sure you want to leave?';
            }
        });

        document.addEventListener("visibilitychange", () => {
            if (document.hidden && isQuizStarted && !quizCompleted) {
                warningsCount++;
                if (warningsCount >= MAX_WARNINGS) {
                    alert(`Warning ${warningsCount}/${MAX_WARNINGS}: Tab switch detected!\n\nMaximum warnings reached. The quiz will now be submitted automatically.`);
                    finishQuiz();
                } else {
                    alert(`Warning ${warningsCount}/${MAX_WARNINGS}: Tab switch detected!\n\nPlease stay on this page. Your quiz will be submitted if you leave again.`);
                }
            }
        });
    </script>
</body>
</html>