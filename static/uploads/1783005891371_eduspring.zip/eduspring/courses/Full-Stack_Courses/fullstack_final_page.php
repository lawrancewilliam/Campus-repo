<?php
session_start();

// LOGIN CHECK
if(!isset($_SESSION['user_email'])){
    header("Location: signin.php?error=login_required");
    exit();
}

include("../../db.php");

$slug = "fullstack";

$stmt = $conn->prepare("SELECT id FROM courses WHERE slug=?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$resCourse = $stmt->get_result();
$course = $resCourse->fetch_assoc();

if(!$course){
    die("Course not found");
}

$course_id = $course['id'];

$email = $_SESSION['user_email'];

$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$resUser = $getUser->get_result();

$userData = $resUser->fetch_assoc();

if(!$userData){
    die("User not found");
}

$user_id = $userData['id'];

$checkProgress = $conn->prepare("
SELECT * FROM course_progress 
WHERE user_id=? AND course_id=?
");
$checkProgress->bind_param("ii", $user_id, $course_id);
$checkProgress->execute();
$resCheck = $checkProgress->get_result();

if($resCheck->num_rows == 0){
    $insert = $conn->prepare("
    INSERT INTO course_progress(user_id, course_id, total_topics, completed_topics, progress_percent)
    VALUES(?, ?, 14, 0, 0)
    ");
    $insert->bind_param("ii", $user_id, $course_id);
    $insert->execute();
}

$completedTopicsList = [];

$getTopics = $conn->prepare("
SELECT topic_name FROM topic_progress 
WHERE user_id=? AND course_id=?
");

$getTopics->bind_param("ii", $user_id, $course_id);
$getTopics->execute();
$resultTopics = $getTopics->get_result();

while($row = $resultTopics->fetch_assoc()){
    $completedTopicsList[] = $row['topic_name'];
}

$stmt = $conn->prepare("
SELECT completed_topics, total_topics 
FROM course_progress 
WHERE user_id=? AND course_id=?
");

$stmt->bind_param("ii", $user_id, $course_id);
$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows > 0){

    $row = $res->fetch_assoc();

    $completed = (int)$row['completed_topics'];
    $total = (int)$row['total_topics'];

} else {
    $completed = 0;
    $total = 14; // fullstack topics
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full-Stack Web Development - Complete Guide</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-jsx.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-json.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-bash.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .sidebar-item {
            transition: all 0.3s ease;
        }
        
        .sidebar-item:hover {
            transform: translateX(5px);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
        }
        
        .topic-completed {
            position: relative;
        }
        
        .topic-completed::after {
            content: '✓';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #10b981;
            font-weight: bold;
        }
        
        .content-section {
            display: none;
            animation: fadeIn 0.5s ease-in;
        }
        
        .content-section.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .code-toolbar {
            position: relative;
            background: #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .copy-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #4f46e5;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background 0.3s ease;
            z-index: 10;
        }
        
        .copy-button:hover {
            background: #3730a3;
        }
        
        pre[class*="language-"] {
            margin: 0;
            padding: 20px;
            background: transparent;
        }
        
        .progress-ring {
            transform: rotate(-90deg);
        }
        
        .progress-ring-circle {
            transition: stroke-dashoffset 0.35s;
            stroke: #10b981;
            stroke-dasharray: 75.398 75.398;
        }
        
        .search-highlight {
            background-color: #fef3c7;
            padding: 1px 2px;
            border-radius: 2px;
        }
        
        .main-search-container {
            max-width: 600px;
            margin: 0 auto;
            position: relative;
        }
        
        .search-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-top: 4px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            max-height: 400px;
            overflow-y: auto;
            z-index: 50;
            display: none;
        }
        
        .search-dropdown.active {
            display: block;
        }
        
        .search-result-item {
            padding: 12px 16px;
            cursor: pointer;
            transition: background 0.2s ease;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .search-result-item:hover {
            background: #f9fafb;
        }
        
        .search-result-item:last-child {
            border-bottom: none;
        }
        
        .no-results {
            padding: 20px;
            text-align: center;
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="gradient-bg text-white shadow-lg sticky top-0 z-40">
        <div class="container mx-auto px-4 py-4">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <button id="menuToggle" class="md:hidden text-white" onclick="toggleSidebar()">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold flex items-center gap-2">
                        <i class="fas fa-code"></i>
                        Full-Stack Tutorial
                    </h1>
                </div>
                
                <!-- Search Bar -->
                <div class="main-search-container w-full md:w-auto">
                    <div class="relative">
                        <input 
                            type="text" 
                            id="globalSearch" 
                            placeholder="Search topics... (Ctrl+K)"
                            class="w-full md:w-96 px-4 py-2 pl-10 pr-10 text-gray-800 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-white/50 shadow-md"
                        >
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <button 
                            id="clearSearch" 
                            class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 hidden"
                            onclick="clearSearch()"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <!-- Search Dropdown -->
                    <div id="searchDropdown" class="search-dropdown"></div>
                </div>
                
                <!-- Progress Indicator -->
                <div class="flex items-center gap-3">
                    <div class="text-right hidden md:block">
                        <div class="text-sm opacity-90">Progress</div>
                        <div class="font-bold" id="progressText">0%</div>
                    </div>
                    <div class="relative">
                        <svg width="30" height="30" class="progress-ring">
                            <circle cx="15" cy="15" r="12" stroke="#ffffff30" stroke-width="3" fill="none" />
                            <circle id="progressCircle" class="progress-ring-circle" cx="15" cy="15" r="12" stroke-width="3" fill="none" stroke-dashoffset="75.398" />
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="flex">
        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar w-64 bg-white shadow-lg h-screen sticky top-16 overflow-y-auto hidden md:block">
            <div class="p-4">
                <h2 class="text-lg font-bold mb-4 text-gray-800">Course Content</h2>
                
                <!-- Unit 1 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 1: Frontend Basics</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="html-css" onclick="showContent('html-css')">
                            <i class="fab fa-html5 mr-2"></i>HTML & CSS
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="javascript" onclick="showContent('javascript')">
                            <i class="fab fa-js mr-2"></i>Modern JavaScript
                        </div>
                    </div>
                </div>
                
                <!-- Unit 2 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 2: Frontend Framework</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="react-intro" onclick="showContent('react-intro')">
                            <i class="fab fa-react mr-2"></i>React Fundamentals
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="react-hooks" onclick="showContent('react-hooks')">
                            <i class="fas fa-link mr-2"></i>React Hooks
                        </div>
                    </div>
                </div>
                
                <!-- Unit 3 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 3: Backend Basics</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="nodejs" onclick="showContent('nodejs')">
                            <i class="fab fa-node-js mr-2"></i>Node.js Core
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="express" onclick="showContent('express')">
                            <i class="fas fa-server mr-2"></i>Express.js
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="express-error" onclick="showContent('express-error')">
                            <i class="fas fa-exclamation-triangle mr-2"></i>Error Handling
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="env-config" onclick="showContent('env-config')">
                            <i class="fas fa-cogs mr-2"></i>Environment Config
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="node-arch" onclick="showContent('node-arch')">
                            <i class="fas fa-sitemap mr-2"></i>Node Architecture
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="rest-design" onclick="showContent('rest-design')">
                            <i class="fas fa-network-wired mr-2"></i>REST API Design
                        </div>
                    </div>
                </div>
                
                <!-- Unit 4 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 4: Database</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="mongodb" onclick="showContent('mongodb')">
                            <i class="fas fa-database mr-2"></i>MongoDB & NoSQL
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="mongoose" onclick="showContent('mongoose')">
                            <i class="fas fa-project-diagram mr-2"></i>Mongoose ODM
                        </div>
                    </div>
                </div>
                
                <!-- Unit 5 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 5: Integration & Deploy</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="api-integration" onclick="showContent('api-integration')">
                            <i class="fas fa-plug mr-2"></i>Connecting React & API
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="deployment" onclick="showContent('deployment')">
                            <i class="fas fa-cloud-upload-alt mr-2"></i>App Deployment
                        </div>
                    </div>
                </div>
                
                <!-- Progress Summary -->
                <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm text-gray-600">Completed</span>
                        <span class="text-sm font-bold text-gray-800">
                            <span id="completedCount">0</span>/<span id="totalCount">0</span>
                        </span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div id="progressBar" class="bg-green-500 h-2 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            
            <!-- Unit 1: HTML & CSS -->
            <section id="html-css" class="content-section active">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fab fa-html5 mr-2"></i>HTML5 & CSS3
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">HTML provides the structure of a webpage, while CSS handles the presentation and layout.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Semantic HTML Structure</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-html">&lt;!DOCTYPE html&gt;
&lt;html lang="en"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
    &lt;title&gt;My Application&lt;/title&gt;
    &lt;link rel="stylesheet" href="styles.css"&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;header&gt;
        &lt;nav&gt;
            &lt;h1&gt;Logo&lt;/h1&gt;
            &lt;ul&gt;
                &lt;li&gt;&lt;a href="#"&gt;Home&lt;/a&gt;&lt;/li&gt;
            &lt;/ul&gt;
        &lt;/nav&gt;
    &lt;/header&gt;
    &lt;main&gt;
        &lt;section class="hero"&gt;
            &lt;h2&gt;Welcome&lt;/h2&gt;
        &lt;/section&gt;
    &lt;/main&gt;
    &lt;footer&gt;
        &lt;p&gt;&amp;copy; 2024 Application&lt;/p&gt;
    &lt;/footer&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">HTML Forms</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">Forms are used to collect user input. Modern HTML5 provides various input types for better validation and user experience.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-html">&lt;form action="/submit" method="POST"&gt;
    &lt;div class="form-group"&gt;
        &lt;label for="email"&gt;Email Address:&lt;/label&gt;
        &lt;input type="email" id="email" name="email" required&gt;
    &lt;/div&gt;
    
    &lt;div class="form-group"&gt;
        &lt;label for="password"&gt;Password:&lt;/label&gt;
        &lt;input type="password" id="password" name="password" minlength="8" required&gt;
    &lt;/div&gt;
    
    &lt;button type="submit"&gt;Log In&lt;/button&gt;
&lt;/form&gt;</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Modern CSS (Flexbox)</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-css">/* Reset & Variables */
:root {
    --primary-color: #4f46e5;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Flexbox Navigation */
nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 2rem;
    background-color: var(--primary-color);
    color: white;
}

nav ul {
    display: flex;
    gap: 1.5rem;
    list-style: none;
}</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">CSS Selectors & Specificity</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">CSS Selectors are used to "find" (or select) the HTML elements you want to style. Understanding specificity is crucial for avoiding style conflicts.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-css">/* Element Selector */
p {
    color: #333;
}

/* Class Selector */
.highlight {
    background-color: yellow;
}

/* ID Selector */
#main-header {
    font-size: 2rem;
}

/* Descendant Selector */
article p {
    line-height: 1.6;
}

/* Pseudo-class */
button:hover {
    background-color: #2563eb;
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 1: JavaScript -->
            <section id="javascript" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fab fa-js mr-2"></i>Modern JavaScript (ES6+)
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Modern JavaScript introduced features like arrow functions, destructuring, and async/await that make writing Full-Stack apps much cleaner.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Variables & Arrow Functions</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">// let & const instead of var
const apiBase = 'https://api.example.com';
let requestCount = 0;

// Arrow Functions
const calculateTotal = (price, tax) => {
    return price + (price * tax);
};

// Implicit return
const multiply = (a, b) => a * b;

// Array methods with arrow functions
const numbers = [1, 2, 3, 4];
const doubled = numbers.map(num => num * 2);
const evens = numbers.filter(num => num % 2 === 0);</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Destructuring & Spread Operator</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const user = { name: 'Alice', age: 25, role: 'Admin' };

// Object Destructuring
const { name, role } = user;
console.log(name); // Alice

// Spread Operator (Objects)
const updatedUser = { ...user, location: 'NY' };

// Spread Operator (Arrays)
const arr1 = [1, 2];
const arr2 = [...arr1, 3, 4]; // [1, 2, 3, 4]</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Array Methods</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">Modern JavaScript provides powerful higher-order functions for array manipulation, reducing the need for traditional loops.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const users = [
    { id: 1, name: 'Alice', active: true },
    { id: 2, name: 'Bob', active: false },
    { id: 3, name: 'Charlie', active: true }
];

// Map: Transform elements
const names = users.map(user => user.name);
console.log(names); // ['Alice', 'Bob', 'Charlie']

// Filter: Select elements based on condition
const activeUsers = users.filter(user => user.active);

// Reduce: Accumulate values
const valuesList = [10, 20, 30, 40];
const total = valuesList.reduce((sum, num) => sum + num, 0);
console.log(total); // 100</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Async/Await & Promises</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const fetchUserData = async (userId) => {
    try {
        const response = await fetch(`https://api.example.com/users/${userId}`);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Fetch error:', error);
    }
};</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 2: React Intro -->
            <section id="react-intro" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fab fa-react mr-2"></i>React Fundamentals
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">React is a component-based library for building user interfaces. It uses JSX, a syntax extension to JavaScript.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Functional Components & Props</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React from 'react';

// A functional component using destructuring for props
const UserCard = ({ name, email, avatarUrl }) => {
    return (
        &lt;div className="card"&gt;
            &lt;img src={avatarUrl} alt={`${name}'s avatar`} /&gt;
            &lt;h3&gt;{name}&lt;/h3&gt;
            &lt;p&gt;{email}&lt;/p&gt;
        &lt;/div&gt;
    );
};

// Parent component rendering the UserCard
const App = () => {
    return (
        &lt;div className="container"&gt;
            &lt;h1&gt;User Directory&lt;/h1&gt;
            &lt;UserCard 
                name="Jane Doe" 
                email="jane@example.com" 
                avatarUrl="/assets/jane.png" 
            /&gt;
        &lt;/div&gt;
    );
};

export default App;</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">State vs Props</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">While props are used to pass data from parent to child, state is used to manage data within a component. State is mutable, while props are read-only.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React, { useState } from 'react';

const ToggleButton = ({ initialText }) => {
    // 'initialText' is a prop
    // 'isToggled' is state
    const [isToggled, setIsToggled] = useState(false);

    return (
        &lt;button onClick={() => setIsToggled(!isToggled)}&gt;
            {isToggled ? 'Toggled ON' : initialText}
        &lt;/button&gt;
    );
};

export default ToggleButton;</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Handling Events</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">React events are named using camelCase, rather than lowercase. With JSX you pass a function as the event handler, rather than a string.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React from 'react';

const FormSubmit = () => {
    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent default browser reload
        console.log('Form submitted!');
    };

    return (
        &lt;form onSubmit={handleSubmit}&gt;
            &lt;input type="text" placeholder="Enter name" /&gt;
            &lt;button type="submit"&gt;Submit&lt;/button&gt;
        &lt;/form&gt;
    );
};

export default FormSubmit;</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 2: React Hooks -->
            <section id="react-hooks" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-link mr-2"></i>React Hooks
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Hooks allow you to use state and other React features without writing a class component.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">useState & useEffect</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React, { useState, useEffect } from 'react';

const CounterAndFetch = () => {
    // useState: Declare a state variable
    const [count, setCount] = useState(0);
    const [data, setData] = useState(null);

    // useEffect: Handle side effects (like data fetching)
    useEffect(() => {
        const fetchData = async () => {
            const res = await fetch('https://api.github.com/users/octocat');
            const result = await res.json();
            setData(result);
        };
        
        fetchData();
    }, []); // Empty dependency array = runs once on mount

    return (
        &lt;div&gt;
            &lt;h2&gt;Counter: {count}&lt;/h2&gt;
            &lt;button onClick={() => setCount(count + 1)}&gt;Increment&lt;/button&gt;
            
            &lt;h3&gt;Fetched Data:&lt;/h3&gt;
            {data ? &lt;p&gt;GitHub Username: {data.login}&lt;/p&gt; : &lt;p&gt;Loading...&lt;/p&gt;}
        &lt;/div&gt;
    );
};

export default CounterAndFetch;</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">useRef Hook</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">The <code>useRef</code> Hook allows you to persist values between renders. It can be used to store a mutable value that does not cause a re-render when updated, or to access a DOM element directly.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React, { useRef } from 'react';

const FocusInput = () => {
    const inputElement = useRef();

    const focusInput = () => {
        inputElement.current.focus();
    };

    return (
        &lt;div&gt;
            &lt;input type="text" ref={inputElement} /&gt;
            &lt;button onClick={focusInput}&gt;Focus Input&lt;/button&gt;
        &lt;/div&gt;
    );
};

export default FocusInput;</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">useContext Hook</h3>
                    <p class="text-gray-600 leading-relaxed mb-4"><code>useContext</code> is a React Hook that lets you read and subscribe to context from your component, avoiding "prop drilling".</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React, { createContext, useContext } from 'react';

// 1. Create a Context
const ThemeContext = createContext('light');

const ThemedButton = () => {
    // 3. Consume the Context
    const theme = useContext(ThemeContext);
    return &lt;button className={theme}&gt;I am styled by theme context!&lt;/button&gt;;
};

const App = () => {
    return (
        // 2. Provide the Context Value
        &lt;ThemeContext.Provider value="dark"&gt;
            &lt;ThemedButton /&gt;
        &lt;/ThemeContext.Provider&gt;
    );
};

export default App;</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 3: Node.js Core -->
            <section id="nodejs" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fab fa-node-js mr-2"></i>Node.js Core
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">Node.js is an open-source, cross-platform JavaScript runtime environment that executes JavaScript code outside a web browser. Historically, JavaScript was used primarily for client-side scripting, where scripts written in JavaScript are embedded in a webpage's HTML and run client-side by a JavaScript engine in the user's web browser. Node.js lets developers use JavaScript to write command-line tools and for server-side scripting—running scripts server-side to produce dynamic web page content before the page is sent to the user's web browser.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">One of the most significant advantages of Node.js is its non-blocking, event-driven architecture. Traditional web server architectures spawn a new thread or process for every new request, which can consume a significant amount of system memory and CPU resources under heavy load. In contrast, Node.js operates on a single-thread event loop, handling thousands of concurrent connections with minimal overhead. This makes it incredibly efficient for I/O-intensive applications.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic HTTP Server</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const http = require('http');

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('&lt;h1&gt;Welcome to the Home Page&lt;/h1&gt;');
    } else if (req.url === '/api/data') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Hello from Node.js!' }));
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
    }
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 3: Node Architecture -->
            <section id="node-arch" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-sitemap mr-2"></i>Node.js Architecture
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">The architecture of Node.js is what truly sets it apart from other backend technologies. At its core, Node.js is built on top of Google Chrome's V8 JavaScript engine, which is written in C++ and highly optimized for compiling JavaScript directly into native machine code. This ensures that the execution of JavaScript on the server is incredibly fast. However, V8 alone isn't enough to build a server; it requires an asynchronous I/O layer, which is provided by the <strong>libuv</strong> library.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">The <strong>Event Loop</strong> is the heart of Node.js architecture. It allows Node.js to perform non-blocking I/O operations—despite the fact that JavaScript is single-threaded—by offloading operations to the system kernel whenever possible. When an asynchronous operation is initiated, Node.js pushes this task to a worker pool managed by libuv. The main thread continues to execute other code without waiting for the task to finish.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">Once the background task is completed, its associated callback function is placed into a task queue. The Event Loop constantly monitors both the call stack and the task queue. If the call stack is empty, it takes the first callback from the queue and pushes it to the call stack, effectively executing it. This continuous, circular process is what allows Node.js to handle tens of thousands of concurrent connections efficiently, making it the perfect choice for highly scalable network applications.</p>
                </div>
            </section>

            <!-- Unit 3: Express.js -->
            <section id="express" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-server mr-2"></i>Express.js
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">Express.js, or simply Express, is a back-end web application framework for building RESTful APIs with Node.js. Released as free and open-source software under the MIT License, it is designed for building web applications and APIs. It has been called the de facto standard server framework for Node.js, and it is the backend component of the popular MEAN, MERN, and MEVN stacks.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">While Node.js provides the raw capabilities to create an HTTP server, doing so from scratch requires handling a massive amount of boilerplate code for routing, parsing payloads, managing sessions, and handling cookies. Express abstracts away this complexity, providing a thin layer of fundamental web application features without obscuring Node.js features that you know and love. It simplifies the process of creating robust, scalable backend systems by providing built-in methods for handling various HTTP requests and creating complex routing systems.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Express API Setup</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const express = require('express');
const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// Mock database
let users = [{ id: 1, name: 'Alice' }];

// GET Route
app.get('/api/users', (req, res) => {
    res.json(users);
});

// POST Route
app.post('/api/users', (req, res) => {
    const newUser = { id: users.length + 1, name: req.body.name };
    users.push(newUser);
    res.status(201).json(newUser);
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Express server running on http://localhost:${PORT}`);
});</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 3: Error Handling -->
            <section id="express-error" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-exclamation-triangle mr-2"></i>Error Handling in Express
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">Proper error handling is an absolute necessity for building robust, production-ready APIs. In a distributed web system, numerous things can go wrong: database connections can fail, third-party APIs can timeout, or clients might send invalid data. Without a centralized error-handling strategy, your Node.js application might crash entirely, or worse, leak sensitive stack traces to the end user. Express comes with a default error handler, but you should always implement custom error-handling middleware to format error responses consistently and log errors appropriately for your team.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Custom Error Handling Middleware</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">Error-handling middleware functions are defined in the same way as other middleware functions, except they have four arguments instead of three: <code>(err, req, res, next)</code>.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const express = require('express');
const app = express();

// A route that throws an error
app.get('/api/broken', (req, res, next) => {
    const error = new Error('Something went wrong!');
    error.status = 500;
    next(error); // Pass the error to the error handler
});

// Custom Error Handler Middleware
// Must be defined AFTER all other routes and middleware
app.use((err, req, res, next) => {
    const statusCode = err.status || 500;
    
    res.status(statusCode).json({
        success: false,
        error: {
            message: err.message || 'Internal Server Error',
            status: statusCode,
            stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
        }
    });
});

app.listen(5000, () => console.log('Server started'));</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 3: Environment Configuration -->
            <section id="env-config" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-cogs mr-2"></i>Environment Variables
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">Environment variables are fundamental to the "Twelve-Factor App" methodology, which dictates that any configuration that varies between deployments (such as development, staging, and production environments) should be stored in the environment, not in the source code. Hardcoding sensitive information like database passwords, third-party API keys, or JWT secrets directly into your codebase is a massive security risk, especially if your repository is public or compromised. Environment variables allow you to completely decouple your configuration from your application logic.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using dotenv</h3>
                    <p class="text-gray-600 leading-relaxed mb-4">The <code>dotenv</code> package loads environment variables from a <code>.env</code> file into <code>process.env</code>.</p>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># .env file (Do not commit this to version control)
PORT=5000
DB_URI=mongodb://localhost:27017/myapp
JWT_SECRET=super_secret_string_123</code></pre>
                    </div>
                    
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">// server.js
require('dotenv').config(); // Load variables from .env

const express = require('express');
const app = express();

const port = process.env.PORT || 3000;
const dbUri = process.env.DB_URI;

console.log(`Connecting to database at: ${dbUri}`);

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 3: REST API Design -->
            <section id="rest-design" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-network-wired mr-2"></i>REST API Design
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4 leading-relaxed">REST (Representational State Transfer) is an architectural style for designing networked applications. Rather than using complex mechanisms like CORBA, RPC, or SOAP to connect between machines, REST utilizes standard HTTP concepts. A RESTful API leverages HTTP methods explicitly and appropriately. In a purely RESTful system, your backend does not store any state about the client session on the server side between requests. This "statelessness" means every single request from a client contains all the information the server needs to fulfill it, leading to highly scalable and cacheable backend architectures.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">When designing a RESTful API, resources should be identified by URIs (Uniform Resource Identifiers), typically formatted as plural nouns rather than verbs. For instance, to retrieve a list of users, the endpoint should be <code>/users</code> rather than <code>/getUsers</code>. The action being performed is defined by the HTTP method: <strong>GET</strong> to retrieve data, <strong>POST</strong> to create new data, <strong>PUT</strong> or <strong>PATCH</strong> to update existing data, and <strong>DELETE</strong> to remove data.</p>
                    <p class="text-gray-700 mb-4 leading-relaxed">Another critical aspect of REST API design is the use of standard HTTP status codes to communicate the result of a request. A successful GET request should return a <code>200 OK</code> status, while a successful POST request creating a new resource should return <code>201 Created</code>. If a client requests a resource that doesn't exist, the server should return a <code>404 Not Found</code>. If the client sends malformed data, a <code>400 Bad Request</code> is appropriate. By adhering to these standard practices, you ensure that your API is predictable, intuitive, and easy for other developers to integrate with.</p>
                </div>
            </section>

            <!-- Unit 4: MongoDB -->
            <section id="mongodb" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-database mr-2"></i>MongoDB & NoSQL
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">MongoDB is a document-based NoSQL database, storing data in JSON-like documents. It is highly flexible and scalable.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic MongoDB Commands</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">// Insert a document into a collection
db.users.insertOne({
    name: "John Doe",
    age: 28,
    email: "john@example.com"
});

// Find documents
db.users.find({ age: { $gt: 25 } });

// Update a document
db.users.updateOne(
    { name: "John Doe" },
    { $set: { age: 29 } }
);

// Delete a document
db.users.deleteOne({ email: "john@example.com" });</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 4: Mongoose -->
            <section id="mongoose" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-project-diagram mr-2"></i>Mongoose ODM
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Mongoose is an Object Data Modeling (ODM) library for MongoDB and Node.js. It manages relationships between data and provides schema validation.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Schemas and Models</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-javascript">const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/myapp', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB Connected'));

// Define a Schema
const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    createdAt: { type: Date, default: Date.now }
});

// Create a Model
const User = mongoose.model('User', UserSchema);

// Create and save a new user
const createUser = async () => {
    try {
        const newUser = new User({ name: 'Jane Doe', email: 'jane@example.com' });
        await newUser.save();
        console.log('User saved:', newUser);
    } catch (err) {
        console.error(err);
    }
};</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 5: API Integration -->
            <section id="api-integration" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-plug mr-2"></i>Connecting React & API
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">To create a full-stack application, the React frontend must communicate with the Express backend using HTTP requests.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Fetching Data from Backend</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-jsx">import React, { useState, useEffect } from 'react';
import axios from 'axios'; // npm install axios

const UsersList = () => {
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                // Requesting from your local Node/Express backend
                const response = await axios.get('/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error("Error fetching users", error);
            }
        };
        fetchUsers();
    }, []);

    return (
        &lt;div&gt;
            &lt;h2&gt;User List&lt;/h2&gt;
            &lt;ul&gt;
                {users.map(user =&gt; (
                    &lt;li key={user.id}&gt;{user.name}&lt;/li&gt;
                ))}
            &lt;/ul&gt;
        &lt;/div&gt;
    );
};

export default UsersList;</code></pre>
                    </div>
                </div>
            </section>

            <!-- Unit 5: Deployment -->
            <section id="deployment" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-cloud-upload-alt mr-2"></i>App Deployment
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Deploying your full-stack application makes it accessible to the world. We commonly use platforms like Heroku, Vercel, or AWS.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Deploying React on Vercel</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># Install Vercel CLI
npm i -g vercel

# Deploy your app
cd client
vercel</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Deploying Node.js on Render</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># Make sure your server listens to process.env.PORT
const PORT = process.env.PORT || 5000;
app.listen(PORT, () =&gt; console.log(`Server running on port ${PORT}`));

# Commit and push to GitHub, then connect your repo to Render.com</code></pre>
                    </div>
                </div>
            </section>
        </main>
    </div>

    <!-- Footer -->
    <footer class="gradient-bg text-white mt-12 py-8">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <p class="text-lg font-semibold">Full-Stack Tutorial</p>
                    <p class="text-sm opacity-90">Complete guide to Web Development</p>
                </div>
            </div>
            <div class="mt-6 pt-6 border-t border-white/20 text-center">
                <p class="text-sm opacity-90">© 2026 Learnify. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>

let completedFromDB = <?php echo $completed; ?>;
let totalFromDB = <?php echo $total; ?>;

let completedTopicsFromDB = <?php echo json_encode($completedTopicsList); ?>;

let completedTopics = new Set();

let totalTopics = 0; // ✅ GLOBAL

document.addEventListener('DOMContentLoaded', function() {

totalTopics = document.querySelectorAll('.sidebar-item').length;

completedTopicsFromDB.forEach(topic => {
    completedTopics.add(topic);
});

    updateProgress(); // 🔥 ADD THIS

    let percentage = Math.min(100, Math.round((completedTopics.size / totalTopics) * 100));

    document.getElementById('progressText').textContent = percentage + '%';

    const circumference = 2 * Math.PI * 12;
    const offset = circumference - (percentage / 100) * circumference;
    document.getElementById('progressCircle').style.strokeDashoffset = offset;

    // ✅ tick marks apply
    completedTopicsFromDB.forEach(topic => {
        const el = document.querySelector(`[data-topic="${topic}"]`);
        if(el){
            el.classList.add('topic-completed');
        }
    });

});

        // Topic data for search
        const topicData = {
            'html-css': { title: 'HTML & CSS', unit: 'Unit 1', keywords: ['html', 'css', 'flexbox', 'design'] },
            'javascript': { title: 'Modern JavaScript', unit: 'Unit 1', keywords: ['js', 'es6', 'arrow', 'promise'] },
            'react-intro': { title: 'React Fundamentals', unit: 'Unit 2', keywords: ['react', 'jsx', 'component', 'props'] },
            'react-hooks': { title: 'React Hooks', unit: 'Unit 2', keywords: ['hooks', 'state', 'effect', 'usestate'] },
            'nodejs': { title: 'Node.js Core', unit: 'Unit 3', keywords: ['node', 'backend', 'server', 'http'] },
            'express': { title: 'Express.js', unit: 'Unit 3', keywords: ['express', 'api', 'route', 'middleware'] },
            'rest-api': { title: 'RESTful APIs', unit: 'Unit 3', keywords: ['rest', 'api', 'http', 'get', 'post', 'put', 'delete'] },
            'middleware': { title: 'Express Middleware', unit: 'Unit 3', keywords: ['middleware', 'express', 'next', 'req', 'res', 'logger'] },
            'express-error': { title: 'Error Handling', unit: 'Unit 3', keywords: ['error', 'handling', 'express', 'middleware', 'status', 'catch'] },
            'env-config': { title: 'Environment Config', unit: 'Unit 3', keywords: ['env', 'dotenv', 'environment', 'variables', 'config', 'secrets'] },
            'node-arch': { title: 'Node Architecture', unit: 'Unit 3', keywords: ['node', 'architecture', 'event loop', 'v8', 'libuv', 'non-blocking'] },
            'rest-design': { title: 'REST API Design', unit: 'Unit 3', keywords: ['rest', 'api', 'design', 'http', 'methods', 'status codes', 'stateless'] },
            'mongodb': { title: 'MongoDB & NoSQL', unit: 'Unit 4', keywords: ['mongo', 'nosql', 'database', 'json'] },
            'mongoose': { title: 'Mongoose ODM', unit: 'Unit 4', keywords: ['mongoose', 'schema', 'model'] },
            'api-integration': { title: 'Connecting React & API', unit: 'Unit 5', keywords: ['axios', 'fetch', 'integration', 'cors'] },
            'deployment': { title: 'App Deployment', unit: 'Unit 5', keywords: ['deploy', 'vercel', 'render', 'hosting'] }
        };

function showContent(topicId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => section.classList.remove('active'));
    
    const selectedSection = document.getElementById(topicId);
    if (selectedSection) selectedSection.classList.add('active');
    
    const sidebarItems = document.querySelectorAll('.sidebar-item');
    sidebarItems.forEach(item => item.classList.remove('active'));
    
    const clickedItem = document.querySelector(`[data-topic="${topicId}"]`);
    if (clickedItem) {
        clickedItem.classList.add('active');
    }

    // (Removed auto-mark so users must click the button)

    window.scrollTo({ top: 0, behavior: 'smooth' });
    clearSearch();
}

        function updateProgress() {
            const completed = completedTopics.size;
            const percentage = Math.round((completed / totalTopics) * 100);
            
            document.getElementById('progressBar').style.width = percentage + '%';
            
            const circumference = 2 * Math.PI * 12;
            const offset = circumference - (percentage / 100) * circumference;
            document.getElementById('progressCircle').style.strokeDashoffset = offset;
            
            document.getElementById('progressText').textContent = percentage + '%';
            document.getElementById('completedCount').textContent = completed;
            document.getElementById('totalCount').textContent = totalTopics;
            
            localStorage.setItem('fullstackTutorialProgress', JSON.stringify([...completedTopics]));
        }

        function loadProgress() {
            const saved = localStorage.getItem('fullstackTutorialProgress');
            if (saved) {
                completedTopics = new Set(JSON.parse(saved));
                completedTopics.forEach(topicId => {
                    const item = document.querySelector(`[data-topic="${topicId}"]`);
                    if (item) item.classList.add('topic-completed');
                    
                    const section = document.getElementById(topicId);
                    if (section) {
                        const btn = section.querySelector('.mark-complete-btn');
                        if (btn) {
                            btn.classList.replace('bg-indigo-50', 'bg-green-500');
                            btn.classList.replace('text-indigo-600', 'text-white');
                            btn.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                            btn.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                            btn.disabled = true;
                            btn.classList.add('cursor-default');
                        }
                    }
                });
                updateProgress();
            }
        }

        function injectCompletionButtons() {
            const sections = document.querySelectorAll('.content-section');
            sections.forEach(section => {
                const topicId = section.id;
                const btnContainer = document.createElement('div');
                btnContainer.className = 'mt-10 pt-6 border-t border-gray-100 flex justify-end';
                const btn = document.createElement('button');
                btn.className = 'mark-complete-btn bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 flex items-center gap-2 shadow-sm';
                btn.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
                btn.onclick = () => markTopicCompleted(topicId, btn);
                btnContainer.appendChild(btn);
                section.appendChild(btnContainer);
            });
        }

        function markTopicCompleted(topicId, btnElement) {
            
            if (btnElement) {
                btnElement.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            }

            fetch('../../mark_topic.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ topic: topicId, course_id: <?php echo $course_id; ?> })
            })
            .then(res => res.json())
            .then(data => {
                completedTopics.add(topicId);
                const item = document.querySelector(`[data-topic="${topicId}"]`);
                if (item) item.classList.add('topic-completed');
                
                if (btnElement) {
                btnElement.classList.replace('bg-indigo-50', 'bg-green-500');
                btnElement.classList.replace('text-indigo-600', 'text-white');
                btnElement.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                btnElement.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                btnElement.disabled = true;
                btnElement.classList.add('cursor-default');
            }
                updateProgress();
                
                // Unlock the next item visually
                const allSidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
                const currIdx = allSidebarItems.findIndex(i => i.getAttribute('data-topic') === topicId);
                if (currIdx >= 0 && currIdx < allSidebarItems.length - 1) {
                    const nextItem = allSidebarItems[currIdx + 1];
                    nextItem.classList.remove('opacity-50', 'pointer-events-none');
                    const nextIcon = nextItem.querySelector('i');
                    if (nextIcon && nextItem.dataset.origIcon) {
                        nextIcon.className = nextItem.dataset.origIcon;
                    }
                }
                
                // Automatically move to the next chapter after a short delay
                setTimeout(() => {
                    const sidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
                    const currentIndex = sidebarItems.findIndex(item => item.getAttribute('data-topic') === topicId);
                    if (currentIndex >= 0 && currentIndex < sidebarItems.length - 1) {
                        const nextTopicId = sidebarItems[currentIndex + 1].getAttribute('data-topic');
                        showContent(nextTopicId);
                    } else if (currentIndex === sidebarItems.length - 1) {
                        window.location.href = 'fullstack_quiz_page.php';
                    }
                }, 800);
            }).catch(err => {
                console.error(err);
                if (btnElement) {
                    btnElement.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
                }
            });
        }

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('hidden');
        }

        function copyCode(button) {
            const text = button.parentElement.querySelector('code').textContent;
            navigator.clipboard.writeText(text).then(() => {
                const originalText = button.textContent;
                button.textContent = 'Copied!';
                button.style.background = '#10b981';
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.background = '#4f46e5';
                }, 2000);
            });
        }

        function clearSearch() {
            document.getElementById('globalSearch').value = '';
            document.getElementById('clearSearch').classList.add('hidden');
            document.getElementById('searchDropdown').classList.remove('active');
        }

        function initializeGlobalSearch() {
            const searchInput = document.getElementById('globalSearch');
            const clearButton = document.getElementById('clearSearch');
            const searchDropdown = document.getElementById('searchDropdown');
            
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase().trim();
                
                if (searchTerm) clearButton.classList.remove('hidden');
                else clearButton.classList.add('hidden');
                
                if (searchTerm.length < 2) {
                    searchDropdown.classList.remove('active');
                    return;
                }
                
                const results = [];
                for (const [topicId, data] of Object.entries(topicData)) {
                    const titleMatch = data.title.toLowerCase().includes(searchTerm);
                    const keywordMatch = data.keywords.some(k => k.toLowerCase().includes(searchTerm));
                    
                    if (titleMatch || keywordMatch) {
                        results.push({ topicId, title: data.title, unit: data.unit });
                    }
                }
                if (results.length > 0) {
                    searchDropdown.innerHTML = results.map(r => `
                        <div class="search-result-item" onclick="navigateToTopic('${r.topicId}')">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="font-semibold text-gray-800">${r.title}</div>
                                    <div class="text-sm text-gray-500">${r.unit}</div>
                                </div>
                                <i class="fas fa-arrow-right text-gray-400"></i>
                            </div>
                        </div>
                    `).join('');
                    searchDropdown.classList.add('active');
                } else {
                    searchDropdown.innerHTML = `
                        <div class="no-results">
                            <p>No topics found</p>
                        </div>
                    `;
                    searchDropdown.classList.add('active');
                }
            });
            
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
                    searchDropdown.classList.remove('active');
                }
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            if (typeof Prism !== 'undefined') Prism.highlightAll();
            injectCompletionButtons();
            loadProgress();
            initializeGlobalSearch();
            
            const sidebarItemsList = Array.from(document.querySelectorAll('.sidebar-item'));
            sidebarItemsList.forEach((item, index) => {
                const totalCompleted = completedTopics.size;
                if (index > totalCompleted) {
                    item.classList.add('opacity-50', 'pointer-events-none');
                    const icon = item.querySelector('i');
                    if (icon) {
                        item.dataset.origIcon = icon.className;
                        icon.className = 'fas fa-lock mr-2';
                    }
                }
            });
            
            const firstItem = document.querySelector('.sidebar-item');
            if (firstItem && !firstItem.classList.contains('topic-completed')) {
                firstItem.classList.add('active');
            }
        });

        function navigateToTopic(topicId) {
            showContent(topicId);
            clearSearch();
        }

    </script>
</body>
</html>