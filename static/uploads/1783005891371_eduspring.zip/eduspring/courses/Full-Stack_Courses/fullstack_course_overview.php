<?php
session_start();

include("../../db.php");

// ✅ get user id
if(!isset($_SESSION['user_id'])){
    header("Location: /eduspring/signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ get course id (fullstack = 3)
$slug = "fullstack";

$stmt = $conn->prepare("SELECT id FROM courses WHERE slug=?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$res = $stmt->get_result();
$course = $res->fetch_assoc();

if(!$course){
    die("Course not found");
}

$course_id = $course['id'];

$checkEnroll = $conn->prepare("SELECT * FROM enrollments WHERE user_id=? AND course_id=?");
$checkEnroll->bind_param("ii", $user_id, $course_id);
$checkEnroll->execute();
$enrollRes = $checkEnroll->get_result();

if($enrollRes->num_rows == 0){
    header("Location: /eduspring/courses.php");
    exit();
}

$checkProgress = $conn->prepare("
SELECT * FROM course_progress 
WHERE user_id=? AND course_id=?
");
$checkProgress->bind_param("ii", $user_id, $course_id);
$checkProgress->execute();
$resCheck = $checkProgress->get_result();

if($resCheck->num_rows == 0){
    $insert = $conn->prepare("
    INSERT INTO course_progress(user_id, course_id, total_topics, completed_topics, progress_percent)
    VALUES(?, ?, 30, 0, 0)
    ");
    $insert->bind_param("ii", $user_id, $course_id);
    $insert->execute();
}

// ✅ get progress
$stmt = $conn->prepare("
SELECT progress_percent 
FROM course_progress 
WHERE user_id=? AND course_id=?
");

$stmt->bind_param("ii", $user_id, $course_id);
$stmt->execute();
$res = $stmt->get_result()->fetch_assoc();

$progress = ($res && isset($res['progress_percent'])) ? $res['progress_percent'] : 0;

// ✅ check quiz passed
$quizCheck = $conn->prepare("
SELECT passed FROM quiz_results 
WHERE user_id=? AND course_id=? 
ORDER BY id DESC LIMIT 1
");

$quizCheck->bind_param("ii", $user_id, $course_id);
$quizCheck->execute();
$qRes = $quizCheck->get_result()->fetch_assoc();

$quizPassed = ($qRes && $qRes['passed'] == 1);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Full-Stack Web Dev Masterclass - Learnify</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        body { font-family: 'Inter', sans-serif; }
        
        .text-fullstack {
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .bg-fullstack {
            background: linear-gradient(135deg, #4f46e5, #7c3aed);
        }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

    <!-- Header -->
    <?php include '../../navbar.php'; ?>

    <!-- Hero Section -->
    <section class="bg-slate-900 py-16 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-indigo-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="container mx-auto px-4 max-w-6xl relative z-10">
            <div class="flex flex-col md:flex-row gap-8 items-center">
                <div class="flex-1">
                    <div class="inline-block bg-indigo-500/20 border border-indigo-500/30 text-indigo-400 font-bold px-3 py-1 rounded-full text-xs mb-4 tracking-wide uppercase">
                        Comprehensive Path
                    </div>
                    <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
                        Full-Stack Web Dev <span class="text-fullstack">Masterclass</span>
                    </h1>
                    <p class="text-lg text-slate-400 mb-8 leading-relaxed max-w-2xl">
                        Master frontend interfaces and backend APIs. Learn HTML, CSS, JavaScript, React, Node.js, Express, and MongoDB to build complete, scalable web applications from scratch.
                    </p>
                    <div class="flex flex-wrap gap-6">
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-clock text-indigo-500"></i> 120 Hours Total
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-signal text-indigo-500"></i> Beginner to Advanced
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-globe text-indigo-500"></i> 100% Online & Self-paced
                        </div>
                    </div>
                </div>
                <div class="w-32 h-32 md:w-48 md:h-48 bg-white/5 rounded-3xl flex items-center justify-center border border-white/10 shadow-2xl backdrop-blur-sm transform rotate-3 hover:rotate-0 transition-transform duration-500">
                    <i class="fas fa-laptop-code text-7xl md:text-8xl text-fullstack drop-shadow-lg"></i>
                </div>
            </div>
        </div>
    </section>

    <main class="flex-1 container mx-auto px-4 py-12 max-w-6xl">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <!-- Course Info Left Column -->
            <div class="lg:col-span-2 space-y-12">
                <!-- About -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">About this Course</h2>
                    <p class="text-gray-600 leading-relaxed mb-4">
                        This comprehensive learning path is engineered to take you from a web development novice to a highly capable Full-Stack engineer. You'll understand how browsers render interfaces, how to write clean component-based React code, and how to build robust, secure backend APIs connected to NoSQL databases.
                    </p>
                    <p class="text-gray-600 leading-relaxed">
                        By the end of this course, you will be fully prepared to tackle the final assessment and earn your auto-generated digital certification, proving your expertise to potential employers.
                    </p>
                </section>

                <!-- What You'll Learn (Coverage) -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">Course Coverage</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Semantic HTML5 & Modern CSS3</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Modern JavaScript (ES6+)</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">React Fundamentals & Hooks</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Node.js Core & Architecture</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Express.js API Development</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">RESTful API Design & Middleware</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">MongoDB & Mongoose ODM</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-indigo-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Full-Stack Integration & Deployment</span>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Sticky Action Card Right Column -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-gray-100 p-8 sticky top-24">
                    <h3 class="text-xl font-bold text-gray-900 mb-6">Your Progress</h3>
                    
                    <!-- Progress Bar -->
                    <div class="mb-8">
                        <div class="flex justify-between text-sm font-bold mb-2">
                            <span class="text-gray-600">Course Completion</span>
                            <span id="progressText" class="text-indigo-600">0%</span>
                        </div>
                        <div class="w-full bg-indigo-50 rounded-full h-3">
                            <div id="progressBar" class="bg-fullstack h-3 rounded-full transition-all duration-1000 ease-out shadow-sm" style="width: 0%"></div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="space-y-4">
                        <!-- 1. Learning Material -->
                        <a id="btnCourse" href="fullstack_final_page.php" class="flex items-center justify-center w-full py-3.5 px-4 bg-fullstack text-white font-bold rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
                            <i class="fas fa-play-circle mr-2 text-lg"></i> Start Learning
                        </a>
                        
                        <!-- 2. Quiz -->
                        <a id="btnQuiz" href="fullstack_quiz_page.php" class="flex items-center justify-center w-full py-3.5 px-4 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed transition-all duration-300 pointer-events-none">
                            <i class="fas fa-tasks mr-2 text-lg"></i> Take Certification Quiz
                            <i class="fas fa-lock ml-auto text-sm"></i>
                        </a>
                        
                        <!-- 3. Certificate -->
                        <button id="btnCert" class="flex items-center justify-center w-full py-3.5 px-4 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed transition-all duration-300 pointer-events-none">
                            <i class="fas fa-certificate mr-2 text-lg"></i> Download Certificate
                            <i class="fas fa-lock ml-auto text-sm"></i>
                        </button>
                    </div>
                    
                    <!-- Status Message -->
                    <div id="statusMessage" class="mt-6 text-sm text-center text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-100 font-medium">
                        Complete the course material (100%) to unlock the certification quiz.
                    </div>
                </div>
            </div>

        </div>
    </main>

    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 mt-auto text-center">
        <div class="container mx-auto px-4">
            <p class="text-sm">© 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>

    <script>

        const progressPercent = <?php echo $progress; ?>;
        const quizPassed = <?php echo $quizPassed ? 'true' : 'false'; ?>;

        document.addEventListener('DOMContentLoaded', () => {
           
            // Update UI Bars
            document.getElementById('progressBar').style.width = progressPercent + '%';
            document.getElementById('progressText').textContent = progressPercent + '%';
            
            // Button Elements
            const btnCourse = document.getElementById('btnCourse');
            const btnQuiz = document.getElementById('btnQuiz');
            const btnCert = document.getElementById('btnCert');
            const statusMessage = document.getElementById('statusMessage');
                        
            // 2. UI State Logic
            if (progressPercent > 0 && progressPercent < 100) {
                btnCourse.innerHTML = '<i class="fas fa-play-circle mr-2 text-lg"></i> Continue Learning';
            } 
            else if (progressPercent >= 100) {
                btnCourse.innerHTML = '<i class="fas fa-book-reader mr-2 text-lg"></i> Review Course Material';
                btnCourse.classList.replace('bg-fullstack', 'bg-slate-800');
                
                // Unlock the Quiz Button
                btnQuiz.href = "fullstack_quiz_page.php";
                btnQuiz.innerHTML = '<i class="fas fa-tasks mr-2 text-lg"></i> Take Certification Quiz';
                btnQuiz.classList.remove('bg-gray-100', 'text-gray-400', 'cursor-not-allowed', 'pointer-events-none');
                btnQuiz.classList.add('bg-fullstack', 'text-white', 'shadow-md', 'hover:shadow-lg', 'hover:-translate-y-0.5');
                statusMessage.innerHTML = "<span class='text-indigo-600 font-bold'>Course completed!</span> You may now take the exam.";
                
                // If Quiz Passed -> Unlock Certificate
                if (quizPassed) {
                    btnQuiz.innerHTML = '<i class="fas fa-check-double mr-2 text-lg"></i> Review Quiz Results';
                    btnQuiz.classList.replace('bg-fullstack', 'bg-slate-800');
                    
                    btnCert.innerHTML = '<i class="fas fa-certificate mr-2 text-lg"></i> Download Certificate';
                    btnCert.classList.remove('bg-gray-100', 'text-gray-400', 'cursor-not-allowed', 'pointer-events-none');
                    btnCert.classList.add('bg-green-500', 'text-white', 'shadow-md', 'hover:shadow-lg', 'hover:bg-green-600', 'hover:-translate-y-0.5');
                    statusMessage.innerHTML = "<span class='text-green-600 font-bold'>Congratulations!</span> You are officially certified.";
                    
                    // Navigate to the certificate page
                    btnCert.addEventListener('click', () => {
                        window.location.href = 'certificate_fullstack.php?course=fullstack';
                    });
                }
            }
        });
    </script>
</body>
</html>