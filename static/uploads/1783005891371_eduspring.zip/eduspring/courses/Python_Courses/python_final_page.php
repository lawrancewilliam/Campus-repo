<?php
session_start();

if(!isset($_SESSION['user_email'])){
    header("Location: /eduspring/signin.php?error=login_required");
    exit();
}

include("../../db.php");

// get user id
$email = $_SESSION['user_email'];

$stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
$userData = $res->fetch_assoc();

if(!$userData){
    die("User not found");
}

$user_id = $userData['id'];

// check enrolled or not (Python course_id = 1)
$check = $conn->prepare("SELECT * FROM enrollments WHERE user_id=? AND course_id=1");
$check->bind_param("i", $user_id);
$check->execute();
$result = $check->get_result();

if($result->num_rows == 0){
    // not enrolled → redirect
    header("Location: /eduspring/courses.php");
    exit();
}

// 🔥 GET PROGRESS FROM DB

$checkProgress = $conn->prepare("
SELECT * FROM course_progress 
WHERE user_id=? AND course_id=1
");
$checkProgress->bind_param("i", $user_id);
$checkProgress->execute();
$resCheck = $checkProgress->get_result();

if($resCheck->num_rows == 0){
    // insert default row
    $insert = $conn->prepare("
    INSERT INTO course_progress(user_id, course_id, total_topics, completed_topics, progress_percent)
    VALUES(?, 1, 23, 0, 0)
    ");
    $insert->bind_param("i", $user_id);
    $insert->execute();
}

$stmt = $conn->prepare("
SELECT total_topics, completed_topics, progress_percent 
FROM course_progress 
WHERE user_id=? AND course_id=1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();
$progress = $res->fetch_assoc();

if($progress){
    $total = $progress['total_topics'];
    $completed = $progress['completed_topics'];
    $progressPercent = $progress['progress_percent'];
}else{
    // default values if no record
    $total = 23;
    $completed = 0;
    $progressPercent = 0;
}

$completedTopics = [];

$getTopics = $conn->prepare("
SELECT topic_name FROM topic_progress
WHERE user_id=? AND course_id=1
");
$getTopics->bind_param("i", $user_id);
$getTopics->execute();
$resTopics = $getTopics->get_result();

while($row = $resTopics->fetch_assoc()){
    $completedTopics[] = $row['topic_name'];
}

function isUnlocked($topicIndex, $completedCount){
    return $topicIndex <= ($completedCount + 1);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Programming Tutorial - Complete Guide</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>
    
    <style>
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .sidebar-item { transition: all 0.3s ease; }
        .sidebar-item:hover { transform: translateX(5px); }
        .sidebar-item.active { background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%); color: white; }
        .topic-completed { position: relative; }
        .topic-completed::after { content: '✓'; position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: #10b981; font-weight: bold; }
        .content-section { display: none; animation: fadeIn 0.5s ease-in; }
        .content-section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .code-toolbar { position: relative; background: #2d2d2d; border-radius: 8px; overflow: hidden; margin: 1rem 0; }
        .copy-button { position: absolute; top: 10px; right: 10px; background: #4f46e5; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; transition: background 0.3s ease; z-index: 10; }
        pre[class*="language-"] { margin: 0; padding: 20px; background: transparent; }
        .progress-ring { transform: rotate(-90deg); }
        .progress-ring-circle { transition: stroke-dashoffset 0.35s; stroke: #10b981; stroke-dasharray: 75.398 75.398; }
        .search-dropdown { position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #e5e7eb; border-radius: 8px; margin-top: 4px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); max-height: 400px; overflow-y: auto; z-index: 50; display: none; }
        .search-dropdown.active { display: block; }
        .search-highlight { background-color: #fef3c7; color: #1f2937; font-weight: bold; }
        table th { background: #6366f1; color: white; }
    </style>
</head>
<body class="bg-gray-50">

    <header class="gradient-bg text-white shadow-lg sticky top-0 z-40">
        <div class="container mx-auto px-4 py-4">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <button id="menuToggle" class="md:hidden text-white" onclick="toggleSidebar()">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold flex items-center gap-2">
                        <i class="fab fa-python"></i> Python Programming
                    </h1>
                </div>
                <div class="relative w-full md:w-96">
                    <input type="text" id="globalSearch" placeholder="Search Python topics..." 
                           class="w-full px-4 py-2 pl-10 pr-10 text-gray-900 bg-white rounded-lg border-none focus:outline-none focus:ring-2 focus:ring-indigo-400 shadow-md placeholder-gray-400">
                    <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    <div id="searchDropdown" class="search-dropdown text-gray-800"></div>
                </div>
                <div class="flex items-center gap-3">
                    <div class="text-right hidden md:block">
                        <div class="text-sm opacity-90">Overall Progress</div>
                        <div class="font-bold" id="progressText"><?php echo $progressPercent; ?>%</div>
                    </div>
                    <svg width="30" height="30" class="progress-ring">
                        <circle cx="15" cy="15" r="12" stroke="#ffffff30" stroke-width="3" fill="none"/>
                        <circle id="progressCircle" class="progress-ring-circle" cx="15" cy="15" r="12" stroke-width="3" fill="none" stroke-dashoffset="75.398"/>
                    </svg>
                </div>
            </div>
        </div>
    </header>

    <div class="flex max-w-[1440px] mx-auto">
        <aside id="sidebar" class="w-64 bg-white shadow-lg h-screen sticky top-16 overflow-y-auto hidden md:block">
            <div class="p-4">
                <h2 class="text-lg font-bold mb-4 text-gray-800">Course Content</h2>
                
<h3 class="text-xs font-bold text-gray-400 uppercase mb-2">Unit 1 – Basics</h3>
<div class="space-y-1 mb-6">

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100"
         data-topic="intro" data-index="1" onclick="show('intro')">
        <i class="fas fa-book-open mr-2"></i>Introduction
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(2,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="interpreter" data-index="2"
         onclick="<?= isUnlocked(2,$completed) ? "show('interpreter')" : '' ?>">
        <i class="fas <?= isUnlocked(2,$completed) ? 'fa-terminal' : 'fa-lock' ?> mr-2"></i>Interpreter
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(3,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="variables" data-index="3"
         onclick="<?= isUnlocked(3,$completed) ? "show('variables')" : '' ?>">
        <i class="fas <?= isUnlocked(3,$completed) ? 'fa-tags' : 'fa-lock' ?> mr-2"></i>Variables
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(4,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="operators" data-index="4"
         onclick="<?= isUnlocked(4,$completed) ? "show('operators')" : '' ?>">
        <i class="fas <?= isUnlocked(4,$completed) ? 'fa-calculator' : 'fa-lock' ?> mr-2"></i>Arithmetic Operators
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(5,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="loops" data-index="5"
         onclick="<?= isUnlocked(5,$completed) ? "show('loops')" : '' ?>">
        <i class="fas <?= isUnlocked(5,$completed) ? 'fa-redo' : 'fa-lock' ?> mr-2"></i>Loops
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(6,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="functions" data-index="6"
         onclick="<?= isUnlocked(6,$completed) ? "show('functions')" : '' ?>">
        <i class="fas <?= isUnlocked(6,$completed) ? 'fa-code' : 'fa-lock' ?> mr-2"></i>Functions
    </div>

</div>


<h3 class="text-xs font-bold text-gray-400 uppercase mb-2">Unit 2 – Data Types</h3>
<div class="space-y-1 mb-6">

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(7,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="datatypes" data-index="7"
         onclick="<?= isUnlocked(7,$completed) ? "show('datatypes')" : '' ?>">
        <i class="fas <?= isUnlocked(7,$completed) ? 'fa-database' : 'fa-lock' ?> mr-2"></i>Python Data Types
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(8,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="lists" data-index="8"
         onclick="<?= isUnlocked(8,$completed) ? "show('lists')" : '' ?>">
        <i class="fas <?= isUnlocked(8,$completed) ? 'fa-list-ul' : 'fa-lock' ?> mr-2"></i>Lists
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(9,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="tuples" data-index="9"
         onclick="<?= isUnlocked(9,$completed) ? "show('tuples')" : '' ?>">
        <i class="fas <?= isUnlocked(9,$completed) ? 'fa-layer-group' : 'fa-lock' ?> mr-2"></i>Tuples
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(10,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="sets" data-index="10"
         onclick="<?= isUnlocked(10,$completed) ? "show('sets')" : '' ?>">
        <i class="fas <?= isUnlocked(10,$completed) ? 'fa-shapes' : 'fa-lock' ?> mr-2"></i>Sets
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(11,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="dictionary" data-index="11"
         onclick="<?= isUnlocked(11,$completed) ? "show('dictionary')" : '' ?>">
        <i class="fas <?= isUnlocked(11,$completed) ? 'fa-book' : 'fa-lock' ?> mr-2"></i>Dictionary
    </div>

</div>

<h3 class="text-xs font-bold text-gray-400 uppercase mb-2">Unit 3 – File Handling</h3>
<div class="space-y-1 mb-6">

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(12,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="fileintro" data-index="12"
         onclick="<?= isUnlocked(12,$completed) ? "show('fileintro')" : '' ?>">
        <i class="fas <?= isUnlocked(12,$completed) ? 'fa-folder-open' : 'fa-lock' ?> mr-2"></i>File Handling
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(13,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="reading" data-index="13"
         onclick="<?= isUnlocked(13,$completed) ? "show('reading')" : '' ?>">
        <i class="fas <?= isUnlocked(13,$completed) ? 'fa-file-import' : 'fa-lock' ?> mr-2"></i>Reading Files
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(14,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="writing" data-index="14"
         onclick="<?= isUnlocked(14,$completed) ? "show('writing')" : '' ?>">
        <i class="fas <?= isUnlocked(14,$completed) ? 'fa-file-export' : 'fa-lock' ?> mr-2"></i>Writing Files
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(15,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="exception" data-index="15"
         onclick="<?= isUnlocked(15,$completed) ? "show('exception')" : '' ?>">
        <i class="fas <?= isUnlocked(15,$completed) ? 'fa-exclamation-triangle' : 'fa-lock' ?> mr-2"></i>Exception Handling
    </div>

</div>


<h3 class="text-xs font-bold text-gray-400 uppercase mb-2">Unit 4 – Modules</h3>
<div class="space-y-1 mb-6">

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(16,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="modules" data-index="16"
         onclick="<?= isUnlocked(16,$completed) ? "show('modules')" : '' ?>">
        <i class="fas <?= isUnlocked(16,$completed) ? 'fa-cubes' : 'fa-lock' ?> mr-2"></i>Modules
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(17,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="import" data-index="17"
         onclick="<?= isUnlocked(17,$completed) ? "show('import')" : '' ?>">
        <i class="fas <?= isUnlocked(17,$completed) ? 'fa-sign-in-alt' : 'fa-lock' ?> mr-2"></i>Import Statement
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(18,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="builtin" data-index="18"
         onclick="<?= isUnlocked(18,$completed) ? "show('builtin')" : '' ?>">
        <i class="fas <?= isUnlocked(18,$completed) ? 'fa-microchip' : 'fa-lock' ?> mr-2"></i>Built-in Modules
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(19,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="packages" data-index="19"
         onclick="<?= isUnlocked(19,$completed) ? "show('packages')" : '' ?>">
        <i class="fas <?= isUnlocked(19,$completed) ? 'fa-box-open' : 'fa-lock' ?> mr-2"></i>Packages
    </div>

</div>


<h3 class="text-xs font-bold text-gray-400 uppercase mb-2">Unit 5 – OOP</h3>
<div class="space-y-1 mb-6">

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(20,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="class" data-index="20"
         onclick="<?= isUnlocked(20,$completed) ? "show('class')" : '' ?>">
        <i class="fas <?= isUnlocked(20,$completed) ? 'fa-sitemap' : 'fa-lock' ?> mr-2"></i>Class
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(21,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="object" data-index="21"
         onclick="<?= isUnlocked(21,$completed) ? "show('object')" : '' ?>">
        <i class="fas <?= isUnlocked(21,$completed) ? 'fa-cube' : 'fa-lock' ?> mr-2"></i>Object
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(22,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="inheritance" data-index="22"
         onclick="<?= isUnlocked(22,$completed) ? "show('inheritance')" : '' ?>">
        <i class="fas <?= isUnlocked(22,$completed) ? 'fa-project-diagram' : 'fa-lock' ?> mr-2"></i>Inheritance
    </div>

    <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100 <?= !isUnlocked(23,$completed) ? 'opacity-50 pointer-events-none' : '' ?>"
         data-topic="polymorphism" data-index="23"
         onclick="<?= isUnlocked(23,$completed) ? "show('polymorphism')" : '' ?>">
        <i class="fas <?= isUnlocked(23,$completed) ? 'fa-th-large' : 'fa-lock' ?> mr-2"></i>Polymorphism
    </div>

</div>
</div>
        </aside>

        <main class="flex-1 p-6 md:p-10 bg-white shadow-inner min-h-screen">
            
            <div id="intro" class="section active content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Introduction to Python Programming</h1>
                <p>Python is a high-level, interpreted, and general-purpose programming language created by Guido van Rossum and released in 1991. Python focuses on simplicity and readability which makes it one of the easiest languages to learn for beginners.</p>
                <p>Python allows developers to write programs with fewer lines of code compared to other programming languages. Because of its powerful libraries and simple syntax, Python is widely used in software development, data science, artificial intelligence, web development, and automation.</p>
                
                <h2 class="text-xl font-bold mt-6">Features of Python</h2>
                <ul class="list-disc pl-5 space-y-2">
                    <li>Simple and easy syntax</li>
                    <li>Interpreted programming language</li>
                    <li>Platform independent</li>
                    <li>Open source</li>
                    <li>Supports Object Oriented Programming</li>
                    <li>Large standard library</li>
                </ul>

                <h2 class="text-xl font-bold mt-6">Applications of Python</h2>
                <ul class="list-disc pl-5 space-y-2">
                    <li>Web development</li>
                    <li>Machine learning</li>
                    <li>Artificial intelligence</li>
                    <li>Automation</li>
                    <li>Data science</li>
                    <li>Game development</li>
                </ul>

                <h2 class="text-xl font-bold mt-6">Example Program</h2>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">print("Hello World")</code></pre></div>
                <h3>Output</h3>
                <div class="code-toolbar"><pre><code class="language-plaintext">Hello World</code></pre></div>
            </div>

            <div id="interpreter" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Python Interpreter</h1>
                <p>Python is an interpreted language which means Python code is executed line by line using a program called the Python Interpreter.</p>
                <h2 class="text-xl font-bold">Types of Execution</h2>
                <h3>Script Mode</h3>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">print("Welcome to Python")</code></pre></div>
                <h3>Interactive Mode</h3>
                <div class="code-toolbar"><pre><code class="language-python">>>> 5 + 3
8
>>> print("Python")
Python</code></pre></div>
            </div>

            <div id="variables" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Variables in Python</h1>
                <p>A variable is a name used to store a value in memory. Python automatically creates variables when values are assigned.</p>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">x = 10
name = "Python"
price = 25.5</code></pre></div>
                <h2 class="text-xl font-bold mt-6">Rules for Variables</h2>
                <ul class="list-disc pl-5 space-y-2">
                    <li>Must start with a letter or underscore</li>
                    <li>Cannot start with a number</li>
                    <li>No spaces allowed</li>
                    <li>Case sensitive</li>
                </ul>
                <h2 class="text-xl font-bold mt-6">Multiple Assignment</h2>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">a,b,c = 10,20,30
print(a)
print(b)
print(c)</code></pre></div>
                <h2 class="text-xl font-bold mt-6">Dynamic Typing</h2>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">x = 10
x = "Hello"</code></pre></div>
            </div>

            <div id="operators" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Arithmetic Operators</h1>
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse border border-gray-200">
                        <thead class="bg-indigo-600 text-white">
                            <tr>
                                <th class="p-3 border">Operator</th>
                                <th class="p-3 border">Name</th>
                                <th class="p-3 border">Description</th>
                                <th class="p-3 border">Example</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td class="p-3 border">+</td><td class="p-3 border">Addition</td><td class="p-3 border">Adds numbers</td><td class="p-3 border">a + b</td></tr>
                            <tr><td class="p-3 border">-</td><td class="p-3 border">Subtraction</td><td class="p-3 border">Subtracts</td><td class="p-3 border">a - b</td></tr>
                            <tr><td class="p-3 border">*</td><td class="p-3 border">Multiplication</td><td class="p-3 border">Multiplies</td><td class="p-3 border">a * b</td></tr>
                            <tr><td class="p-3 border">/</td><td class="p-3 border">Division</td><td class="p-3 border">Floating result</td><td class="p-3 border">a / b</td></tr>
                            <tr><td class="p-3 border">%</td><td class="p-3 border">Modulus</td><td class="p-3 border">Remainder</td><td class="p-3 border">a % b</td></tr>
                            <tr><td class="p-3 border">**</td><td class="p-3 border">Exponent</td><td class="p-3 border">Power of a number</td><td class="p-3 border">a ** b</td></tr>
                            <tr><td class="p-3 border">//</td><td class="p-3 border">Floor Division</td><td class="p-3 border">Division without decimal</td><td class="p-3 border">a // b</td></tr>
                        </tbody>
                    </table>
                </div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
a = 10
b = 3

print("Addition:", a + b)
print("Subtraction:", a - b)
print("Multiplication:", a * b)
print("Division:", a / b)
print("Modulus:", a % b)
print("Exponent:", a ** b)
print("Floor Division:", a // b)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Output</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Addition: 13
Subtraction: 7
Multiplication: 30
Division: 3.3333
Modulus: 1
Exponent: 1000
Floor Division: 3
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Explanation of Each Operation</h2>

<h3 class="text-xl font-bold mt-6">Addition (+)</h3>
<p>
The addition operator adds two numbers and returns the result.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 5
y = 7
print(x + y)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Subtraction (-)</h3>
<p>
Subtracts the second number from the first number.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
y = 4
print(x - y)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Multiplication (*)</h3>
<p>
Used to multiply numbers together.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 6
y = 3
print(x * y)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Division (/)</h3>
<p>
Divides the first number by the second number and returns a floating-point result.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
y = 2
print(x / y)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Modulus (%)</h3>
<p>
Returns the remainder after division.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(10 % 3)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Exponent (**)</h3>
<p>
Raises the first number to the power of the second number.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(2 ** 3)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Floor Division (//)</h3>
<p>
Performs division and rounds the result down to the nearest whole number.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(10 // 3)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Important Notes</h2>
                <ul class="list-disc pl-5 space-y-2">
                    <li>Division always returns a floating-point value.</li>
                    <li>Floor division removes the decimal part.</li>
                    <li>Exponent operator is used for power calculations.</li>
                    <li>Modulus is useful for checking even or odd numbers.</li>
                </ul>


<h2 class="text-xl font-bold mt-6">Real World Example</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
price = 50
quantity = 4

total = price * quantity

print("Total price:", total)
</code></pre>
            </div>
</div>
            <div id="loops" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Looping Statements</h1>
                <p>Loops allow a block of code to run repeatedly until a condition becomes false.</p>
                <h2 class="text-xl font-bold mt-6">For Loop</h2>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">for i in range(5):
    print(i)</code></pre></div>
                <h2 class="text-xl font-bold mt-6">While Loop</h2>
                <div class="code-toolbar"><button class="copy-button" onclick="copyCode(this)">Copy</button><pre><code class="language-python">i = 1
while i <= 5:
    print(i)
    i = i + 1</code></pre></div>
                <h2 class="text-xl font-bold mt-6">Control Statements</h2>
                <p><b>Break:</b> Stops the loop completely. <br><b>Continue:</b> Skips the current iteration.</p>
            </div>

            <div id="functions" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Functions in Python</h1>
               

<p> 
A function is a block of code that performs a specific task.
Functions help reduce repetition and make programs easier to manage.
</p>

<h2 class="text-xl font-bold mt-6">Syntax</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def function_name():
    statements
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def greet():
    print("Hello Python")

greet()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Function with Parameters</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def add(a, b):
    print(a + b)

add(5, 3)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Function with Return</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def square(n):
    return n * n

print(square(4))
</code></pre>
</div>

            </div>

            <div id="datatypes" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Python Data Types</h1>
               
<h1>Python Data Types</h1>

<p>
In programming, a data type specifies the type of value that a variable can store.
Python provides many built-in data types that allow programmers to store and
manipulate different kinds of information such as numbers, text, and collections.
</p>

<p>
Unlike many other programming languages, Python automatically determines the data
type of a variable when a value is assigned to it. This feature is known as
<b>Dynamic Typing</b>.
</p>

<h2 class="text-xl font-bold mt-6">Example</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
name = "Python"
price = 45.5
</code></pre>
</div>

<p>
In the above example:
</p>

<ul>
<li>x is an integer</li>
<li>name is a string</li>
<li>price is a floating point number</li>
</ul>

<h2 class="text-xl font-bold mt-6">1. Numeric Data Types</h2>

<p>
Numeric data types are used to store numerical values.
Python supports three numeric types.
</p>

<ul>
<li>Integer (int)</li>
<li>Floating point (float)</li>
<li>Complex numbers (complex)</li>
</ul>

<h3 class="text-xl font-bold mt-6">Integer (int)</h3>

<p>
Integers are whole numbers without decimal points.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
y = -25
print(x)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Float</h3>

<p>
Float values contain decimal points.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
price = 45.75
temperature = 36.5
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Complex Numbers</h3>

<p>
Complex numbers contain real and imaginary parts.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
z = 3 + 4j
print(z)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">2. String Data Type</h2>

<p>
A string represents textual data. Strings are written inside
single quotes or double quotes.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
name = "Python"
message = 'Welcome to programming'
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">String Operations</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
text = "Python"

print(len(text))
print(text.upper())
print(text.lower())
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">3. Boolean Data Type</h2>

<p>
Boolean values represent logical values. They can be either
True or False.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = True
y = False

print(x)
print(y)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">4. Sequence Data Types</h2>

<p>
Sequence types store multiple values in an ordered collection.
</p>

<ul>
<li>List</li>
<li>Tuple</li>
<li>Range</li>
</ul>

<h3 class="text-xl font-bold mt-6">Range Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = range(5)

for i in numbers:
    print(i)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">5. Set Data Type</h2>

<p>
A set is an unordered collection of unique elements.
Duplicate values are automatically removed.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
s = {1,2,3,3,4}
print(s)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">6. Dictionary Data Type</h2>

<p>
A dictionary stores data in key-value pairs.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student = {
 "name":"John",
 "age":20,
 "course":"Python"
}

print(student["name"])
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Checking Data Type</h2>

<p>
Python provides the <b>type()</b> function to check the data type of a variable.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
print(type(x))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Type Conversion</h2>

<p>
Python allows converting one data type to another.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = "10"

y = int(x)

print(y)
</code></pre>
</div>

</div>


            <div id="lists" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Lists in Python</h1>

<p>
A list is one of the most commonly used data structures in Python.
A list is an ordered collection of elements that can store multiple values
in a single variable. Lists can contain elements of different data types
such as integers, strings, and even other lists.
</p>

<h2 class="text-xl font-bold mt-6">Characteristics of Python Lists</h2>

<ul>
<li>Lists are ordered collections</li>
<li>Lists are mutable (values can be changed)</li>
<li>Lists allow duplicate values</li>
<li>Lists can store multiple data types</li>
<li>Lists are written using square brackets [ ]</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating a List</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30, 40, 50]
print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
[10, 20, 30, 40, 50]
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Accessing List Elements</h2>

<p>
List elements can be accessed using indexing. The index of the first element
is always 0.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30, 40]

print(numbers[0])
print(numbers[2])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
10
30
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Negative Indexing</h2>

<p>
Negative indexing allows accessing elements from the end of the list.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30, 40]

print(numbers[-1])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
40
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">List Slicing</h2>

<p>
Slicing allows extracting a part of a list.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30, 40, 50]

print(numbers[1:4])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
[20, 30, 40]
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Changing List Elements</h2>

<p>
Since lists are mutable, elements can be modified.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30]

numbers[1] = 100

print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
[10, 100, 30]
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Adding Elements to a List</h2>

<h3 class="text-xl font-bold mt-6">Using append()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30]

numbers.append(40)

print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using insert()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.insert(1, 15)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Removing Elements from a List</h2>

<h3 class="text-xl font-bold mt-6">Using remove()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.remove(20)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using pop()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.pop()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Looping Through a List</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = [10, 20, 30]

for n in numbers:
    print(n)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">List Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
students = ["John", "Mary", "Alex"]

students.append("David")

for s in students:
    print(s)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Lists</h2>

<ul>
<li>Can store multiple values</li>
<li>Supports dynamic resizing</li>
<li>Easy to modify elements</li>
<li>Provides many built-in methods</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Lists</h2>

<ul>
<li>Storing student records</li>
<li>Managing collections of data</li>
<li>Data processing tasks</li>
<li>Iterating through data</li>
</ul>

</div>
       

            <div id="tuples" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Tuples in Python</h1>
                <p>
A tuple is a built-in data structure in Python that allows storing multiple
values in a single variable. Tuples are similar to lists but the main difference
is that tuples are <b>immutable</b>, meaning their elements cannot be changed
after they are created.
</p>

<p>
Tuples are used when a collection of values should remain constant throughout
the program. They are commonly used for storing fixed data such as coordinates,
database records, and configuration settings.
</p>

<h2 class="text-xl font-bold mt-6">Characteristics of Tuples</h2>

<ul>
<li>Tuples are ordered collections of elements.</li>
<li>Tuples are immutable (cannot be modified).</li>
<li>Tuples allow duplicate values.</li>
<li>Tuples can contain different data types.</li>
<li>Tuples are written using parentheses ( ).</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating a Tuple</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10, 20, 30, 40)
print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
(10, 20, 30, 40)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple with Different Data Types</h2>

<p>
A tuple can contain elements of different data types.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
data = (10, "Python", 45.5)
print(data)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Accessing Tuple Elements</h2>

<p>
Tuple elements can be accessed using indexing. The index of the first element
is always 0.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10, 20, 30, 40)

print(numbers[0])
print(numbers[2])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
10
30
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Negative Indexing</h2>

<p>
Negative indexing allows accessing elements from the end of the tuple.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10,20,30,40)

print(numbers[-1])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
40
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple Slicing</h2>

<p>
Slicing allows retrieving a subset of elements from a tuple.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10,20,30,40,50)

print(numbers[1:4])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
(20,30,40)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple Length</h2>

<p>
The number of elements in a tuple can be determined using the <b>len()</b> function.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10,20,30,40)

print(len(numbers))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple Packing</h2>

<p>
When multiple values are assigned to a tuple, it is called tuple packing.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
data = ("John", 20, "Python")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple Unpacking</h2>

<p>
Tuple unpacking allows assigning tuple values to multiple variables.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
data = ("John", 20, "Python")

name, age, course = data

print(name)
print(age)
print(course)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Looping Through a Tuple</h2>

<p>
Tuples can be iterated using loops.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10,20,30)

for n in numbers:
    print(n)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Tuple Methods</h2>

<p>
Tuples have only two built-in methods because they are immutable.
</p>

<table>

<tr>
<th>Method</th>
<th>Description</th>
</tr>

<tr>
<td>count()</td>
<td>Returns the number of times a value appears in the tuple</td>
</tr>

<tr>
<td>index()</td>
<td>Returns the index of the first occurrence of a value</td>
</tr>

</table>

<h3 class="text-xl font-bold mt-6">Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = (10,20,30,20)

print(numbers.count(20))
print(numbers.index(30))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Tuples</h2>

<ul>
<li>Faster than lists for fixed data</li>
<li>Protects data from accidental modification</li>
<li>Uses less memory compared to lists</li>
<li>Suitable for constant collections of values</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Tuples</h2>

<ul>
<li>Storing coordinates (x,y)</li>
<li>Returning multiple values from functions</li>
<li>Database records</li>
<li>Configuration settings</li>
</ul>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student = ("John", 21, "Computer Science")

print("Name:", student[0])
print("Age:", student[1])
print("Course:", student[2])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Name: John
Age: 21
Course: Computer Science
</code></pre>
</div>

</div>

            <div id="sets" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Sets in Python</h1>
                
<p>
A set is a built-in data structure in Python used to store multiple
unique elements in a single variable. Sets are similar to lists and
tuples, but they have special properties such as not allowing duplicate
values and not maintaining a fixed order of elements.
</p>

<p>
Sets are commonly used when we need to store unique values and perform
mathematical operations like union, intersection, and difference.
</p>

<h2 class="text-xl font-bold mt-6">Characteristics of Sets</h2>

<ul>
<li>Sets are unordered collections of elements.</li>
<li>Sets do not allow duplicate values.</li>
<li>Sets are mutable (elements can be added or removed).</li>
<li>Sets can store multiple data types.</li>
<li>Sets are written using curly braces { }.</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating a Set</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = {10, 20, 30, 40}

print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
{10, 20, 30, 40}
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Set with Duplicate Values</h2>

<p>
If duplicate values are included in a set, Python automatically removes them.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
data = {1,2,3,3,4,4,5}

print(data)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
{1,2,3,4,5}
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Creating an Empty Set</h2>

<p>
An empty set cannot be created using {} because it creates a dictionary.
Instead, we use the <b>set()</b> function.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
s = set()

print(type(s))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Adding Elements to a Set</h2>

<h3 class="text-xl font-bold mt-6">Using add()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = {10,20,30}

numbers.add(40)

print(numbers)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using update()</h3>

<p>
The update() method is used to add multiple elements.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.update([50,60])
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Removing Elements from a Set</h2>

<h3 class="text-xl font-bold mt-6">Using remove()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.remove(20)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using discard()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.discard(30)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using pop()</h3>

<p>
The pop() method removes a random element from the set.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers.pop()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Set Operations</h2>

<p>
Sets support mathematical operations like union, intersection,
difference, and symmetric difference.
</p>

<h3 class="text-xl font-bold mt-6">Union</h3>

<p>
Combines elements from two sets.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
A = {1,2,3}
B = {3,4,5}

print(A | B)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Intersection</h3>

<p>
Returns common elements from both sets.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(A & B)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Difference</h3>

<p>
Returns elements present in one set but not in another.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(A - B)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Symmetric Difference</h3>

<p>
Returns elements that are in either set but not in both.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(A ^ B)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Looping Through a Set</h2>

<p>
Sets can be iterated using loops.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
numbers = {10,20,30}

for n in numbers:
    print(n)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Common Set Methods</h2>

<table>

<tr>
<th>Method</th>
<th>Description</th>
</tr>

<tr>
<td>add()</td>
<td>Adds an element to the set</td>
</tr>

<tr>
<td>update()</td>
<td>Adds multiple elements</td>
</tr>

<tr>
<td>remove()</td>
<td>Removes a specific element</td>
</tr>

<tr>
<td>discard()</td>
<td>Removes element without error</td>
</tr>

<tr>
<td>pop()</td>
<td>Removes a random element</td>
</tr>

<tr>
<td>clear()</td>
<td>Removes all elements from the set</td>
</tr>

<tr>
<td>copy()</td>
<td>Returns a copy of the set</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Advantages of Sets</h2>

<ul>
<li>Automatically removes duplicate values</li>
<li>Supports mathematical set operations</li>
<li>Efficient for membership testing</li>
<li>Useful for storing unique data</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Sets</h2>

<ul>
<li>Removing duplicate elements from lists</li>
<li>Performing mathematical set operations</li>
<li>Finding common elements between datasets</li>
<li>Membership testing in data collections</li>
</ul>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
A = {10,20,30}
B = {20,30,40}

print("Union:", A | B)
print("Intersection:", A & B)
print("Difference:", A - B)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Union: {10,20,30,40}
Intersection: {20,30}
Difference: {10}
</code></pre>
</div>

</div>

            <div id="dictionary" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Dictionary in Python</h1>
                
<p>
A dictionary is a built-in data structure in Python used to store data in
<b>key-value pairs</b>. Each element in a dictionary consists of a key and
its corresponding value. Dictionaries are commonly used to represent
structured data such as student information, product details, or user records.
</p>

<p>
Unlike lists and tuples which use numerical indexes, dictionaries use
<b>keys</b> to access values. Keys must be unique and immutable
(such as strings, numbers, or tuples).
</p>

<h2 class="text-xl font-bold mt-6">Characteristics of Dictionaries</h2>

<ul>
<li>Dictionaries store data as key-value pairs.</li>
<li>Dictionaries are mutable (values can be modified).</li>
<li>Keys must be unique.</li>
<li>Dictionaries are unordered collections.</li>
<li>Dictionaries are written using curly braces { }.</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating a Dictionary</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student = {
 "name": "John",
 "age": 20,
 "course": "Python"
}

print(student)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
{'name': 'John', 'age': 20, 'course': 'Python'}
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Accessing Dictionary Values</h2>

<p>
Values in a dictionary can be accessed using their keys.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student = {
 "name":"John",
 "age":20
}

print(student["name"])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
John
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using get() Method</h2>

<p>
The get() method returns the value for a given key without causing an error
if the key does not exist.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(student.get("age"))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Adding Elements to a Dictionary</h2>

<p>
New key-value pairs can be added to a dictionary easily.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student["city"] = "Chennai"

print(student)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Modifying Dictionary Values</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student["age"] = 21
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Removing Elements from a Dictionary</h2>

<h3 class="text-xl font-bold mt-6">Using pop()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student.pop("age")
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using del</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
del student["course"]
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Using clear()</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student.clear()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Looping Through a Dictionary</h2>

<p>
Dictionaries can be iterated using loops.
</p>

<h3 class="text-xl font-bold mt-6">Loop Through Keys</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
for key in student:
    print(key)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Loop Through Values</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
for value in student.values():
    print(value)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Loop Through Key-Value Pairs</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
for key, value in student.items():
    print(key, value)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Common Dictionary Methods</h2>

<table>

<tr>
<th>Method</th>
<th>Description</th>
</tr>

<tr>
<td>keys()</td>
<td>Returns all keys in the dictionary</td>
</tr>

<tr>
<td>values()</td>
<td>Returns all values in the dictionary</td>
</tr>

<tr>
<td>items()</td>
<td>Returns key-value pairs</td>
</tr>

<tr>
<td>get()</td>
<td>Returns value for a specific key</td>
</tr>

<tr>
<td>pop()</td>
<td>Removes a key and its value</td>
</tr>

<tr>
<td>update()</td>
<td>Updates dictionary with new values</td>
</tr>

<tr>
<td>clear()</td>
<td>Removes all elements</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Dictionary Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
student = {
 "name":"Alice",
 "age":22,
 "course":"Computer Science"
}

print("Name:", student["name"])
print("Age:", student["age"])
print("Course:", student["course"])
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Name: Alice
Age: 22
Course: Computer Science
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Dictionaries</h2>

<ul>
<li>Efficient data retrieval using keys</li>
<li>Flexible and easy to modify</li>
<li>Suitable for storing structured data</li>
<li>Supports fast lookups</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Dictionaries</h2>

<ul>
<li>Storing database records</li>
<li>Configuration settings</li>
<li>JSON data representation</li>
<li>Counting frequency of elements</li>
</ul>

<h2 class="text-xl font-bold mt-6">Example: Counting Word Frequency</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
text = "python is easy and python is powerful"

words = text.split()

frequency = {}

for word in words:
    if word in frequency:
        frequency[word] += 1
    else:
        frequency[word] = 1

print(frequency)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
{'python': 2, 'is': 2, 'easy': 1, 'and': 1, 'powerful': 1}
</code></pre>
</div>

</div>

            <div id="fileintro" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">File Handling</h1>
              
<p>
File handling in Python is used to store data permanently in files.
Normally, data stored in variables is temporary and lost when the
program ends. By using files, we can save data permanently so that
it can be used later.
</p>

<p>
Python provides built-in functions to create, read, write, and delete
files. File handling is commonly used in applications like storing
user information, logs, reports, and database records.
</p>

<h2 class="text-xl font-bold mt-6">Advantages of File Handling</h2>

<ul>
<li>Stores data permanently</li>
<li>Helps manage large amounts of data</li>
<li>Allows reading and writing data easily</li>
<li>Useful for saving program results</li>
</ul>

<h2 class="text-xl font-bold mt-6">File Path</h2>

<p>
A file path specifies the location of a file in the computer system.
Python can access files using either relative paths or absolute paths.
</p>

<h3 class="text-xl font-bold mt-6">Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt")
</code></pre>
</div>

<p>
Here, the file <b>data.txt</b> is located in the same folder as the program.
</p>

<h2 class="text-xl font-bold mt-6">Opening a File</h2>

<p>
Python uses the <b>open()</b> function to open a file.
</p>

<h3 class="text-xl font-bold mt-6">Syntax</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("filename", "mode")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">File Modes</h2>

<table border="1" cellpadding="8">

<tr>
<th>Mode</th>
<th>Description</th>
</tr>

<tr>
<td>r</td>
<td>Read mode (default mode)</td>
</tr>

<tr>
<td>w</td>
<td>Write mode (creates new file or overwrites existing file)</td>
</tr>

<tr>
<td>a</td>
<td>Append mode (adds data to existing file)</td>
</tr>

<tr>
<td>r+</td>
<td>Read and write mode</td>
</tr>

<tr>
<td>b</td>
<td>Binary mode</td>
</tr>

<tr>
<td>t</td>
<td>Text mode (default)</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Closing a File</h2>

<p>
After performing operations on a file, it should be closed to free
system resources.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Reading Data from a File</h2>

<h3 class="text-xl font-bold mt-6">read() Method</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

content = file.read()

print(content)

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">readline() Method</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

line = file.readline()

print(line)

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">readlines() Method</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

lines = file.readlines()

print(lines)

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Writing Data to a File</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","w")

file.write("Welcome to Python Programming")

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Appending Data to a File</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","a")

file.write("This is additional text")

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">File Pointer Position</h2>

<h3 class="text-xl font-bold mt-6">tell() Method</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

print(file.tell())
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">seek() Method</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file.seek(0)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using with Statement</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
with open("data.txt","r") as file:
    data = file.read()
    print(data)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("sample.txt","w")

file.write("Python File Handling Example")

file.close()

file = open("sample.txt","r")

print(file.read())

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Python File Handling Example
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Applications of File Handling</h2>

<ul>
<li>Saving user data in applications</li>
<li>Log file creation</li>
<li>Report generation</li>
<li>Data storage for programs</li>
</ul>

</div>

            <div id="reading" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Reading Files</h1>

<p>
Reading files is one of the most common operations in file handling.
It allows a program to retrieve stored data from a file and use it
inside the program. Python provides several built-in functions to
read the contents of a file efficiently.
</p>

<p>
To read a file, the file must first be opened using the
<b>open()</b> function in <b>read mode (r)</b>.
</p>

<h2 class="text-xl font-bold mt-6">Opening a File for Reading</h2>

<p>
The following syntax is used to open a file in read mode.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt", "r")
</code></pre>
</div>

<p>
If the file exists, Python opens the file and allows the program
to read its contents. If the file does not exist, an error occurs.
</p>

<h2 class="text-xl font-bold mt-6">Methods for Reading Files</h2>

<p>
Python provides several methods to read data from files.
Each method works differently depending on how much data
needs to be read.
</p>
<br>
<table border="1" cellpadding="8">

<tr>
<th>Method</th>
<th>Description</th>
</tr>

<tr>
<td>read()</td>
<td>Reads the entire file content</td>
</tr>

<tr>
<td>readline()</td>
<td>Reads one line at a time</td>
</tr>

<tr>
<td>readlines()</td>
<td>Reads all lines and returns them as a list</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">1. read() Method</h2>

<p>
The <b>read()</b> method reads the entire content of a file
and returns it as a string.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt", "r")

content = file.read()

print(content)

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Welcome to Python Programming
File handling is easy to learn
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Reading Specific Number of Characters</h2>

<p>
The read() method can also read a specific number of characters
from the file.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

print(file.read(10))

file.close()
</code></pre>
</div>

<p>
This reads only the first 10 characters from the file.
</p>

<h2 class="text-xl font-bold mt-6">2. readline() Method</h2>

<p>
The <b>readline()</b> method reads a single line from the file.
Each time it is called, the next line of the file is read.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

line1 = file.readline()
line2 = file.readline()

print(line1)
print(line2)

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Welcome to Python Programming
File handling is easy
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">3. readlines() Method</h2>

<p>
The <b>readlines()</b> method reads all lines of the file and
returns them as a list.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

lines = file.readlines()

print(lines)

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
['Welcome to Python\n', 'File handling is easy\n']
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Reading File Using a Loop</h2>

<p>
A common method for reading files is using a loop,
which reads the file line by line.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","r")

for line in file:
 print(line)

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using the with Statement</h2>

<p>
Python provides the <b>with</b> statement to simplify file
handling. It automatically closes the file after use.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
with open("data.txt","r") as file:
 data = file.read()
 print(data)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Checking if File Exists</h2>

<p>
Before reading a file, it is good practice to check whether
the file exists to avoid errors.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import os

if os.path.exists("data.txt"):
 file = open("data.txt","r")
 print(file.read())
else:
 print("File not found")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
with open("sample.txt","r") as file:

 print("File Content:")

 for line in file:
  print(line)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
File Content:
Python is easy
Python is powerful
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Reading Files</h2>

<ul>
<li>Allows programs to access stored data</li>
<li>Useful for processing large datasets</li>
<li>Helps in reading logs and reports</li>
<li>Enables data analysis and processing</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Reading Files</h2>

<ul>
<li>Reading configuration files</li>
<li>Loading user data</li>
<li>Processing log files</li>
<li>Reading text documents</li>
</ul>

</div>

            <div id="writing" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Writing Files</h1>
                
<div>

<p>
Writing files in Python is an important part of file handling.
It allows programs to store information permanently inside a file.
This stored data can later be read and processed by the program.
</p>

<p>
Python provides built-in functions that allow developers to create
new files, write data into files, and append data to existing files.
Writing files is commonly used in applications for storing logs,
saving reports, and maintaining records.
</p>

<h2 class="text-xl font-bold mt-6">Opening a File for Writing</h2>

<p>
Before writing data into a file, the file must be opened using the
<b>open()</b> function in write mode.
</p>

<h3 class="text-xl font-bold mt-6">Syntax</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("filename", "mode")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">File Modes Used for Writing</h2>

<table border="1" cellpadding="8">

<tr>
<th>Mode</th>
<th>Description</th>
</tr>

<tr>
<td>w</td>
<td>Write mode. Creates a new file or overwrites an existing file.</td>
</tr>

<tr>
<td>a</td>
<td>Append mode. Adds data to the end of an existing file.</td>
</tr>

<tr>
<td>w+</td>
<td>Write and read mode.</td>
</tr>

<tr>
<td>a+</td>
<td>Append and read mode.</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Using write() Method</h2>

<p>
The <b>write()</b> method is used to write text into a file.
If the file does not exist, Python automatically creates it.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","w")

file.write("Welcome to Python Programming")

file.close()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Explanation</h3>

<ul>
<li>The file is opened in write mode.</li>
<li>The write() method stores text inside the file.</li>
<li>The file is closed after writing.</li>
</ul>

<h2 class="text-xl font-bold mt-6">Writing Multiple Lines</h2>

<p>
Multiple lines can be written by using the newline character
<b>\n</b>.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","w")

file.write("Python Programming\n")
file.write("File Handling Example\n")
file.write("Writing Data to Files")

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using writelines() Method</h2>

<p>
The <b>writelines()</b> method writes multiple lines from a list
into a file.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
lines = ["Python\n", "Java\n", "C++\n"]

file = open("data.txt","w")

file.writelines(lines)

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Appending Data to a File</h2>

<p>
Append mode allows new data to be added without deleting the
existing content of the file.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
file = open("data.txt","a")

file.write("\nThis is appended text")

file.close()
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using the with Statement</h2>

<p>
The <b>with</b> statement automatically closes the file after
the writing operation is completed. This is the recommended
method for handling files.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
with open("data.txt","w") as file:

 file.write("Python File Writing Example")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
with open("sample.txt","w") as file:

 file.write("Python Programming\n")
 file.write("Learning File Handling\n")
 file.write("Writing Files Example")

print("Data written successfully")
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Data written successfully
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Writing Files</h2>

<ul>
<li>Stores program output permanently</li>
<li>Helps maintain logs and reports</li>
<li>Useful for saving user data</li>
<li>Allows data to be reused in future programs</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Writing Files</h2>

<ul>
<li>Saving user registration details</li>
<li>Generating reports</li>
<li>Logging application events</li>
<li>Storing configuration data</li>
</ul>

</div>
</div>
            <div id="exception" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Exception Handling</h1>
     
<p>
Exception handling is an important concept in Python that allows
programmers to handle errors that occur during the execution of
a program. Instead of stopping the program suddenly, exception
handling allows the program to continue running smoothly by
managing errors properly.
</p>

<p>
In Python, errors that occur during program execution are called
<b>exceptions</b>. Python provides several built-in mechanisms to
detect and handle these exceptions.
</p>

<h2 class="text-xl font-bold mt-6">Errors vs Exceptions</h2>

<p>
Errors and exceptions both indicate problems in a program,
but they occur in different situations.
</p>

<table border="1" cellpadding="8">

<tr>
<th>Type</th>
<th>Description</th>
</tr>

<tr>
<td>Syntax Error</td>
<td>Occurs when the program violates Python syntax rules.</td>
</tr>

<tr>
<td>Runtime Error</td>
<td>Occurs while the program is running.</td>
</tr>

<tr>
<td>Exception</td>
<td>An error that occurs during program execution.</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Example of an Exception</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
x = 10
y = 0

print(x / y)
</code></pre>
</div>

<p>
This program produces a <b>ZeroDivisionError</b> because division
by zero is not allowed.
</p>

<h2 class="text-xl font-bold mt-6">Handling Exceptions Using try and except</h2>

<p>
Python uses the <b>try</b> and <b>except</b> blocks to handle exceptions.
</p>

<h3 class="text-xl font-bold mt-6">Syntax</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 statements
except:
 statements
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 x = 10
 y = 0
 print(x / y)

except:
 print("Error occurred")
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Error occurred
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Handling Specific Exceptions</h2>

<p>
It is possible to handle specific types of exceptions.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 num = int(input("Enter a number: "))
 result = 10 / num
 print(result)

except ZeroDivisionError:
 print("Cannot divide by zero")

except ValueError:
 print("Invalid input")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Multiple Exceptions</h2>

<p>
Multiple exceptions can be handled using multiple
<b>except</b> blocks.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 x = int(input("Enter number"))
 y = 10 / x

except ZeroDivisionError:
 print("Division by zero is not allowed")

except ValueError:
 print("Invalid input")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using else Block</h2>

<p>
The <b>else</b> block executes if no exception occurs.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 num = 10
 print(num)

except:
 print("Error")

else:
 print("Program executed successfully")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using finally Block</h2>

<p>
The <b>finally</b> block always executes whether an
exception occurs or not.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:
 file = open("data.txt","r")

except:
 print("File not found")

finally:
 print("Execution completed")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Raising Exceptions</h2>

<p>
Python allows programmers to manually raise exceptions
using the <b>raise</b> keyword.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
age = -5

if age < 0:
 raise ValueError("Age cannot be negative")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">User-Defined Exceptions</h2>

<p>
Python allows creating custom exceptions by defining
a new class derived from the Exception class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class CustomError(Exception):
 pass

try:
 raise CustomError("This is a custom exception")

except CustomError as e:
 print(e)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
try:

 number = int(input("Enter a number: "))
 result = 100 / number

 print("Result:", result)

except ZeroDivisionError:

 print("Cannot divide by zero")

except ValueError:

 print("Please enter a valid number")

finally:

 print("Program finished")
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Enter a number: 0
Cannot divide by zero
Program finished
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Exception Handling</h2>

<ul>
<li>Prevents sudden program termination</li>
<li>Improves program reliability</li>
<li>Makes debugging easier</li>
<li>Provides user-friendly error messages</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Exception Handling</h2>

<ul>
<li>Handling file errors</li>
<li>Managing invalid user inputs</li>
<li>Preventing application crashes</li>
<li>Handling network or database errors</li>
</ul>

</div>

            <div id="modules" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Modules in Python</h1>
                
<p>
A Python module is simply a file with a <b>.py</b> extension that
contains Python definitions and statements. Modules help improve
code readability, reusability, and maintainability.
</p>

<h2 class="text-xl font-bold mt-6">Advantages of Using Modules</h2>

<ul>
<li>Improves code organization</li>
<li>Promotes code reuse</li>
<li>Reduces program complexity</li>
<li>Makes debugging easier</li>
<li>Encourages modular programming</li>
</ul>

<h2 class="text-xl font-bold mt-6">Types of Modules</h2>

<p>
Python mainly supports two types of modules.
</p>

<table border="1" cellpadding="8">

<tr>
<th>Type</th>
<th>Description</th>
</tr>

<tr>
<td>Built-in Modules</td>
<td>Modules that come pre-installed with Python.</td>
</tr>

<tr>
<td>User-defined Modules</td>
<td>Modules created by programmers.</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Built-in Modules in Python</h2>

<p>
Python provides many built-in modules that contain useful
functions for performing different tasks.
</p>

<p>Some commonly used built-in modules include:</p>

<ul>
<li>math</li>
<li>random</li>
<li>datetime</li>
<li>sys</li>
<li>os</li>
</ul>

<h3 class="text-xl font-bold mt-6">Example Using math Module</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

print(math.sqrt(16))
print(math.factorial(5))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
4.0
120
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Creating a User-Defined Module</h2>

<p>
A user-defined module is created by writing Python code inside
a file and saving it with a <b>.py</b> extension.
</p>

<h3 class="text-xl font-bold mt-6">Example: Creating a Module</h3>

<p>Create a file named <b>mymodule.py</b></p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def greet(name):
 print("Hello", name)

def add(a,b):
 return a + b
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing a Module</h2>

<p>
Modules can be imported into another Python program using the
<b>import</b> keyword.
</p>

<h3 class="text-xl font-bold mt-6">Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import mymodule

mymodule.greet("Sahana")

print(mymodule.add(5,3))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Hello Sahana
8
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing Specific Functions</h2>

<p>
Instead of importing the entire module, specific functions can
also be imported.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from mymodule import add

print(add(10,5))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using Alias for Modules</h2>

<p>
Modules can also be imported using an alias name to make the
program shorter and easier to write.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math as m

print(m.sqrt(25))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">The dir() Function</h2>

<p>
The <b>dir()</b> function returns a list of all the functions
and variables defined in a module.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

print(dir(math))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Packages in Python</h2>

<p>
A package is a collection of multiple modules organized in
directories. Packages help structure large applications.
</p>

<p>
A package usually contains an <b>__init__.py</b> file which
indicates that the directory should be treated as a package.
</p>

<h3 class="text-xl font-bold mt-6">Example Structure</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
mypackage/
   module1.py
   module2.py
   __init__.py
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program Using Modules</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

num = 9

square_root = math.sqrt(num)

print("Square root:", square_root)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Square root: 3.0
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Applications of Modules</h2>

<ul>
<li>Developing large software systems</li>
<li>Creating reusable code libraries</li>
<li>Organizing projects into multiple files</li>
<li>Reducing program size and complexity</li>
</ul>

</div>

            <div id="import" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Import Statement</h1>

<div>

<p>
The import statement in Python is used to include modules in a program.
Modules contain functions, variables, and classes that can be reused
in different programs. By using the import statement, programmers can
access the functionality defined inside another module.
</p>

<p>
Instead of rewriting the same code multiple times, Python allows
developers to reuse existing modules by importing them into the
current program. This improves program efficiency and reduces
code duplication.
</p>

<h2 class="text-xl font-bold mt-6">Syntax of Import Statement</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import module_name
</code></pre>
</div>

<p>
This statement imports the entire module so that all functions
and variables inside the module can be accessed using the module name.
</p>

<h2 class="text-xl font-bold mt-6">Example of Import Statement</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

print(math.sqrt(16))
print(math.factorial(4))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
4.0
24
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Types of Import Statements</h2>

<p>
Python provides several ways to import modules depending on the
requirements of the program.
</p>

<table border="1" cellpadding="8">

<tr>
<th>Import Type</th>
<th>Description</th>
</tr>

<tr>
<td>import module</td>
<td>Imports the entire module.</td>
</tr>

<tr>
<td>from module import name</td>
<td>Imports a specific function or variable.</td>
</tr>

<tr>
<td>from module import *</td>
<td>Imports everything from the module.</td>
</tr>

<tr>
<td>import module as alias</td>
<td>Imports module using another name.</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Importing Entire Module</h2>

<p>
When the entire module is imported, functions must be accessed
using the module name.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import random

print(random.randint(1,10))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing Specific Functions</h2>

<p>
Instead of importing the whole module, only specific functions
can be imported.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from math import sqrt

print(sqrt(25))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing Multiple Functions</h2>

<p>
Multiple functions can also be imported from the same module.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from math import sqrt, factorial

print(sqrt(36))
print(factorial(5))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using Alias in Import Statement</h2>

<p>
Modules can be imported with a shorter name using the
<b>as</b> keyword.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math as m

print(m.sqrt(49))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Wildcard Import</h2>

<p>
Wildcard import allows all functions and variables from
a module to be imported.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from math import *

print(sqrt(64))
</code></pre>
</div>

<p>
However, wildcard imports are generally not recommended
because they can create confusion when multiple modules
contain functions with the same name.
</p>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

number = 16

result = math.sqrt(number)

print("Square root:", result)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Square root: 4.0
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Using Import Statement</h2>

<ul>
<li>Allows reuse of existing code</li>
<li>Reduces program size</li>
<li>Improves code readability</li>
<li>Provides access to powerful built-in libraries</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Import Statement</h2>

<ul>
<li>Mathematical calculations using math module</li>
<li>Generating random numbers</li>
<li>Working with operating system files</li>
<li>Handling date and time operations</li>
</ul>

</div>
</div>       
            <div id="builtin" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Built-in Modules</h1>
                
<div>

<p>
Built-in modules in Python are modules that come pre-installed
with the Python programming language. These modules provide
a large collection of useful functions and tools that help
developers perform various tasks without writing additional code.
</p>

<p>
Python's standard library contains many built-in modules that
support operations such as mathematical calculations, file
handling, operating system interaction, random number generation,
date and time manipulation, and many more.
</p>

<h2 class="text-xl font-bold mt-6">Definition</h2>

<p>
A built-in module is a module that is included in Python's
standard library and can be used directly in programs by
importing it using the <b>import</b> statement.
</p>

<h2 class="text-xl font-bold mt-6">Advantages of Built-in Modules</h2>

<ul>
<li>Reduces programming effort</li>
<li>Provides ready-made functions</li>
<li>Improves program efficiency</li>
<li>Speeds up development time</li>
<li>Makes programs easier to maintain</li>
</ul>

<h2 class="text-xl font-bold mt-6">Common Built-in Modules in Python</h2>

<table border="1" cellpadding="8">

<tr>
<th>Module</th>
<th>Description</th>
</tr>

<tr>
<td>math</td>
<td>Provides mathematical functions such as square root,
power, trigonometric functions, etc.</td>
</tr>

<tr>
<td>random</td>
<td>Used to generate random numbers.</td>
</tr>

<tr>
<td>datetime</td>
<td>Used for working with dates and time.</td>
</tr>

<tr>
<td>sys</td>
<td>Provides functions to interact with the Python interpreter.</td>
</tr>

<tr>
<td>os</td>
<td>Allows interaction with the operating system.</td>
</tr>

</table>

<h2 class="text-xl font-bold mt-6">Math Module</h2>

<p>
The math module provides various mathematical functions
such as square root, factorial, logarithmic functions,
and trigonometric operations.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math

print(math.sqrt(16))
print(math.factorial(5))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
4.0
120
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Random Module</h2>

<p>
The random module is used to generate random numbers
and perform random selections.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import random

print(random.randint(1,10))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
7
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">DateTime Module</h2>

<p>
The datetime module helps in working with date and time
values such as current date, current time, and formatting dates.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import datetime

x = datetime.datetime.now()

print(x)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">OS Module</h2>

<p>
The os module allows Python programs to interact with
the operating system.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import os

print(os.getcwd())
</code></pre>
</div>

<p>
This program prints the current working directory.
</p>

<h2 class="text-xl font-bold mt-6">Sys Module</h2>

<p>
The sys module provides functions that interact with the
Python runtime environment.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import sys

print(sys.version)
</code></pre>
</div>

<p>
This displays the current version of Python installed
on the system.
</p>

<h2 class="text-xl font-bold mt-6">Example Program Using Built-in Modules</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import math
import random

number = 25

print("Square Root:", math.sqrt(number))

print("Random Number:", random.randint(1,100))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Square Root: 5.0
Random Number: 42
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Applications of Built-in Modules</h2>

<ul>
<li>Scientific calculations</li>
<li>Game development using random numbers</li>
<li>Date and time management</li>
<li>Operating system operations</li>
<li>System-level programming</li>
</ul>

</div>
</div>

            <div id="packages" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Packages</h1>

<p>
A package in Python is a collection of modules organized in a
directory structure. Packages allow programmers to organize
related modules together so that large projects can be managed
more efficiently.
</p>

<p>
When programs become very large, storing all modules in a single
folder can make the project difficult to manage. Python packages
solve this problem by grouping modules into folders.
</p>

<h2 class="text-xl font-bold mt-6">Definition</h2>

<p>
A package is a directory that contains multiple Python modules
along with a special file called <b>__init__.py</b> which tells
Python that the directory should be treated as a package.
</p>

<h2 class="text-xl font-bold mt-6">Structure of a Python Package</h2>

<p>
A typical Python package structure looks like the following:
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
mypackage/
    __init__.py
    module1.py
    module2.py
    module3.py
</code></pre>
</div>

<p>
Here:
</p>

<ul>
<li><b>mypackage</b> is the package folder</li>
<li><b>__init__.py</b> indicates that the directory is a package</li>
<li><b>module1.py, module2.py</b> are modules inside the package</li>
</ul>

<h2 class="text-xl font-bold mt-6">Advantages of Packages</h2>

<ul>
<li>Organizes large projects into smaller components</li>
<li>Improves code readability</li>
<li>Encourages modular programming</li>
<li>Makes code reuse easier</li>
<li>Helps avoid naming conflicts</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating a Package</h2>

<p>
To create a package, follow these steps:
</p>

<ol>
<li>Create a directory with the package name</li>
<li>Create an <b>__init__.py</b> file inside the directory</li>
<li>Add Python modules inside the directory</li>
</ol>

<h3 class="text-xl font-bold mt-6">Example</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
mathpackage/
    __init__.py
    addition.py
    subtraction.py
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Module Inside Package</h2>

<p>addition.py</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def add(a, b):
    return a + b
</code></pre>
</div>

<p>subtraction.py</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
def subtract(a, b):
    return a - b
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing Modules from Packages</h2>

<p>
Modules from a package can be imported using the dot notation.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import mathpackage.addition

print(mathpackage.addition.add(5,3))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Importing Specific Functions from Package</h2>

<p>
Specific functions can also be imported from modules inside
a package.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from mathpackage.addition import add

print(add(10,5))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Using Alias with Packages</h2>

<p>
Packages can also be imported using alias names.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
import mathpackage.addition as a

print(a.add(7,3))
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program Using Packages</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
from mathpackage.subtraction import subtract

result = subtract(10,4)

print("Result:", result)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Result: 6
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Applications of Packages</h2>

<ul>
<li>Large software development</li>
<li>Organizing machine learning libraries</li>
<li>Building reusable code libraries</li>
<li>Managing complex applications</li>
</ul>

<h2 class="text-xl font-bold mt-6">Popular Python Packages</h2>

<ul>
<li>NumPy – Numerical computing</li>
<li>Pandas – Data analysis</li>
<li>Matplotlib – Data visualization</li>
<li>TensorFlow – Machine learning</li>
<li>Django – Web development</li>
</ul>

</div>      

            <div id="class" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Class</h1>
                
<p>
In Python, a class is a blueprint for creating objects.
Classes are used in Object-Oriented Programming (OOP) to group
related data and functions together. A class defines the
properties and behavior that objects created from the class
will have.
</p>

<p>
Classes help programmers organize code in a structured way.
Using classes makes programs more modular, reusable,
and easier to maintain.
</p>

<h2 class="text-xl font-bold mt-6">Definition of a Class</h2>

<p>
A class is a user-defined data structure that contains
data members (variables) and member functions (methods)
that operate on the data.
</p>

<h2 class="text-xl font-bold mt-6">Syntax for Creating a Class</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class ClassName:
    # class body
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example of a Class</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:
    name = "Sahana"
    age = 20
</code></pre>
</div>

<p>
In this example, <b>Student</b> is a class that contains two
attributes: name and age.
</p>

<h2 class="text-xl font-bold mt-6">Creating an Object</h2>

<p>
An object is an instance of a class. Objects are created
using the class name.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:
    name = "Sahana"
    age = 20

s1 = Student()

print(s1.name)
print(s1.age)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Sahana
20
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Class Attributes</h2>

<p>
Attributes are variables that belong to a class.
They store information related to the object.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Car:
    brand = "Toyota"
    color = "Red"
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Class Methods</h2>

<p>
Methods are functions defined inside a class.
They describe the behavior of objects.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:

    def display(self):
        print("This is a student class")
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Using Methods</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:

    def greet(self):
        print("Welcome to Python OOP")

s = Student()

s.greet()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Welcome to Python OOP
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">The __init__() Constructor</h2>

<p>
The <b>__init__()</b> method is a special method in Python
that acts as a constructor. It is automatically called
when an object is created.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:

    def __init__(self, name, age):
        self.name = name
        self.age = age

s1 = Student("Sahana",20)

print(s1.name)
print(s1.age)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Sahana
20
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">The self Keyword</h2>

<p>
The <b>self</b> keyword refers to the current object of the class.
It is used to access variables and methods within the class.
</p>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Rectangle:

    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

r = Rectangle(5,3)

print("Area:", r.area())
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Area: 15
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Using Classes</h2>

<ul>
<li>Improves code organization</li>
<li>Supports code reuse</li>
<li>Allows modular programming</li>
<li>Makes complex programs easier to manage</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Classes</h2>

<ul>
<li>Software development</li>
<li>Game development</li>
<li>GUI applications</li>
<li>Database systems</li>
<li>Web applications</li>
</ul>

</div>


            <div id="object" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Object</h1>
                
<div>

<p>
In Object-Oriented Programming (OOP), an object is an instance of a class.
While a class acts as a blueprint, objects represent real-world entities
that contain data and behavior defined by the class.
</p>

<p>
Objects allow programmers to use the properties and methods defined
inside a class. Each object can have different values for the same
attributes defined in the class.
</p>

<h2 class="text-xl font-bold mt-6">Definition of an Object</h2>

<p>
An object is an instance of a class that contains data (attributes)
and functions (methods). Objects allow interaction with the
features defined in the class.
</p>

<h2 class="text-xl font-bold mt-6">Example of Class and Object</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:
    name = "Sahana"
    age = 20

s1 = Student()

print(s1.name)
print(s1.age)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Sahana
20
</code></pre>
</div>

<p>
In this example:
</p>

<ul>
<li><b>Student</b> is the class</li>
<li><b>s1</b> is the object of the class</li>
</ul>

<h2 class="text-xl font-bold mt-6">Characteristics of Objects</h2>

<ul>
<li>Identity – Each object has a unique identity.</li>
<li>State – Defined by attributes of the object.</li>
<li>Behavior – Defined by methods of the object.</li>
</ul>

<h2 class="text-xl font-bold mt-6">Creating Multiple Objects</h2>

<p>
A class can create multiple objects with different data.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:

    def __init__(self, name, age):
        self.name = name
        self.age = age

s1 = Student("Sahana",20)
s2 = Student("Priya",21)

print(s1.name)
print(s2.name)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Sahana
Priya
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Accessing Object Attributes</h2>

<p>
Attributes of an object can be accessed using the dot (.)
operator.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Car:
    brand = "Toyota"
    color = "Red"

c1 = Car()

print(c1.brand)
print(c1.color)
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Calling Object Methods</h2>

<p>
Methods defined inside a class can be called using the object.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:

    def greet(self):
        print("Hello Student")

s = Student()

s.greet()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Hello Student
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Modifying Object Properties</h2>

<p>
Object attributes can be modified after the object is created.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:
    name = "Sahana"

s1 = Student()

s1.name = "Anita"

print(s1.name)
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Anita
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Deleting Object Properties</h2>

<p>
Attributes of an object can be deleted using the <b>del</b> keyword.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Student:
    name = "Sahana"

s1 = Student()

del s1.name
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Deleting an Object</h2>

<p>
Entire objects can also be deleted using the <b>del</b> keyword.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
s1 = Student()

del s1
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Example Program</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Rectangle:

    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

r1 = Rectangle(4,5)

print("Area:", r1.area())
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Area: 20
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Objects</h2>

<ul>
<li>Represents real-world entities</li>
<li>Improves code organization</li>
<li>Supports reusability</li>
<li>Helps manage complex programs</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Objects</h2>

<ul>
<li>Software development</li>
<li>Game development</li>
<li>GUI applications</li>
<li>Database systems</li>
<li>Web applications</li>
</ul>

</div>
</div>
            <div id="inheritance" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Inheritance</h1>
                
<div>

<p>
Inheritance is one of the most important concepts in Object-Oriented
Programming (OOP). It allows one class to inherit the properties
and methods of another class. The class that inherits properties
is called the <b>child class</b> (or derived class) and the class
whose properties are inherited is called the <b>parent class</b>
(or base class).
</p>

<p>
Inheritance helps in code reusability and makes programs easier
to maintain and extend. Instead of writing the same code multiple
times, programmers can reuse the existing code from another class.
</p>

<h2 class="text-xl font-bold mt-6">Definition</h2>

<p>
Inheritance is the mechanism by which a new class acquires the
properties and behavior of an existing class.
</p>

<h2 class="text-xl font-bold mt-6">Syntax of Inheritance</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class ParentClass:
    # parent class code

class ChildClass(ParentClass):
    # child class code
</code></pre>
</div>

<p>
Here, the ChildClass inherits all the attributes and methods
from ParentClass.
</p>

<h2 class="text-xl font-bold mt-6">Example of Inheritance</h2>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Animal:

    def speak(self):
        print("Animal makes a sound")

class Dog(Animal):

    def bark(self):
        print("Dog barks")

d = Dog()

d.speak()
d.bark()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Animal makes a sound
Dog barks
</code></pre>
</div>

<p>
In this example:
</p>

<ul>
<li><b>Animal</b> is the parent class</li>
<li><b>Dog</b> is the child class</li>
<li>The Dog class inherits the <b>speak()</b> method from Animal</li>
</ul>

<h2 class="text-xl font-bold mt-6">Types of Inheritance in Python</h2>

<p>
Python supports several types of inheritance.
</p>

<h3 class="text-xl font-bold mt-6">1. Single Inheritance</h3>

<p>
In single inheritance, a child class inherits from only one
parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Parent:
    def display(self):
        print("This is parent class")

class Child(Parent):
    pass

c = Child()
c.display()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">2. Multiple Inheritance</h3>

<p>
In multiple inheritance, a child class inherits from more
than one parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Father:
    def skill1(self):
        print("Gardening")

class Mother:
    def skill2(self):
        print("Cooking")

class Child(Father, Mother):
    pass

c = Child()
c.skill1()
c.skill2()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">3. Multilevel Inheritance</h3>

<p>
In multilevel inheritance, a class inherits from a class
which itself inherits from another class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Grandparent:
    def show(self):
        print("Grandparent class")

class Parent(Grandparent):
    pass

class Child(Parent):
    pass

c = Child()
c.show()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">4. Hierarchical Inheritance</h3>

<p>
In hierarchical inheritance, multiple child classes inherit
from a single parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Parent:
    def display(self):
        print("Parent class")

class Child1(Parent):
    pass

class Child2(Parent):
    pass
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">5. Hybrid Inheritance</h3>

<p>
Hybrid inheritance is a combination of two or more types
of inheritance.
</p>

<h2 class="text-xl font-bold mt-6">Method Overriding</h2>

<p>
Method overriding occurs when a child class provides its own
implementation of a method that is already defined in the
parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Animal:

    def speak(self):
        print("Animal sound")

class Dog(Animal):

    def speak(self):
        print("Dog barks")

d = Dog()
d.speak()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Dog barks
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Advantages of Inheritance</h2>

<ul>
<li>Promotes code reuse</li>
<li>Reduces redundancy</li>
<li>Improves program structure</li>
<li>Makes programs easier to maintain</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Inheritance</h2>

<ul>
<li>Software development</li>
<li>Game development</li>
<li>GUI programming</li>
<li>Web applications</li>
<li>Large enterprise systems</li>
</ul>

</div>
</div>
            <div id="polymorphism" class="section content-section prose max-w-none">
                <h1 class="text-3xl font-bold text-indigo-600 mb-4">Polymorphism</h1>
                
<p>
Polymorphism is one of the core concepts of Object-Oriented
Programming (OOP). The word polymorphism means
<b>"many forms"</b>. In Python, polymorphism allows
different objects to respond to the same method or function
in different ways.
</p>

<p>
Polymorphism improves flexibility and reusability in programs.
Using polymorphism, the same function name can be used
for different types of operations.
</p>

<h2 class="text-xl font-bold mt-6">Definition</h2>

<p>
Polymorphism is the ability of an object, function, or method
to take multiple forms depending on the context in which
it is used.
</p>

<h2 class="text-xl font-bold mt-6">Example of Polymorphism Using Functions</h2>

<p>
The same function can work with different types of data.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(len("Python"))
print(len([1,2,3,4]))
print(len({"a":1,"b":2}))
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
6
4
2
</code></pre>
</div>

<p>
Here the <b>len()</b> function behaves differently depending
on the type of object passed to it.
</p>

<h2 class="text-xl font-bold mt-6">Polymorphism with Class Methods</h2>

<p>
Different classes can define methods with the same name
but perform different actions.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Dog:
    def sound(self):
        print("Dog barks")

class Cat:
    def sound(self):
        print("Cat meows")

d = Dog()
c = Cat()

d.sound()
c.sound()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Dog barks
Cat meows
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Polymorphism with Inheritance</h2>

<p>
Polymorphism is commonly used with inheritance where
a child class overrides a method defined in the parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Animal:

    def speak(self):
        print("Animal makes a sound")

class Dog(Animal):

    def speak(self):
        print("Dog barks")

a = Animal()
d = Dog()

a.speak()
d.speak()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
Animal makes a sound
Dog barks
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Method Overriding</h2>

<p>
Method overriding occurs when a child class provides a
specific implementation of a method that is already defined
in the parent class.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
class Parent:

    def show(self):
        print("This is parent class")

class Child(Parent):

    def show(self):
        print("This is child class")

c = Child()
c.show()
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
This is child class
</code></pre>
</div>

<h2 class="text-xl font-bold mt-6">Operator Overloading</h2>

<p>
Python also supports polymorphism through operator
overloading. This means the same operator can perform
different operations depending on the operands.
</p>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
print(5 + 3)
print("Hello " + "Python")
</code></pre>
</div>

<h3 class="text-xl font-bold mt-6">Output</h3>

<div class="code-toolbar">
<button class="copy-button" onclick="copyCode(this)">Copy</button>
<pre><code class="language-python">
8
Hello Python
</code></pre>
</div>

<p>
In the first example, the <b>+</b> operator performs addition,
while in the second example it performs string concatenation.
</p>

<h2 class="text-xl font-bold mt-6">Advantages of Polymorphism</h2>

<ul>
<li>Improves code flexibility</li>
<li>Encourages code reuse</li>
<li>Reduces complexity in programs</li>
<li>Makes programs easier to extend</li>
</ul>

<h2 class="text-xl font-bold mt-6">Applications of Polymorphism</h2>

<ul>
<li>Software development</li>
<li>Game development</li>
<li>Web applications</li>
<li>GUI applications</li>
<li>Large enterprise systems</li>
</ul>

</div>

        </main>
    </div>

    <footer class="gradient-bg text-white py-8 mt-10">
        <div class="container mx-auto px-4 text-center">
            <p>© 2026 Python Tutorial Project. Built with Tailwind CSS.</p>
        </div>
    </footer>

    <script>

let percent = <?php echo $progressPercent; ?>;
let circle = document.getElementById("progressCircle");

// 🔥 initial progress load from DB
let offset = 75.398 - (75.398 * percent / 100);
circle.style.strokeDashoffset = offset;

function show(id) {

    // ✅ show content
    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
    const target = document.getElementById(id);
    if(target) target.classList.add('active');

    // ✅ active highlight (removed auto tick mark so users must click the complete button)
    document.querySelectorAll('.sidebar-item').forEach(item => {
        item.classList.remove('active');
        if(item.getAttribute('data-topic') === id) {
            item.classList.add('active');
        }
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
    Prism.highlightAll();
}

        function copyCode(button) {
            const code = button.parentElement.querySelector('code').innerText;
            navigator.clipboard.writeText(code);
            button.innerText = "Copied!";
            setTimeout(() => button.innerText = "Copy", 2000);
        }

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('hidden');
        }

        document.addEventListener('DOMContentLoaded', () => {

            const searchInput = document.getElementById('globalSearch');
            const dropdown = document.getElementById('searchDropdown');

                let completed = <?php echo $completed; ?>;

    document.querySelectorAll('.sidebar-item').forEach(item => {
        let index = parseInt(item.getAttribute('data-index'));

        if(index <= completed){
            item.classList.add('topic-completed'); // ✅ tick
        }
    });

    // 🔥 inject Mark as Complete buttons
    function injectCompletionButtons() {
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => {
            const topicId = section.id;
            const btnContainer = document.createElement('div');
            btnContainer.className = 'mt-10 pt-6 border-t border-gray-100 flex justify-end';
            const btn = document.createElement('button');
            btn.className = 'mark-complete-btn bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 flex items-center gap-2 shadow-sm';
            btn.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
            
            btn.onclick = () => {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                completeTopic(topicId);
            };
            
            btnContainer.appendChild(btn);
            section.appendChild(btnContainer);
        });
        
        document.querySelectorAll('.sidebar-item').forEach(item => {
            if (item.classList.contains('topic-completed')) {
                const topicId = item.getAttribute('data-topic');
                const section = document.getElementById(topicId);
                if (section) {
                    const btn = section.querySelector('.mark-complete-btn');
                    if (btn) {
                        btn.classList.replace('bg-indigo-50', 'bg-green-500');
                        btn.classList.replace('text-indigo-600', 'text-white');
                        btn.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                        btn.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                        btn.disabled = true;
                        btn.classList.add('cursor-default');
                    }
                }
            }
        });
    }
    injectCompletionButtons();

    searchInput.addEventListener('input', (e) => {
                const term = e.target.value.toLowerCase().trim();
                if(term.length < 1) { dropdown.classList.remove('active'); return; }
                let results = "";
                document.querySelectorAll('.sidebar-item').forEach(item => {
                    if(item.innerText.toLowerCase().includes(term)) {
                        const highlighted = item.innerText.replace(new RegExp(`(${term})`, 'gi'), '<span class="search-highlight">$1</span>');
                        results += `<div class="p-3 hover:bg-gray-100 cursor-pointer border-b" onclick="show('${item.getAttribute('data-topic')}')">${highlighted}</div>`;
                    }
                });
                dropdown.innerHTML = results || "<div class='p-3 text-gray-500 italic'>No matching topics found</div>";
                dropdown.classList.add('active');
            });

            document.addEventListener('click', (e) => {
                if(!searchInput.contains(e.target)) dropdown.classList.remove('active');
            });
        });

function completeTopic(topicName){

    fetch('complete_topic.php',{
        method:'POST',
        headers:{
            'Content-Type':'application/x-www-form-urlencoded'
        },
        body:'topic_name=' + encodeURIComponent(topicName)
    })
    .then(res => res.text())
    .then(data => {
        console.log("Response:", data);

        const el = document.querySelector(`[data-topic="${topicName}"]`);
        if (el) {
            el.classList.add('topic-completed');
        }

        const section = document.getElementById(topicName);
        if (section) {
            const btn = section.querySelector('.mark-complete-btn');
            if (btn) {
                btn.classList.replace('bg-indigo-50', 'bg-green-500');
                btn.classList.replace('text-indigo-600', 'text-white');
                btn.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                btn.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                btn.disabled = true;
                btn.classList.add('cursor-default');
            }
        }

        // Unlock the next item visually
        const allSidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
        const currIdx = allSidebarItems.findIndex(i => i.getAttribute('data-topic') === topicName);
        if (currIdx >= 0 && currIdx < allSidebarItems.length - 1) {
            const nextItem = allSidebarItems[currIdx + 1];
            nextItem.classList.remove('opacity-50', 'pointer-events-none');
            const nextIcon = nextItem.querySelector('i');
            if (nextIcon) {
                nextIcon.classList.remove('fa-lock');
                nextIcon.classList.add('fa-unlock');
            }
        }

        setTimeout(() => {
            const sidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
            const currentIndex = sidebarItems.findIndex(item => item.getAttribute('data-topic') === topicName);
            if (currentIndex >= 0 && currentIndex < sidebarItems.length - 1) {
                const nextTopicId = sidebarItems[currentIndex + 1].getAttribute('data-topic');
                show(nextTopicId);
            } else if (currentIndex === sidebarItems.length - 1) {
                window.location.href = 'python_quiz_page.php';
            }
        }, 800);
    });

}
    </script>
</body>
</html>