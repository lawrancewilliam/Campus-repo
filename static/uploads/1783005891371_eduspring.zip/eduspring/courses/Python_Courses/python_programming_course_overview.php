<?php
session_start();
include("../../db.php");

// 🔥 USER ID GET
if (!isset($_SESSION['user_email'])) {
    header("Location: ../signin.php");
    exit();
}
$email = $_SESSION['user_email'];

$stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();

if (!$user) {
    die("User not found");
}

$user_id = $user['id'];
$course_id = 1; // Python course

// 🔥 FETCH PROGRESS
$progressQuery = $conn->prepare("
SELECT progress_percent FROM course_progress 
WHERE user_id=? AND course_id=?
");
$progressQuery->bind_param("ii", $user_id, $course_id);
$progressQuery->execute();
$resProgress = $progressQuery->get_result();

if($row = $resProgress->fetch_assoc()){
    $progressPercent = $row['progress_percent'];
} else {
    $progressPercent = 0;
}

// 🔥 CHECK QUIZ PASSED
$quizQuery = $conn->prepare("
SELECT passed FROM quiz_results 
WHERE user_id=? AND course_id=?
ORDER BY id DESC LIMIT 1
");
$quizQuery->bind_param("ii", $user_id, $course_id);
$quizQuery->execute();
$resQuiz = $quizQuery->get_result();

if($quiz = $resQuiz->fetch_assoc()){
    $quizPassed = $quiz['passed'] == 1;
} else {
    $quizPassed = false;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Developer Masterclass - Learnify</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        body { font-family: 'Inter', sans-serif; }
        
        .text-python {
            background: linear-gradient(135deg, #10b981, #047857);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .bg-python {
            background: linear-gradient(135deg, #10b981, #047857);
        }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

    <!-- Header -->
    <?php include '../../navbar.php'; ?>

    <!-- Hero Section -->
    <section class="bg-slate-900 py-16 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-emerald-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="container mx-auto px-4 max-w-6xl relative z-10">
            <div class="flex flex-col md:flex-row gap-8 items-center">
                <div class="flex-1">
                    <div class="inline-block bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold px-3 py-1 rounded-full text-xs mb-4 tracking-wide uppercase">
                        Structured Career Path
                    </div>
                    <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
                        Python Developer <span class="text-python">Masterclass</span>
                    </h1>
                    <p class="text-lg text-slate-400 mb-8 leading-relaxed max-w-2xl">
                        Build scalable backend systems, automate tasks, and analyze data. Master Python, Django, Flask, and APIs to become a highly sought-after, job-ready professional.
                    </p>
                    <div class="flex flex-wrap gap-6">
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-clock text-emerald-500"></i> 110 Hours Total
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-signal text-emerald-500"></i> Beginner to Pro
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-globe text-emerald-500"></i> 100% Online & Self-paced
                        </div>
                    </div>
                </div>
                <div class="w-32 h-32 md:w-48 md:h-48 bg-white/5 rounded-3xl flex items-center justify-center border border-white/10 shadow-2xl backdrop-blur-sm transform rotate-3 hover:rotate-0 transition-transform duration-500">
                    <i class="fab fa-python text-7xl md:text-9xl text-python drop-shadow-lg"></i>
                </div>
            </div>
        </div>
    </section>

    <main class="flex-1 container mx-auto px-4 py-12 max-w-6xl">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <!-- Course Info Left Column -->
            <div class="lg:col-span-2 space-y-12">
                <!-- About -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">About this Course</h2>
                    <p class="text-gray-600 leading-relaxed mb-4">
                        This comprehensive learning path is engineered to take you from a programming novice to a highly capable Python developer. You will learn how to write clean, "Pythonic" code, and master everything from basic syntax to advanced topics like web frameworks, RESTful APIs, and data analysis.
                    </p>
                    <p class="text-gray-600 leading-relaxed">
                        By the end of this course, you will be fully prepared to tackle the final assessment and earn your auto-generated digital certification, proving your expertise to potential employers.
                    </p>
                </section>

                <!-- What You'll Learn (Coverage) -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">Course Coverage</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Python Syntax & Fundamentals</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Object-Oriented Programming (OOP)</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Data Structures & Algorithms</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Web Scraping & Automation</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Django & Flask Web Frameworks</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">RESTful APIs & JSON Integration</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Data Analysis (Pandas & NumPy)</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-emerald-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Exception Handling & File I/O</span>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Sticky Action Card Right Column -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-gray-100 p-8 sticky top-24">
                    <h3 class="text-xl font-bold text-gray-900 mb-6">Your Progress</h3>
                    
                    <!-- Progress Bar -->
                    <div class="mb-8">
                        <div class="flex justify-between text-sm font-bold mb-2">
                            <span class="text-gray-600">Course Completion</span>
                            <span id="progressText" class="text-emerald-600">0%</span>
                        </div>
                        <div class="w-full bg-emerald-50 rounded-full h-3">
                            <div id="progressBar" class="bg-python h-3 rounded-full transition-all duration-1000 ease-out shadow-sm" style="width: 0%"></div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="space-y-4">
                        <!-- 1. Learning Material -->
                        <a id="btnCourse" href="python_final_page.php"
                        class="flex items-center justify-center w-full py-3.5 px-4 bg-python text-white font-bold rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
                        <i class="fas fa-play-circle mr-2 text-lg"></i> Start Learning
                        </a>
                        
                        <!-- 2. Quiz -->
                        <a id="btnQuiz" href="python_quiz_page.php"
                        class="flex items-center justify-center w-full py-3.5 px-4 bg-python text-white font-bold rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
                        <i class="fas fa-tasks mr-2 text-lg"></i> Take Certification Quiz
                        </a>
                        
                        <!-- 3. Certificate -->
                        <button id="btnCert" class="flex items-center justify-center w-full py-3.5 px-4 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed transition-all duration-300 pointer-events-none">
                            <i class="fas fa-certificate mr-2 text-lg"></i> Download Certificate
                        </button>
                    </div>
                    
                    <!-- Status Message -->
                    <div id="statusMessage" class="mt-6 text-sm text-center text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-100 font-medium">
                        Complete the course material (100%) to unlock the certification quiz.
                    </div>
                </div>
            </div>

        </div>
    </main>

    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 mt-auto text-center">
        <div class="container mx-auto px-4">
            <p class="text-sm">© 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>

    <script>
document.addEventListener('DOMContentLoaded', () => {

    let progressPercent = <?php echo $progressPercent;?>;
    let quizPassed = <?php echo $quizPassed ? 'true' : 'false';?>;

    // Update UI
    document.getElementById('progressBar').style.width = progressPercent + '%';
    document.getElementById('progressText').textContent = progressPercent + '%';

    const btnCourse = document.getElementById('btnCourse');
    const btnQuiz = document.getElementById('btnQuiz');
    const btnCert = document.getElementById('btnCert');
    const statusMessage = document.getElementById('statusMessage');

    // 🔒 DEFAULT LOCK
btnQuiz.classList.remove('bg-python','text-white','shadow-md','hover:shadow-lg','hover:-translate-y-0.5');
btnQuiz.classList.add('bg-gray-100','text-gray-400','cursor-not-allowed','pointer-events-none');

btnCert.classList.add('bg-gray-100','text-gray-400','cursor-not-allowed','pointer-events-none');

    // 🚀 COURSE PROGRESS
    if (progressPercent > 0 && progressPercent < 100) {
        btnCourse.innerHTML = '<i class="fas fa-play-circle mr-2"></i> Continue Learning';
    }

    // ✅ COURSE COMPLETED → UNLOCK QUIZ
    if (progressPercent >= 100) {

        btnCourse.innerHTML = '<i class="fas fa-book-reader mr-2"></i> Review Course';

        btnQuiz.classList.remove('bg-gray-100','text-gray-400','cursor-not-allowed','pointer-events-none');
        btnQuiz.classList.add('bg-python','text-white');

        statusMessage.innerHTML = "✅ Course completed! Quiz unlocked.";
    }

    // 🎯 QUIZ PASSED → UNLOCK CERTIFICATE
    if (progressPercent >= 100 && quizPassed) {

        btnCert.classList.remove('bg-gray-100','text-gray-400','cursor-not-allowed','pointer-events-none');
        btnCert.classList.add('bg-green-500','text-white');

        statusMessage.innerHTML = "🏆 Congrats! Certificate unlocked.";

        btnCert.addEventListener('click', () => {
            window.location.href = 'certificate_python.php?course=python';
        });
    }

});
</script>
</body>
</html>