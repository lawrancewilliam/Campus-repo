<?php
session_start();
include("../../db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../../signin.php");
    exit();
}

$user_id = $_SESSION['user_id']; // ✅ correct usage
$course_id = 1;

$check = $conn->prepare("SELECT * FROM quiz_results WHERE user_id=? AND course_id=? AND passed=1");
$check->bind_param("ii", $user_id, $course_id);
$check->execute();
$res = $check->get_result();

$already_done = $res->num_rows > 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Programming Quiz</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #306998; /* Python Blue */
            --secondary-color: #FFE873; /* Python Yellow */
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --danger-color: #f44336;
            --light-color: #f5f5f5;
            --dark-color: #212121;
            --text-color: #333;
            --border-color: #e0e0e0;
            --shadow: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 30px rgba(0,0,0,0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1f4068 0%, #1b1b2f 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* Top Header Bar */
        .top-header {
            background: white;
            padding: 1rem 2rem;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .test-info {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .test-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .test-details {
            display: flex;
            gap: 1.5rem;
            font-size: 0.9rem;
        }

        .test-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
        }

        .test-detail i {
            color: var(--primary-color);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        #timer {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--light-color);
            border-radius: 20px;
            font-weight: bold;
        }

        #timer.warning {
            background: #fff3cd;
            color: #856404;
        }

        #timer.danger {
            background: #f8d7da;
            color: #721c24;
        }

        .help-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s;
        }

        .help-btn:hover {
            transform: scale(1.1);
        }

        /* Main Content Area */
        .main-container {
            flex: 1;
            display: flex;
            padding: 2rem;
            gap: 2rem;
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
        }

        /* Question Area */
        .question-area {
            flex: 1;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .question-number {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .question-type {
            background: var(--primary-color);
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }

        .question-text {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 2rem;
            color: var(--dark-color);
        }

        .answers-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .answer-option {
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .answer-option:hover {
            border-color: var(--primary-color);
            background: #f8f9ff;
            transform: translateX(5px);
        }

        .answer-option.selected {
            border-color: var(--primary-color);
            background: #e8eaf6;
        }

        .answer-marker {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: var(--light-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: var(--primary-color);
        }

        .answer-option.selected .answer-marker {
            background: var(--primary-color);
            color: white;
        }

        .answer-text {
            flex: 1;
        }

        /* Input Styles */
        .fill-blank-input, .code-input {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        .fill-blank-input:focus, .code-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .code-input {
            min-height: 200px;
            font-family: 'Courier New', monospace;
            resize: vertical;
        }

        /* Rearrange Container */
        .rearrange-container {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .rearrange-item {
            padding: 1rem;
            background: var(--light-color);
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 2px solid transparent;
            transition: all 0.3s;
        }

        .rearrange-item:hover {
            border-color: var(--primary-color);
        }

        .rearrange-controls {
            display: flex;
            gap: 0.5rem;
        }

        .rearrange-controls button {
            width: 30px;
            height: 30px;
            border: none;
            background: var(--primary-color);
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .rearrange-controls button:hover:not(:disabled) {
            background: #204c72;
        }

        .rearrange-controls button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        /* Right Sidebar - Question Navigator */
        .right-sidebar {
            width: 280px;
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .navigator-title {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 1rem;
            color: var(--dark-color);
            text-align: center;
        }

        .navigator-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .nav-item {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--light-color);
            border: 2px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-item:hover {
            border-color: var(--primary-color);
            transform: scale(1.1);
        }

        .nav-item.current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .nav-item.answered {
            background: var(--success-color);
            color: white;
            border-color: var(--success-color);
        }

        .navigator-legend {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        .legend-box {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid var(--border-color);
        }

        .legend-box.current {
            background: var(--primary-color);
            border-color: var(--primary-color);
        }

        .legend-box.answered {
            background: var(--success-color);
            border-color: var(--success-color);
        }

        /* Bottom Navigation */
        .bottom-navigation {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-buttons {
            display: flex;
            gap: 1rem;
        }

        .nav-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-btn.prev {
            background: var(--light-color);
            color: var(--text-color);
        }

        .nav-btn.prev:hover:not(:disabled) {
            background: #e0e0e0;
        }

        .nav-btn.next {
            background: var(--primary-color);
            color: white;
        }

        .nav-btn.next:hover {
            background: #204c72;
        }

        .nav-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .progress-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .progress-bar-container {
            width: 200px;
            height: 8px;
            background: var(--light-color);
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: var(--primary-color);
            transition: width 0.5s;
        }

        .progress-text {
            font-size: 0.9rem;
            color: #666;
        }

        /* Intro Screen */
        .intro-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .intro-card {
            background: white;
            border-radius: 16px;
            padding: 3rem;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }

        .intro-icon {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .intro-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .intro-description {
            color: #666;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .intro-instructions {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            text-align: left;
        }

        .intro-instructions h3 {
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .intro-instructions ul {
            list-style: none;
            padding-left: 0;
        }

        .intro-instructions li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .intro-instructions li i {
            color: var(--success-color);
        }

        .start-btn {
            padding: 1rem 3rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }

        .start-btn:hover {
            background: #204c72;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(48, 105, 152, 0.3);
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background: var(--dark-color);
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 1rem;
            opacity: 0;
            transition: all 0.3s;
            z-index: 1000;
        }

        .toast.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }

        .toast.success {
            background: var(--success-color);
        }

        .toast.error {
            background: var(--danger-color);
        }

        .toast.info {
            background: var(--primary-color);
        }

        /* Results Section */
        .results-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 3rem;
            box-shadow: var(--shadow-lg);
            text-align: center;
            max-width: 800px;
            margin: 2rem auto;
        }

        .results-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
        }

        .results-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .results-score {
            font-size: 3rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .results-message {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }

        .results-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .results-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .action-btn.primary {
            background: var(--primary-color);
            color: white;
        }

        .action-btn.primary:hover {
            background: #204c72;
        }

        .action-btn.secondary {
            background: var(--light-color);
            color: var(--text-color);
        }

        .action-btn.secondary:hover {
            background: #e0e0e0;
        }

        /* Review Section */
        .review-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            max-width: 1000px;
            margin: 2rem auto;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .review-title {
            font-size: 1.8rem;
            color: var(--dark-color);
        }

        .back-btn {
            padding: 0.6rem 1.2rem;
            background: var(--light-color);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #e0e0e0;
        }

        .review-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .review-question {
            padding: 1.5rem;
            border-radius: 8px;
            border: 2px solid var(--border-color);
        }

        .review-question.correct {
            border-color: var(--success-color);
            background: #f1f8e9;
        }

        .review-question.incorrect {
            border-color: var(--danger-color);
            background: #ffebee;
        }

        .review-question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .review-question-number {
            font-weight: bold;
            color: var(--dark-color);
        }

        .review-status {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .review-status.correct {
            background: var(--success-color);
            color: white;
        }

        .review-status.incorrect {
            background: var(--danger-color);
            color: white;
        }

        .review-explanation {
            margin-top: 1rem;
            padding: 1rem;
            background: white;
            border-radius: 6px;
            border-left: 4px solid var(--primary-color);
        }

        .review-explanation-title {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .main-container {
                flex-direction: column;
            }

            .right-sidebar {
                width: 100%;
                position: static;
            }

            .navigator-grid {
                grid-template-columns: repeat(10, 1fr);
            }
        }

        @media (max-width: 768px) {
            .top-header {
                flex-direction: column;
                gap: 1rem;
            }

            .test-details {
                flex-direction: column;
                gap: 0.5rem;
            }

            .navigator-grid {
                grid-template-columns: repeat(8, 1fr);
            }

            .results-stats {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .navigator-grid {
                grid-template-columns: repeat(6, 1fr);
            }

            .progress-bar-container {
                width: 100px;
            }

            .nav-buttons {
                flex-direction: column;
                width: 100%;
            }

            .nav-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <?php if($already_done): ?>
<script>
alert("You already completed this quiz!");
window.location.href = "python_final_page.php";
</script>
<?php endif; ?>
</head>
<body>
    <!-- Top Header Bar -->
    <header class="top-header">
        <div class="test-info">
            <h1 class="test-title">Python Programming Quiz</h1>
            <div class="test-details">
                <div class="test-detail">
                    <i class="fas fa-question-circle"></i>
                    <span>50 Questions</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-clock"></i>
                    <span>90 Minutes</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-percentage"></i>
                    <span>70% to Pass</span>
                </div>
            </div>
        </div>
        <div class="header-actions">
            <div id="timer">
                <i class="fas fa-hourglass-half"></i>
                <span id="timerText">90:00</span>
            </div>
            <button class="help-btn" onclick="showHelp()">
                <i class="fas fa-question"></i>
            </button>
        </div>
    </header>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Question Area -->
        <div class="question-area">
            <div class="question-header">
                <div class="question-number" id="questionNumber">Question 1</div>
                <div class="question-type" id="questionType">Multiple Choice</div>
            </div>
            <div class="question-text" id="questionText">
                Loading question...
            </div>
            <div class="answers-container" id="answersContainer">
                <!-- Answers will be loaded here -->
            </div>
        </div>

        <!-- Right Sidebar - Question Navigator -->
        <aside class="right-sidebar">
            <div class="navigator-title">Question Navigator</div>
            <div class="navigator-grid" id="navigatorGrid">
                <!-- Question numbers will be generated here -->
            </div>
            <div class="navigator-legend">
                <div class="legend-item">
                    <div class="legend-box"></div>
                    <span>Not Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box answered"></div>
                    <span>Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box current"></div>
                    <span>Current</span>
                </div>
            </div>
        </aside>
    </div>

    <!-- Bottom Navigation -->
    <footer class="bottom-navigation">
        <div class="nav-buttons">
            <button class="nav-btn prev" id="prevBtn" onclick="previousQuestion()">
                <i class="fas fa-arrow-left"></i>
                Previous
            </button>
            <button class="nav-btn next" id="nextBtn" onclick="nextQuestion()">
                Next
                <i class="fas fa-arrow-right"></i>
            </button>
        </div>
        <div class="progress-container">
            <div class="progress-bar-container">
                <div class="progress-bar" id="progressBar" style="width: 2%"></div>
            </div>
            <div class="progress-text" id="progressText">Question 1 of 50</div>
        </div>
    </footer>

    <!-- Intro Screen -->
    <div class="intro-screen" id="introScreen">
        <div class="intro-card">
            <div class="intro-icon">
                <i class="fab fa-python"></i>
            </div>
            <h2 class="intro-title">Python Programming Quiz</h2>
            <p class="intro-description">
                Test your knowledge of Python programming with this comprehensive quiz covering 
                core concepts, data structures, functions, OOP, and more.
            </p>
            <div class="intro-instructions">
                <h3>Instructions:</h3>
                <ul>
                    <li><i class="fas fa-check"></i> You have 90 minutes to complete 50 questions</li>
                    <li><i class="fas fa-check"></i> Minimum 70% score required to pass</li>
                    <li><i class="fas fa-check"></i> Questions include multiple choice, true/false, fill in the blank, code writing, and rearrange</li>
                    <li><i class="fas fa-check"></i> Use the question navigator on the right to jump between questions</li>
                    <li><i class="fas fa-check"></i> Your progress is automatically saved</li>
                    <li><i class="fas fa-check"></i> Stay on this page - leaving may result in automatic submission</li>
                </ul>
            </div>
            <button class="start-btn" onclick="startQuiz()">
                Start Quiz
            </button>
        </div>
    </div>

    <!-- Results Section -->
    <div class="results-section" id="resultsSection">
        <div class="results-icon" id="resultsIcon">
            <i class="fas fa-trophy"></i>
        </div>
        <h2 class="results-title" id="resultsTitle">Quiz Completed!</h2>
        <div class="results-score" id="resultsScore">85%</div>
        <p class="results-message" id="resultsMessage">Great job! You've passed the quiz!</p>
        
        <div class="results-stats">
            <div class="stat-card">
                <div class="stat-label">Correct Answers</div>
                <div class="stat-value" id="correctAnswers">42</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Incorrect Answers</div>
                <div class="stat-value" id="incorrectAnswers">8</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Time Taken</div>
                <div class="stat-value" id="timeTaken">45:32</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Accuracy</div>
                <div class="stat-value" id="accuracy">84%</div>
            </div>
        </div>
        
        <div class="results-actions">
            <button class="action-btn primary" onclick="reviewAnswers()">
                <i class="fas fa-eye"></i>
                Review Answers
            </button>
            <button class="action-btn secondary" onclick="retakeQuiz()">
                <i class="fas fa-redo"></i>
                Retake Quiz
            </button>
            <button class="action-btn secondary" id="certBtn" onclick="downloadCertificate()" disabled>
                <i class="fas fa-download"></i>
                Download Certificate
            </button>
            <button class="action-btn secondary" onclick="shareResults()">
                <i class="fas fa-share"></i>
                Share Results
            </button>
        </div>
    </div>

    <!-- Review Section -->
    <div class="review-section" id="reviewSection">
        <div class="review-header">
            <h2 class="review-title">Answer Review</h2>
            <button class="back-btn" onclick="backToResults()">
                <i class="fas fa-arrow-left"></i>
                Back to Results
            </button>
        </div>
        <div class="review-container" id="reviewContainer">
            <!-- Review items will be generated here -->
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <i class="toast-icon fas fa-info-circle"></i>
        <span id="toastMessage">Notification message</span>
    </div>

    <script>

        function enterFullScreen() {
    let elem = document.documentElement;

    if (elem.requestFullscreen) {
        elem.requestFullscreen().catch(err => console.log(err));
    } else if (elem.webkitRequestFullscreen) {
        elem.webkitRequestFullscreen();
    } else if (elem.msRequestFullscreen) {
        elem.msRequestFullscreen();
    }
}

        // Python Quiz Data
        const quizData = [
            {
                id: 1,
                type: 'multiple',
                question: 'What is the output of print(type([])) in Python?',
                options: ['list', 'class', 'Array', 'type'],
                correct: 1,
                explanation: 'The built-in type() function returns the class type of the object, which is <class \'list\'>.'
            },
            {
                id: 2,
                type: 'multiple',
                question: 'Which of the following is NOT a keyword in Python?',
                options: ['assert', 'nonlocal', 'eval', 'pass'],
                correct: 2,
                explanation: '`eval` is a built-in function, not a keyword. The others are reserved Python keywords.'
            },
            {
                id: 3,
                type: 'truefalse',
                question: 'Python is a statically typed language.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Python is dynamically typed; you do not need to declare the type of a variable when you create one.'
            },
            {
                id: 4,
                type: 'fillblank',
                question: 'What keyword is used to define a function in Python?',
                correct: 'def',
                explanation: 'The `def` keyword is used to declare a function in Python.'
            },
            {
                id: 5,
                type: 'code',
                question: 'Write a lambda function that squares a number `x`.',
                correct: 'lambda x: x**2',
                explanation: 'A lambda function uses the `lambda` keyword followed by arguments, a colon, and the expression: lambda x: x**2'
            },
            {
                id: 6,
                type: 'multiple',
                question: 'What is the output of `3 ** 2`?',
                options: ['6', '9', '8', '1'],
                correct: 1,
                explanation: 'The `**` operator acts as the exponentiation operator. 3 squared is 9.'
            },
            {
                id: 7,
                type: 'truefalse',
                question: 'Tuples are mutable in Python.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Tuples are immutable; their elements cannot be changed once assigned.'
            },
            {
                id: 8,
                type: 'multiple',
                question: 'Which method adds an element to the end of a list?',
                options: ['insert()', 'push()', 'add()', 'append()'],
                correct: 3,
                explanation: 'The `append()` method adds a single item to the end of a list.'
            },
            {
                id: 9,
                type: 'fillblank',
                question: 'What built-in function returns the length of a list?',
                correct: 'len',
                explanation: 'The `len()` function returns the number of items in an object.'
            },
            {
                id: 10,
                type: 'code',
                question: 'Write a list comprehension that generates squares of numbers from 0 to 9.',
                correct: '[x**2 for x in range(10)]',
                explanation: 'List comprehensions provide a concise way to create lists: [expression for item in iterable].'
            },
            {
                id: 11,
                type: 'multiple',
                question: 'What does the `items()` method of a dictionary return?',
                options: ['A list of keys', 'A list of values', 'A view object of key-value tuples', 'A new dictionary'],
                correct: 2,
                explanation: 'The `items()` method returns a view object that displays a list of a given dictionary\'s (key, value) tuple pairs.'
            },
            {
                id: 12,
                type: 'truefalse',
                question: 'A set can contain duplicate elements.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'A set is an unordered collection of unique elements. Duplicates are automatically removed.'
            },
            {
                id: 13,
                type: 'rearrange',
                question: 'Rearrange the following operators from highest to lowest precedence:',
                options: ['Addition (+)', 'Multiplication (*)', 'Exponentiation (**)', 'Parentheses ()'],
                correct: ['Parentheses ()', 'Exponentiation (**)', 'Multiplication (*)', 'Addition (+)'],
                explanation: 'Parentheses override all precedence, followed by Exponentiation, Multiplication, and Addition (PEMDAS).'
            },
            {
                id: 14,
                type: 'multiple',
                question: 'What does the `pass` statement do?',
                options: ['Exits the program', 'Skips the current loop iteration', 'Does nothing (null operation)', 'Returns from a function'],
                correct: 2,
                explanation: '`pass` is a null operation. It is used as a placeholder when a statement is required syntactically.'
            },
            {
                id: 15,
                type: 'fillblank',
                question: 'What keyword is used to stop a loop completely?',
                correct: 'break',
                explanation: 'The `break` keyword terminates the current loop and resumes execution at the next statement.'
            },
            {
                id: 16,
                type: 'truefalse',
                question: 'The `else` clause can be used with a `for` loop in Python.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Yes, a `for` loop can have an `else` block which executes when the loop completes normally (without a break).'
            },
            {
                id: 17,
                type: 'multiple',
                question: 'What is the output of `print("Hello"[1:3])`?',
                options: ['He', 'el', 'll', 'lo'],
                correct: 1,
                explanation: 'Slicing syntax [start:stop] is exclusive of the stop index. Index 1 is "e" and index 2 is "l".'
            },
            {
                id: 18,
                type: 'code',
                question: 'Write a function named `greet` that takes a `name` and returns "Hello " concatenated with the name.',
                correct: 'def greet(name): return "Hello " + name',
                explanation: 'A standard function definition using def, taking an argument, and returning the concatenated string.'
            },
            {
                id: 19,
                type: 'fillblank',
                question: 'The ______ keyword is used to return a value from a generator function without destroying local variables.',
                correct: 'yield',
                explanation: '`yield` pauses the function saving all its states and later continues from there on successive calls.'
            },
            {
                id: 20,
                type: 'truefalse',
                question: 'A Python function can return multiple values separated by commas.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Yes, returning multiple values separated by commas implicitly returns them as a single tuple.'
            },
            {
                id: 21,
                type: 'multiple',
                question: 'How do you create an empty dictionary?',
                options: ['{}', '[]', '()', 'empty()'],
                correct: 0,
                explanation: '{} creates an empty dictionary. [] is an empty list, and () is an empty tuple.'
            },
            {
                id: 22,
                type: 'rearrange',
                question: 'Rearrange the steps to read a file safely using a context manager:',
                options: ['Read the contents', 'Open the file using with', 'Process the data', 'The file closes automatically'],
                correct: ['Open the file using with', 'Read the contents', 'Process the data', 'The file closes automatically'],
                explanation: 'You first open the file, then read it inside the block, process the data, and it automatically closes when exiting the block.'
            },
            {
                id: 23,
                type: 'multiple',
                question: 'Which exception is raised when a dictionary is queried for a non-existent key?',
                options: ['ValueError', 'IndexError', 'KeyError', 'MissingKeyError'],
                correct: 2,
                explanation: 'A KeyError is raised when a dictionary key is not found in the set of existing keys.'
            },
            {
                id: 24,
                type: 'truefalse',
                question: 'The `is` operator checks if two variables refer to the exact same object in memory.',
                options: ['True', 'False'],
                correct: 0,
                explanation: '`is` checks for object identity (memory address), whereas `==` checks for value equality.'
            },
            {
                id: 25,
                type: 'fillblank',
                question: 'The ______ block in a try-except statement always executes, regardless of whether an exception occurred.',
                correct: 'finally',
                explanation: 'The `finally` block is executed no matter what, making it perfect for cleaning up resources.'
            },
            {
                id: 26,
                type: 'code',
                question: 'Write a class definition named `Dog` with an empty body (using pass).',
                correct: 'class Dog: pass',
                explanation: 'Use the `class` keyword followed by the class name, a colon, and the `pass` statement.'
            },
            {
                id: 27,
                type: 'multiple',
                question: 'What is the purpose of the `__init__` method in Python?',
                options: ['To destroy an object', 'To initialize the object attributes', 'To print the object', 'To compare objects'],
                correct: 1,
                explanation: '`__init__` is the constructor method used to initialize instance variables when an object is created.'
            },
            {
                id: 28,
                type: 'truefalse',
                question: 'Python supports multiple inheritance.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Python fully supports multiple inheritance, allowing a class to inherit from more than one parent class.'
            },
            {
                id: 29,
                type: 'fillblank',
                question: 'The first parameter of an instance method in a class is conventionally named ____.',
                correct: 'self',
                explanation: '`self` represents the instance of the class and binds the attributes with the given arguments.'
            },
            {
                id: 30,
                type: 'rearrange',
                question: 'Order the Method Resolution Order (MRO) for class D(B, C) where B and C inherit from A:',
                options: ['D (Class itself)', 'B (First parent)', 'C (Second parent)', 'A (Common base)', 'object (Root base)'],
                correct: ['D (Class itself)', 'B (First parent)', 'C (Second parent)', 'A (Common base)', 'object (Root base)'],
                explanation: 'Python uses C3 Linearization. It checks the class itself, then left-to-right through parents, then base classes.'
            },
            {
                id: 31,
                type: 'multiple',
                question: 'What does the `@classmethod` decorator do?',
                options: ['Makes the method static', 'Binds the method to the class instead of the instance', 'Makes the method private', 'Caches the method result'],
                correct: 1,
                explanation: 'A class method receives the class as the implicit first argument (cls), rather than the instance.'
            },
            {
                id: 32,
                type: 'truefalse',
                question: 'Private attributes in Python (starting with `__`) are strictly inaccessible from outside the class.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'False. They are only name-mangled (changed to _ClassName__attribute), but can still be accessed.'
            },
            {
                id: 33,
                type: 'fillblank',
                question: 'The built-in function used to call methods of a parent class is ____.',
                correct: 'super',
                explanation: 'The `super()` function is used to give access to methods and properties of a parent or sibling class.'
            },
            {
                id: 34,
                type: 'code',
                question: 'Write a try-except block that ignores a `ZeroDivisionError` when calculating `1/0` (using pass).',
                correct: 'try: 1/0\nexcept ZeroDivisionError: pass',
                explanation: 'A simple try-except structure catching the specific exception and ignoring it.'
            },
            {
                id: 35,
                type: 'multiple',
                question: 'Which symbol is traditionally used for string formatting in older Python versions?',
                options: ['$', '#', '%', '@'],
                correct: 2,
                explanation: 'The `%` operator was the original method for string formatting in Python (e.g. "%s" % "Hello").'
            },
            {
                id: 36,
                type: 'truefalse',
                question: 'f-strings (formatted string literals) were introduced in Python 3.6.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'True. f-strings provide a fast and readable way to embed expressions inside string literals.'
            },
            {
                id: 37,
                type: 'fillblank',
                question: 'To use a specific function from a module, you use the syntax: from module ____ function',
                correct: 'import',
                explanation: 'The `import` keyword allows you to bring specific components into your current namespace.'
            },
            {
                id: 38,
                type: 'multiple',
                question: 'What does `if __name__ == "__main__":` signify?',
                options: ['The script is being imported', 'The script is running as the main program', 'The script has a function named main', 'It checks if the module is named main'],
                correct: 1,
                explanation: 'This idiom ensures that the block of code only runs if the file is executed directly, not if imported as a module.'
            },
            {
                id: 39,
                type: 'truefalse',
                question: 'The `map()` function immediately returns a constructed list in Python 3.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'False. In Python 3, `map()` returns a map object (an iterator), not a list. You must cast it with `list()`.'
            },
            {
                id: 40,
                type: 'code',
                question: 'Write the statement to import only the `sqrt` function from the `math` module.',
                correct: 'from math import sqrt',
                explanation: 'Use the `from module import function` syntax to keep the namespace clean.'
            },
            {
                id: 41,
                type: 'multiple',
                question: 'Which built-in module is used to work with Regular Expressions?',
                options: ['regex', 're', 'regexp', 'strings'],
                correct: 1,
                explanation: 'The `re` module provides regular expression matching operations.'
            },
            {
                id: 42,
                type: 'rearrange',
                question: 'Order the following numeric types from least complex/memory to most complex:',
                options: ['bool', 'int', 'float', 'complex'],
                correct: ['bool', 'int', 'float', 'complex'],
                explanation: 'Booleans are essentially integers (0/1), integers are whole numbers, floats have decimals, and complex numbers have real/imaginary parts.'
            },
            {
                id: 43,
                type: 'truefalse',
                question: '`sys.argv` contains a list of command-line arguments passed to a Python script.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'True. `sys.argv[0]` is the script name, and subsequent elements are the arguments.'
            },
            {
                id: 44,
                type: 'fillblank',
                question: 'The ____ keyword is used to trigger an exception manually.',
                correct: 'raise',
                explanation: 'You use `raise ExceptionName("Message")` to manually throw an error.'
            },
            {
                id: 45,
                type: 'multiple',
                question: 'What is the output of `bool("False")`?',
                options: ['True', 'False', 'None', 'Error'],
                correct: 0,
                explanation: 'Any non-empty string in Python evaluates to True when cast to a boolean, even the string "False".'
            },
            {
                id: 46,
                type: 'code',
                question: 'Write the code to open a file named "test.txt" in write mode using the built-in open function.',
                correct: 'open("test.txt", "w")',
                explanation: 'The `open()` function takes the filename and the mode string "w" for writing.'
            },
            {
                id: 47,
                type: 'truefalse',
                question: 'A decorator is a function that takes another function and extends its behavior without modifying its internal code.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'True. Decorators wrap a function to add functionality before or after it executes.'
            },
            {
                id: 48,
                type: 'fillblank',
                question: 'The `with` statement is used for context management and ensures the `__enter__` and ____ methods are called.',
                correct: '__exit__',
                explanation: 'The `__exit__` method is always called to clean up resources, such as closing a file.'
            },
            {
                id: 49,
                type: 'multiple',
                question: 'What does `*args` do in a function definition?',
                options: ['Passes keyword arguments as a dict', 'Dereferences a pointer', 'Gathers positional arguments into a tuple', 'Unpacks a list'],
                correct: 2,
                explanation: '`*args` collects extra positional arguments passed to the function into a tuple variable named args.'
            },
            {
                id: 50,
                type: 'rearrange',
                question: 'Rearrange the typical stages of using a decorator:',
                options: ['Define the decorator function', 'Define the target function with @decorator', 'Call the target function', 'The decorator wrapper executes'],
                correct: ['Define the decorator function', 'Define the target function with @decorator', 'Call the target function', 'The decorator wrapper executes'],
                explanation: 'You first create the decorator, apply it using the @ syntax above your target function, then call the target function to trigger the wrapped behavior.'
            }
        ];

        // Quiz State
        let currentQuestion = 0;
        let userAnswers = {};
        let startTime = Date.now();
        let timerInterval;
        let timeRemaining = 90 * 60; // 90 minutes in seconds
        let quizCompleted = false;
        let isQuizStarted = false;
        let warningsCount = 0;
        const MAX_WARNINGS = 3;

        // Start Quiz
function startQuiz() {

    // 🔥 FIRST hide intro
    document.getElementById('introScreen').style.display = 'none';

    isQuizStarted = true;
    initQuiz();
    startTimer();

    // 🔥 THEN fullscreen
    setTimeout(() => {
        enterFullScreen();
    }, 300);
}

        // Initialize Quiz
        function initQuiz() {
            renderQuestion();
            renderNavigator();
            updateProgress();
        }

        // Render Question
        function renderQuestion() {
            const question = quizData[currentQuestion];
            
            // Update question info
            document.getElementById('questionNumber').textContent = `Question ${currentQuestion + 1}`;
            document.getElementById('questionType').textContent = getQuestionTypeText(question.type);
            document.getElementById('questionText').textContent = question.question;
            
            // Render answers based on question type
            const answersContainer = document.getElementById('answersContainer');
            answersContainer.innerHTML = '';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                question.options.forEach((option, index) => {
                    const answerOption = document.createElement('div');
                    answerOption.className = 'answer-option';
                    answerOption.onclick = () => selectAnswer(index);
                    
                    const isCorrect = userAnswers[question.id] === index;
                    if (isCorrect) {
                        answerOption.classList.add('selected');
                    }
                    
                    answerOption.innerHTML = `
                        <div class="answer-marker">${String.fromCharCode(65 + index)}</div>
                        <div class="answer-text">${option}</div>
                    `;
                    
                    answersContainer.appendChild(answerOption);
                });
            } else if (question.type === 'fillblank') {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'fill-blank-input';
                input.placeholder = 'Type your answer here...';
                input.value = userAnswers[question.id] || '';
                input.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Answer saved!', 'success');
                };
                answersContainer.appendChild(input);
            } else if (question.type === 'code') {
                const textarea = document.createElement('textarea');
                textarea.className = 'code-input';
                textarea.placeholder = 'Write your code here...';
                textarea.value = userAnswers[question.id] || '';
                textarea.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Code saved!', 'success');
                };
                answersContainer.appendChild(textarea);
            } else if (question.type === 'rearrange') {
                const container = document.createElement('div');
                container.className = 'rearrange-container';
                
                // Initialize user answer if not present
                if (!userAnswers[question.id]) {
                    userAnswers[question.id] = [...question.options];
                }
                
                const currentOrder = userAnswers[question.id];
                
                currentOrder.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'rearrange-item';
                    div.innerHTML = `
                        <div class="rearrange-text">${item}</div>
                        <div class="rearrange-controls">
                            <button onclick="moveItem(${question.id}, ${index}, -1)" ${index === 0 ? 'disabled' : ''} title="Move Up"><i class="fas fa-chevron-up"></i></button>
                            <button onclick="moveItem(${question.id}, ${index}, 1)" ${index === currentOrder.length - 1 ? 'disabled' : ''} title="Move Down"><i class="fas fa-chevron-down"></i></button>
                        </div>
                    `;
                    container.appendChild(div);
                });
                answersContainer.appendChild(container);
            }
            
            // Update navigation buttons
            updateNavigationButtons();
        }

        // Get Question Type Text
        function getQuestionTypeText(type) {
            const types = {
                'multiple': 'Multiple Choice',
                'truefalse': 'True/False',
                'fillblank': 'Fill in the Blank',
                'code': 'Code Writing',
                'rearrange': 'Rearrange the Order'
            };
            return types[type] || 'Question';
        }

        // Select Answer
        function selectAnswer(index) {
            const question = quizData[currentQuestion];
            userAnswers[question.id] = index;
            
            // Update UI
            const answerOptions = document.querySelectorAll('.answer-option');
            answerOptions.forEach((option, i) => {
                option.classList.remove('selected');
                if (i === index) {
                    option.classList.add('selected');
                }
            });
            
            showToast('Answer selected!', 'success');
            updateNavigator();
        }

        // Move item for rearrange questions
        function moveItem(questionId, index, direction) {
            const arr = userAnswers[questionId];
            const temp = arr[index];
            arr[index] = arr[index + direction];
            arr[index + direction] = temp;
            renderQuestion();
            updateNavigator();
        }

        // Next Question
        function nextQuestion() {
            if (currentQuestion < quizData.length - 1) {
                currentQuestion++;
                renderQuestion();
                updateNavigator();
                updateProgress();
            } else {
                finishQuiz();
            }
        }

        // Previous Question
        function previousQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                renderQuestion();
                updateNavigator();
                updateProgress();
            }
        }

        // Update Navigation Buttons
        function updateNavigationButtons() {
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            
            prevBtn.disabled = currentQuestion === 0;
            
            if (currentQuestion === quizData.length - 1) {
                nextBtn.innerHTML = '<i class="fas fa-flag-checkered"></i> Finish';
            } else {
                nextBtn.innerHTML = 'Next <i class="fas fa-arrow-right"></i>';
            }
        }

        // Update Progress
        function updateProgress() {
            const progress = ((currentQuestion + 1) / quizData.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressText').textContent = 
                `Question ${currentQuestion + 1} of ${quizData.length}`;
        }

        // Render Navigator
        function renderNavigator() {
            const navigatorGrid = document.getElementById('navigatorGrid');
            navigatorGrid.innerHTML = '';
            
            for (let i = 0; i < quizData.length; i++) {
                const navItem = document.createElement('div');
                navItem.className = 'nav-item';
                navItem.textContent = i + 1;
                
                if (i === currentQuestion) {
                    navItem.classList.add('current');
                }
                
                if (userAnswers[quizData[i].id] !== undefined) {
                    navItem.classList.add('answered');
                }
                
                navItem.onclick = () => goToQuestion(i);
                navigatorGrid.appendChild(navItem);
            }
        }

        // Update Navigator
        function updateNavigator() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach((item, index) => {
                item.classList.remove('current');
                if (index === currentQuestion) {
                    item.classList.add('current');
                }
                
                if (userAnswers[quizData[index].id] !== undefined) {
                    item.classList.add('answered');
                }
            });
        }

        // Go to Question
        function goToQuestion(index) {
            currentQuestion = index;
            renderQuestion();
            updateNavigator();
            updateProgress();
        }

        // Start Timer
        function startTimer() {
            timerInterval = setInterval(() => {
                timeRemaining--;
                updateTimerDisplay();
                
                if (timeRemaining <= 0) {
                    clearInterval(timerInterval);
                    finishQuiz();
                }
            }, 1000);
        }

        // Update Timer Display
        function updateTimerDisplay() {
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            const timerText = document.getElementById('timerText');
            const timer = document.getElementById('timer');
            
            timerText.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeRemaining <= 300) { // 5 minutes
                timer.classList.add('warning');
            }
            
            if (timeRemaining <= 60) { // 1 minute
                timer.classList.remove('warning');
                timer.classList.add('danger');
            }
        }

        // Finish Quiz
        function finishQuiz() {
    if (quizCompleted) return;
    quizCompleted = true;

    clearInterval(timerInterval);

    const results = calculateResults();

localStorage.setItem("quizSubmitted", "true");

fetch('../../save_quiz.php', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        course_slug: "python",
        answers: userAnswers,               // ✅ correct
        score: results.correct,             // ✅ correct
        total: results.total,               // ✅ correct
        percentage: results.percentage      // ✅ correct
    })
})
.then(res => res.text())
.then(data => {
    console.log("SERVER RESPONSE:", data);

    if(data.includes("success")){
        console.log("✅ Saved successfully");
    } else {
        alert("Error: " + data);
    }
})
.catch(err => {
    console.log("Fetch error:", err);
});

    // UI hide
    document.querySelector('.main-container').style.display = 'none';
    document.querySelector('.bottom-navigation').style.display = 'none';
    document.querySelector('.top-header').style.display = 'none';

    showResults(results);
}

        // Calculate Results
        function calculateResults() {
            let correct = 0;
            let total = quizData.length;
            
            quizData.forEach(question => {
                const userAnswer = userAnswers[question.id];
                
                if (question.type === 'multiple' || question.type === 'truefalse') {
                    if (userAnswer === question.correct) {
                        correct++;
                    }
                } else if (question.type === 'fillblank') {
                    if (userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase()) {
                        correct++;
                    }
                } else if (question.type === 'code') {
                    // Very simple length check for code submission simulation
                    if (userAnswer && userAnswer.length > 5) {
                        correct++;
                    }
                } else if (question.type === 'rearrange') {
                    if (userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct)) {
                        correct++;
                    }
                }
            });
            
            const percentage = Math.round((correct / total) * 100);
            const timeTaken = Math.floor((Date.now() - startTime) / 1000);
            
            return {
                correct,
                incorrect: total - correct,
                total,
                percentage,
                timeTaken,
                passed: percentage >= 70
            };
        }

        // Show Results
        function showResults(results) {
    document.getElementById('resultsSection').style.display = 'block';

    const certBtn = document.getElementById("certBtn"); // 🔥 important

    if (results.passed) {
        certBtn.disabled = false;
        certBtn.style.opacity = "1";
        certBtn.style.cursor = "pointer";
    } else {
        certBtn.disabled = true;
        certBtn.style.opacity = "0.5";
        certBtn.style.cursor = "not-allowed";
    }
    
            // Update results UI
            const resultsIcon = document.getElementById('resultsIcon');
            const resultsTitle = document.getElementById('resultsTitle');
            const resultsScore = document.getElementById('resultsScore');
            const resultsMessage = document.getElementById('resultsMessage');
            
            if (results.percentage >= 90) {
                resultsIcon.innerHTML = '<i class="fas fa-trophy" style="color: #4caf50;"></i>';
                resultsTitle.textContent = 'Excellent!';
                resultsMessage.textContent = 'Outstanding performance! You\'re a Python expert!';
            } else if (results.percentage >= 70) {
                resultsIcon.innerHTML = '<i class="fas fa-star" style="color: #ff9800;"></i>';
                resultsTitle.textContent = 'Well Done!';
                resultsMessage.textContent = 'Great job! You\'ve passed the quiz!';
            } else {
                resultsIcon.innerHTML = '<i class="fas fa-redo" style="color: #f44336;"></i>';
                resultsTitle.textContent = 'Keep Practicing!';
                resultsMessage.textContent = 'You didn\'t pass this time, but don\'t give up!';
            }
                        
            resultsScore.textContent = results.percentage + '%';
            
            // Update stats
            document.getElementById('correctAnswers').textContent = results.correct;
            document.getElementById('incorrectAnswers').textContent = results.incorrect;
            document.getElementById('timeTaken').textContent = formatTime(results.timeTaken);
            document.getElementById('accuracy').textContent = results.percentage + '%';
        }

        // Format Time
        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${minutes}:${secs.toString().padStart(2, '0')}`;
        }

        // Review Answers
        function reviewAnswers() {
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'block';
            
            const reviewContainer = document.getElementById('reviewContainer');
            reviewContainer.innerHTML = '';
            
            quizData.forEach((question, index) => {
                const userAnswer = userAnswers[question.id];
                const isCorrect = checkAnswer(question, userAnswer);
                
                const reviewItem = document.createElement('div');
                reviewItem.className = `review-question ${isCorrect ? 'correct' : 'incorrect'}`;
                
                reviewItem.innerHTML = `
                    <div class="review-question-header">
                        <div class="review-question-number">Question ${index + 1}</div>
                        <div class="review-status ${isCorrect ? 'correct' : 'incorrect'}">
                            <i class="fas fa-${isCorrect ? 'check' : 'times'}"></i>
                            ${isCorrect ? 'Correct' : 'Incorrect'}
                        </div>
                    </div>
                    <p style="margin-bottom: 1rem;">${question.question}</p>
                    <div style="margin-bottom: 1rem;">
                        <strong>Your answer:</strong> ${formatUserAnswer(question, userAnswer)}
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <strong>Correct answer:</strong> ${formatCorrectAnswer(question)}
                    </div>
                    <div class="review-explanation">
                        <div class="review-explanation-title">Explanation</div>
                        ${question.explanation}
                    </div>
                `;
                
                reviewContainer.appendChild(reviewItem);
            });
        }

        // Check Answer
        function checkAnswer(question, userAnswer) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return userAnswer === question.correct;
            } else if (question.type === 'fillblank') {
                return userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase();
            } else if (question.type === 'code') {
                return userAnswer && userAnswer.length > 5;
            } else if (question.type === 'rearrange') {
                return userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct);
            }
            return false;
        }

        // Format User Answer
        function formatUserAnswer(question, userAnswer) {
            if (userAnswer === undefined || userAnswer === null || userAnswer === '') return 'Not answered';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[userAnswer] || 'Invalid answer';
            } else if (question.type === 'fillblank') {
                return userAnswer;
            } else if (question.type === 'code') {
                return '<code>' + userAnswer.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + (userAnswer.length > 100 ? '...' : '') + '</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + userAnswer.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return userAnswer;
        }

        // Format Correct Answer
        function formatCorrectAnswer(question) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[question.correct];
            } else if (question.type === 'fillblank') {
                return question.correct;
            } else if (question.type === 'code') {
                return '<code>' + question.correct.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + '...</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + question.correct.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return question.correct;
        }

        // Back to Results
        function backToResults() {
            document.getElementById('reviewSection').style.display = 'none';
            document.getElementById('resultsSection').style.display = 'block';
        }

        // Retake Quiz
        function retakeQuiz() {
            // Reset state
            currentQuestion = 0;
            userAnswers = {};
            startTime = Date.now();
            timeRemaining = 90 * 60;
            quizCompleted = false;
            warningsCount = 0;

            localStorage.removeItem("quizSubmitted");  //ADD THIS
            
            // Reset UI
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'none';
            document.querySelector('.main-container').style.display = 'flex';
            document.querySelector('.bottom-navigation').style.display = 'flex';
            document.querySelector('.top-header').style.display = 'flex';
            
            // Restart
            initQuiz();
            startTimer();
        }

        // Download Certificate
function downloadCertificate() {
    window.location.href = "certificate_python.php?course=python";
}

        // Share Results
        function shareResults() {
            const results = calculateResults();
            const text = `I scored ${results.percentage}% on the Python Programming Quiz on Learnify! 🐍🎉`;
            
            if (navigator.share) {
                navigator.share({
                    title: 'Python Quiz Results',
                    text: text,
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(text);
                showToast('Results copied to clipboard!', 'success');
            }
        }

        // Show Help
        function showHelp() {
            showToast('Use the question navigator on the right to jump between questions. You have 90 minutes to complete the quiz.', 'info');
        }

        // Show Toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            const toastIcon = toast.querySelector('.toast-icon i');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type} show`;
            
            // Update icon
            if (type === 'success') {
                toastIcon.className = 'fas fa-check-circle';
            } else if (type === 'error') {
                toastIcon.className = 'fas fa-times-circle';
            } else {
                toastIcon.className = 'fas fa-info-circle';
            }
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Prevent accidental page refresh
        window.addEventListener('beforeunload', function(e) {
            if (!quizCompleted && isQuizStarted && Object.keys(userAnswers).length > 0) {
                e.preventDefault();
                e.returnValue = 'Your quiz progress will be lost. Are you sure you want to leave?';
            }
        });

        // Handle visibility change for anti-cheat
document.addEventListener("visibilitychange", () => {
    if (document.hidden && isQuizStarted && !quizCompleted) {

        warningsCount++;

        if (warningsCount >= MAX_WARNINGS) {

            showToast("❌ Quiz Cancelled! Too many tab switches", "error");

            setTimeout(() => {

                // 🔥 Prevent duplicate save
                if (!localStorage.getItem("quizSubmitted")) {
                    localStorage.setItem("quizSubmitted", "true");

                    fetch('../../save_quiz.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            answers: userAnswers,
                            score: 0,
                            total: quizData.length,
                            percentage: 0,
                            passed: 0
                        })
                    }).catch(err => console.log(err));
                }

                // 🔥 ALWAYS REDIRECT
                window.location.href = "python_course_overview.php";

            }, 1000);

        } else {
            alert(`⚠️ Warning ${warningsCount}/${MAX_WARNINGS}\n\nDo not switch tabs!`);
        }
    }
});
    </script>
</body>
</html>