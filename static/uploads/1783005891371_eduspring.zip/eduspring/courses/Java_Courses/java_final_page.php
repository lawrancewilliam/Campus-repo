<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB connection failed");
}

if(!isset($_SESSION['user_email'])){
    header("Location: /eduspring/signin.php");
    exit();
}

$email = $_SESSION['user_email'];

// 🔥 GET USER ID FROM EMAIL
$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$resUser = $getUser->get_result();

$userData = $resUser->fetch_assoc();

if(!$userData){
    die("User not found");
}

$user_id = $userData['id'];

$course_id = 2; // Java

$completedTopicsList = [];

$getTopics = $conn->prepare("
SELECT topic_name FROM topic_progress 
WHERE user_id=? AND course_id=?
");

$getTopics->bind_param("ii", $user_id, $course_id);
$getTopics->execute();
$resultTopics = $getTopics->get_result();

while($row = $resultTopics->fetch_assoc()){
    $completedTopicsList[] = $row['topic_name'];
}

$stmt = $conn->prepare("
SELECT completed_topics, total_topics 
FROM course_progress 
WHERE user_id=? AND course_id=?
");

$stmt->bind_param("ii", $user_id, $course_id);
$stmt->execute();
$res = $stmt->get_result();

if($res->num_rows > 0){

    $row = $res->fetch_assoc(); // ✅ FIRST FETCH

    $completed = (int)$row['completed_topics']; // ✅ THEN ASSIGN
    $total = (int)$row['total_topics'];         // ✅ THEN ASSIGN

} else {
    $completed = 0;
    $total = 28;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Java Programming Tutorial - Complete Guide</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-java.min.js"></script>
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .sidebar-item {
            transition: all 0.3s ease;
        }
        
        .sidebar-item:hover {
            transform: translateX(5px);
        }
        
        .sidebar-item.active {
            background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
            color: white;
        }
        
        .topic-completed {
            position: relative;
        }
        
        .topic-completed::after {
            content: '✓';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #10b981;
            font-weight: bold;
        }
        
        .content-section {
            display: none;
            animation: fadeIn 0.5s ease-in;
        }
        
        .content-section.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .code-toolbar {
            position: relative;
            background: #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .copy-button {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #4f46e5;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background 0.3s ease;
            z-index: 10;
        }
        
        .copy-button:hover {
            background: #3730a3;
        }
        
        pre[class*="language-"] {
            margin: 0;
            padding: 20px;
            background: transparent;
        }
        
        .progress-ring {
            transform: rotate(-90deg);
        }
        
        .progress-ring-circle {
            transition: stroke-dashoffset 0.35s;
            stroke: #10b981;
            stroke-dasharray: 75.398 75.398;
        }
        
        .search-highlight {
            background-color: #fef3c7;
            padding: 1px 2px;
            border-radius: 2px;
        }
        
        /* Enhanced search bar styles */
        .main-search-container {
            max-width: 600px;
            margin: 0 auto;
            position: relative;
        }
        
        .search-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-top: 4px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            max-height: 400px;
            overflow-y: auto;
            z-index: 50;
            display: none;
        }
        
        .search-dropdown.active {
            display: block;
        }
        
        .search-result-item {
            padding: 12px 16px;
            cursor: pointer;
            transition: background 0.2s ease;
            border-bottom: 1px solid #f3f4f6;
        }
        
        .search-result-item:hover {
            background: #f9fafb;
        }
        
        .search-result-item:last-child {
            border-bottom: none;
        }
        
        .no-results {
            padding: 20px;
            text-align: center;
            color: #6b7280;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header with Enhanced Search Bar -->
    <header class="gradient-bg text-white shadow-lg sticky top-0 z-40">
        <div class="container mx-auto px-4 py-4">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <button id="menuToggle" class="md:hidden text-white" onclick="toggleSidebar()">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold flex items-center gap-2">
                        <i class="fab fa-java"></i>
                        Java Programming Tutorial
                    </h1>
                </div>
                
                <!-- Enhanced Search Bar at Center Top -->
                <div class="main-search-container w-full md:w-auto">
                    <div class="relative">
                        <input 
                            type="text" 
                            id="globalSearch" 
                            placeholder="Search topics... (Ctrl+K)"
                            class="w-full md:w-96 px-4 py-2 pl-10 pr-10 text-gray-800 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-white/50 shadow-md"
                        >
                        <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        <button 
                            id="clearSearch" 
                            class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 hidden"
                            onclick="clearSearch()"
                        >
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <!-- Search Dropdown -->
                    <div id="searchDropdown" class="search-dropdown"></div>
                </div>
                
                <!-- Progress Indicator -->
                <div class="flex items-center gap-3">
                    <div class="text-right hidden md:block">
                        <div class="text-sm opacity-90">Progress</div>
                        <div class="font-bold" id="progressText">0%</div>
                    </div>
                    <div class="relative">
                        <svg width="30" height="30" class="progress-ring">
                            <circle
                                cx="15"
                                cy="15"
                                r="12"
                                stroke="#ffffff30"
                                stroke-width="3"
                                fill="none"
                            />
                            <circle
                                id="progressCircle"
                                class="progress-ring-circle"
                                cx="15"
                                cy="15"
                                r="12"
                                stroke-width="3"
                                fill="none"
                                stroke-dashoffset="75.398"
                            />
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </header>

<script>
    let completedFromDB = <?php echo $completed; ?>;
    let totalFromDB = <?php echo $total; ?>;

    let completedTopicsFromDB = <?php echo json_encode($completedTopicsList); ?>;
    
    document.addEventListener('DOMContentLoaded', function() {

    let percentage = Math.min(100, Math.round((completedFromDB / totalFromDB) * 100));

    document.getElementById('progressText').textContent = percentage + '%';

    const circumference = 2 * Math.PI * 12;
    const offset = circumference - (percentage / 100) * circumference;
    document.getElementById('progressCircle').style.strokeDashoffset = offset;

// Apply tick marks from DB
completedTopicsFromDB.forEach(topic => {
    const el = document.querySelector(`[data-topic="${topic}"]`);
    if(el){
        el.classList.add('topic-completed');
    }
});

});

</script>

    <div class="flex">
        <!-- Sidebar (without search) -->
        <aside id="sidebar" class="sidebar w-64 bg-white shadow-lg h-screen sticky top-16 overflow-y-auto hidden md:block">
            <div class="p-4">
                <h2 class="text-lg font-bold mb-4 text-gray-800">Course Content</h2>
                
                <!-- Unit 1 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 1: Basics</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="intro" onclick="showContent('intro'); markTopicComplete('intro')">
                            <i class="fas fa-book-open mr-2"></i>Introduction to Java
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="setup" onclick="showContent('setup'); markTopicComplete('setup')">
                            <i class="fas fa-download mr-2"></i>Setup & Installation
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="syntax" onclick="showContent('syntax'); markTopicComplete('syntax')">
                            <i class="fas fa-code mr-2"></i>Basic Syntax
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="variables" onclick="showContent('variables'); markTopicComplete('variables')">
                            <i class="fas fa-database mr-2"></i>Variables & Data Types
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="operators" onclick="showContent('operators'); markTopicComplete('operators')">
                            <i class="fas fa-calculator mr-2"></i>Operators
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="input" onclick="showContent('input'); markTopicComplete('input')">
                            <i class="fas fa-keyboard mr-2"></i>User Input
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="comments" onclick="showContent('comments'); markTopicComplete('comments')">
                            <i class="fas fa-comment mr-2"></i>Comments
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="first" onclick="showContent('first'); markTopicComplete('first')">
                            <i class="fas fa-play mr-2"></i>First Program
                        </div>
                    </div>
                </div>
                
                <!-- Unit 2 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 2: OOP</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="classes" onclick="showContent('classes'); markTopicComplete('classes')">
                            <i class="fas fa-cube mr-2"></i>Classes & Objects
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="methods" onclick="showContent('methods'); markTopicComplete('methods')">
                            <i class="fas fa-functions mr-2"></i>Methods
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="constructors" onclick="showContent('constructors'); markTopicComplete('constructors')">
                            <i class="fas fa-tools mr-2"></i>Constructors
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="inheritance" onclick="showContent('inheritance'); markTopicComplete('inheritance')">
                            <i class="fas fa-sitemap mr-2"></i>Inheritance
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="polymorphism" onclick="showContent('polymorphism'); markTopicComplete('polymorphism')">
                            <i class="fas fa-shapes mr-2"></i>Polymorphism
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="encapsulation" onclick="showContent('encapsulation'); markTopicComplete('encapsulation')">
                            <i class="fas fa-lock mr-2"></i>Encapsulation
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="static" onclick="showContent('static'); markTopicComplete('static')">
                            <i class="fas fa-bolt mr-2"></i>Static Members
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="inner" onclick="showContent('inner'); markTopicComplete('inner')">
                            <i class="fas fa-layer-group mr-2"></i>Inner Classes
                        </div>
                    </div>
                </div>
                
                <!-- Unit 3 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 3: Advanced</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="collections" onclick="showContent('collections'); markTopicComplete('collections')">
                            <i class="fas fa-box mr-2"></i>Collections Framework
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="generics" onclick="showContent('generics'); markTopicComplete('generics')">
                            <i class="fas fa-code-branch mr-2"></i>Generics
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="threads" onclick="showContent('threads'); markTopicComplete('threads')">
                            <i class="fas fa-sync-alt mr-2"></i>Multithreading
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="lambda" onclick="showContent('lambda'); markTopicComplete('lambda')">
                            <i class="fas fa-arrow-right mr-2"></i>Lambda Expressions
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="streams" onclick="showContent('streams'); markTopicComplete('streams')">
                            <i class="fas fa-water mr-2"></i>Stream API
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="exceptions" onclick="showContent('exceptions'); markTopicComplete('exceptions')">
                            <i class="fas fa-exclamation-triangle mr-2"></i>Exception Handling
                        </div>
                    </div>
                </div>
                
                <!-- Unit 4 -->
                <div class="mb-6">
                    <h3 class="text-sm font-semibold text-gray-600 uppercase tracking-wider mb-2">Unit 4: Applications</h3>
                    <div class="space-y-1">
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="strings" onclick="showContent('strings'); markTopicComplete('strings')">
                            <i class="fas fa-font mr-2"></i>String Class
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="files" onclick="showContent('files'); markTopicComplete('files')">
                            <i class="fas fa-file mr-2"></i>File I/O
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="jdbc" onclick="showContent('jdbc'); markTopicComplete('jdbc')">
                            <i class="fas fa-database mr-2"></i>JDBC
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="networking" onclick="showContent('networking'); markTopicComplete('networking')">
                            <i class="fas fa-network-wired mr-2"></i>Networking
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="swing" onclick="showContent('swing'); markTopicComplete('swing')">
                            <i class="fas fa-window-maximize mr-2"></i>GUI with Swing
                        </div>
                        <div class="sidebar-item px-3 py-2 rounded-lg cursor-pointer hover:bg-gray-100" data-topic="patterns" onclick="showContent('patterns'); markTopicComplete('patterns')">
                            <i class="fas fa-th mr-2"></i>Design Patterns
                        </div>
                    </div>
                </div>
                
                <!-- Progress Summary -->
                <div class="mt-6 p-4 bg-gray-50 rounded-lg">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm text-gray-600">Completed</span>
                        <span class="text-sm font-bold text-gray-800">
                            <span id="completedCount">0</span>/<span id="totalCount">0</span>
                        </span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div id="progressBar" class="bg-green-500 h-2 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            <!-- Introduction Section -->
            <section id="intro" class="content-section active">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-book-open mr-2"></i>Introduction to Java
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">What is Java?</h3>
                    <ul class="list-disc pl-6 space-y-2 text-gray-700">
                        <li>Object-oriented programming language</li>
                        <li>Platform-independent (Write Once, Run Anywhere)</li>
                        <li>Developed by Sun Microsystems (now Oracle) in 1995</li>
                        <li>Widely used for enterprise applications, Android development, and web services</li>
                    </ul>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Key Features</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Simple</h4>
                            <p class="text-gray-600 text-sm">Easy to learn and use, with syntax similar to C++ but simpler.</p>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Object-Oriented</h4>
                            <p class="text-gray-600 text-sm">Everything in Java is an object, promoting modularity and reusability.</p>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Platform Independent</h4>
                            <p class="text-gray-600 text-sm">Java code can run on any platform that supports Java without recompilation.</p>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Secure</h4>
                            <p class="text-gray-600 text-sm">Built-in security features to protect against viruses and tampering.</p>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Robust</h4>
                            <p class="text-gray-600 text-sm">Strong memory management, exception handling, and type checking.</p>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Multithreaded</h4>
                            <p class="text-gray-600 text-sm">Support for concurrent programming with built-in multithreading.</p>
                        </div>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Java Applications</h3>
                    <div class="bg-blue-50 p-4 rounded-lg mt-4">
                        <p class="text-gray-700">Java is used in various domains:</p>
                        <ul class="list-disc pl-6 mt-2 space-y-1 text-gray-700">
                            <li>Enterprise applications (Spring, Jakarta EE)</li>
                            <li>Android mobile app development</li>
                            <li>Web services and REST APIs</li>
                            <li>Big data technologies (Hadoop, Spark)</li>
                            <li>Scientific and financial applications</li>
                            <li>Desktop applications (Swing, JavaFX)</li>
                        </ul>
                    </div>
                </div>
            </section>

            <!-- Setup Section -->
            <section id="setup" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-download mr-2"></i>Setup & Installation
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Follow these steps to set up Java development environment on your system.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Step 1: Install JDK</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># Check if Java is installed
java -version

# If not installed, download from:
# https://www.oracle.com/java/technologies/downloads/

# For Ubuntu/Debian:
sudo apt update
sudo apt install openjdk-11-jdk

# For macOS (using Homebrew):
brew install openjdk@11

# For Windows:
# Download and run the installer from Oracle website</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Step 2: Set JAVA_HOME</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># For Linux/macOS (add to ~/.bashrc or ~/.zshrc)
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$PATH:$JAVA_HOME/bin

# For Windows (System Properties > Environment Variables)
# JAVA_HOME = C:\Program Files\Java\jdk-11
# PATH = %PATH%;%JAVA_HOME%\bin</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Step 3: Verify Installation</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># Verify Java version
java -version

# Verify Java compiler
javac -version

# Check JAVA_HOME
echo $JAVA_HOME</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Step 4: Install an IDE</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">IntelliJ IDEA</h4>
                            <p class="text-gray-600 text-sm mb-2">Popular IDE for Java development</p>
                            <a href="https://www.jetbrains.com/idea/" class="text-blue-500 text-sm hover:underline">Download</a>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Eclipse</h4>
                            <p class="text-gray-600 text-sm mb-2">Open-source IDE for Java</p>
                            <a href="https://www.eclipse.org/downloads/" class="text-blue-500 text-sm hover:underline">Download</a>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">VS Code</h4>
                            <p class="text-gray-600 text-sm mb-2">Lightweight editor with Java extensions</p>
                            <a href="https://code.visualstudio.com/" class="text-blue-500 text-sm hover:underline">Download</a>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Syntax Section -->
            <section id="syntax" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-code mr-2"></i>Basic Syntax
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Understanding Java syntax is the foundation of writing Java programs.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic Program Structure</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class HelloWorld {
    // This is the main method - entry point of the program
    public static void main(String[] args) {
        // Print statement to display output
        System.out.println("Hello, World!");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Key Syntax Rules</h3>
                    <ul class="list-disc pl-6 space-y-2 text-gray-700">
                        <li>Java is case-sensitive (HelloWorld ≠ helloworld)</li>
                        <li>Class names should start with uppercase letter (PascalCase)</li>
                        <li>Method names should start with lowercase letter (camelCase)</li>
                        <li>Every statement must end with a semicolon (;)</li>
                        <li>Code blocks are enclosed in curly braces {}</li>
                        <li>Java files must have the same name as the public class</li>
                    </ul>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Naming Conventions</h3>
                    <div class="bg-gray-50 p-4 rounded-lg mt-4">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="border-b">
                                    <th class="text-left py-2">Type</th>
                                    <th class="text-left py-2">Convention</th>
                                    <th class="text-left py-2">Example</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b">
                                    <td class="py-2">Class</td>
                                    <td class="py-2">PascalCase</td>
                                    <td class="py-2">MyClass, HelloWorld</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">Method</td>
                                    <td class="py-2">camelCase</td>
                                    <td class="py-2">myMethod(), calculateSum()</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">Variable</td>
                                    <td class="py-2">camelCase</td>
                                    <td class="py-2">myVariable, userName</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">Constant</td>
                                    <td class="py-2">UPPER_SNAKE_CASE</td>
                                    <td class="py-2">MAX_VALUE, PI</td>
                                </tr>
                                <tr>
                                    <td class="py-2">Package</td>
                                    <td class="py-2">lowercase</td>
                                    <td class="py-2">com.example.app</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- Variables Section -->
            <section id="variables" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-database mr-2"></i>Variables & Data Types
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Variables are containers for storing data values. Java has two categories of data types: primitive and reference.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Primitive Data Types</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class DataTypes {
    public static void main(String[] args) {
        // Integer types
        byte byteVar = 127;        // 8-bit, -128 to 127
        short shortVar = 32767;    // 16-bit, -32,768 to 32,767
        int intVar = 2147483647;   // 32-bit, -2^31 to 2^31-1
        long longVar = 9223372036854775807L; // 64-bit, -2^63 to 2^63-1
        
        // Floating-point types
        float floatVar = 3.14f;    // 32-bit, 6-7 decimal digits
        double doubleVar = 3.14159265359; // 64-bit, 15-16 decimal digits
        
        // Character type
        char charVar = 'A';        // 16-bit Unicode character
        
        // Boolean type
        boolean boolVar = true;    // true or false
        
        // Print all variables
        System.out.println("byte: " + byteVar);
        System.out.println("short: " + shortVar);
        System.out.println("int: " + intVar);
        System.out.println("long: " + longVar);
        System.out.println("float: " + floatVar);
        System.out.println("double: " + doubleVar);
        System.out.println("char: " + charVar);
        System.out.println("boolean: " + boolVar);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Reference Data Types</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class ReferenceTypes {
    public static void main(String[] args) {
        // String is a reference type
        String greeting = "Hello, Java!";
        
        // Arrays are reference types
        int[] numbers = {1, 2, 3, 4, 5};
        String[] names = {"Alice", "Bob", "Charlie"};
        
        // Custom class objects
        Person person = new Person("John", 25);
        
        // Print reference types
        System.out.println(greeting);
        System.out.println("First number: " + numbers[0]);
        System.out.println("First name: " + names[0]);
        System.out.println("Person: " + person.getName() + ", " + person.getAge());
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() { return name; }
    public int getAge() { return age; }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Type Conversion</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class TypeConversion {
    public static void main(String[] args) {
        // Implicit (widening) conversion
        int intValue = 100;
        long longValue = intValue;  // int to long
        double doubleValue = intValue; // int to double
        
        // Explicit (narrowing) conversion
        double pi = 3.14159;
        int intPi = (int) pi;  // double to int (loses decimal part)
        
        // String to primitive
        String strNumber = "123";
        int parsedInt = Integer.parseInt(strNumber);
        double parsedDouble = Double.parseDouble(strNumber);
        
        // Primitive to String
        int number = 42;
        String strFromInt = Integer.toString(number);
        String strFromInt2 = String.valueOf(number);
        
        System.out.println("Widening: " + longValue + ", " + doubleValue);
        System.out.println("Narrowing: " + intPi);
        System.out.println("Parsed: " + parsedInt + ", " + parsedDouble);
        System.out.println("To String: " + strFromInt + ", " + strFromInt2);
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Operators Section -->
            <section id="operators" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-calculator mr-2"></i>Operators
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java provides various operators to perform different types of operations on variables and values.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Arithmetic Operators</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class ArithmeticOperators {
    public static void main(String[] args) {
        int a = 10, b = 3;
        
        // Addition
        int sum = a + b;  // 13
        
        // Subtraction
        int diff = a - b; // 7
        
        // Multiplication
        int product = a * b; // 30
        
        // Division
        int quotient = a / b; // 3 (integer division)
        double preciseQuotient = (double) a / b; // 3.333...
        
        // Modulus (remainder)
        int remainder = a % b; // 1
        
        // Increment/Decrement
        int x = 5;
        x++;  // x = 6
        x--;  // x = 5
        ++x;  // x = 6 (pre-increment)
        --x;  // x = 5 (pre-decrement)
        
        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + diff);
        System.out.println("Product: " + product);
        System.out.println("Quotient: " + quotient);
        System.out.println("Precise Quotient: " + preciseQuotient);
        System.out.println("Remainder: " + remainder);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Comparison Operators</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class ComparisonOperators {
    public static void main(String[] args) {
        int a = 10, b = 20;
        
        // Equal to
        boolean isEqual = (a == b);  // false
        
        // Not equal to
        boolean isNotEqual = (a != b); // true
        
        // Greater than
        boolean isGreater = (a > b); // false
        
        // Less than
        boolean isLess = (a < b); // true
        
        // Greater than or equal to
        boolean isGreaterOrEqual = (a >= b); // false
        
        // Less than or equal to
        boolean isLessOrEqual = (a <= b); // true
        
        System.out.println("Equal: " + isEqual);
        System.out.println("Not Equal: " + isNotEqual);
        System.out.println("Greater: " + isGreater);
        System.out.println("Less: " + isLess);
        System.out.println("Greater or Equal: " + isGreaterOrEqual);
        System.out.println("Less or Equal: " + isLessOrEqual);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Logical Operators</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class LogicalOperators {
    public static void main(String[] args) {
        boolean x = true, y = false;
        
        // Logical AND
        boolean andResult = (x && y); // false
        
        // Logical OR
        boolean orResult = (x || y); // true
        
        // Logical NOT
        boolean notX = !x; // false
        boolean notY = !y; // true
        
        // Short-circuit evaluation
        int a = 5, b = 0;
        // boolean result = (b != 0) && (a / b > 2); // No division by zero error
        
        System.out.println("AND: " + andResult);
        System.out.println("OR: " + orResult);
        System.out.println("NOT X: " + notX);
        System.out.println("NOT Y: " + notY);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Assignment Operators</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class AssignmentOperators {
    public static void main(String[] args) {
        int x = 10;
        
        // Simple assignment
        int y = x; // y = 10
        
        // Add and assign
        x += 5; // x = 15
        
        // Subtract and assign
        x -= 3; // x = 12
        
        // Multiply and assign
        x *= 2; // x = 24
        
        // Divide and assign
        x /= 4; // x = 6
        
        // Modulus and assign
        x %= 4; // x = 2
        
        System.out.println("x: " + x);
        System.out.println("y: " + y);
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Input Section -->
            <section id="input" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-keyboard mr-2"></i>User Input
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java provides various ways to get input from users, with the Scanner class being the most common approach.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Scanner Class</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.Scanner;

public class UserInput {
    public static void main(String[] args) {
        // Create Scanner object
        Scanner scanner = new Scanner(System.in);
        
        // Read string input
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        
        // Read integer input
        System.out.print("Enter your age: ");
        int age = scanner.nextInt();
        
        // Read double input
        System.out.print("Enter your height (in meters): ");
        double height = scanner.nextDouble();
        
        // Read boolean input
        System.out.print("Are you a student? (true/false): ");
        boolean isStudent = scanner.nextBoolean();
        
        // Display the input
        System.out.println("\n--- Your Information ---");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Height: " + height + "m");
        System.out.println("Student: " + isStudent);
        
        // Close the scanner
        scanner.close();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Reading Multiple Values</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.Scanner;

public class MultipleInputs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Read multiple numbers
        System.out.print("Enter 5 numbers separated by space: ");
        int[] numbers = new int[5];
        
        for (int i = 0; i < 5; i++) {
            numbers[i] = scanner.nextInt();
        }
        
        // Calculate sum
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + (double) sum / 5);
        
        scanner.close();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Input Validation</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.Scanner;
import java.util.InputMismatchException;

public class InputValidation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Validate integer input
        int number = 0;
        boolean validInput = false;
        
        while (!validInput) {
            try {
                System.out.print("Enter a number between 1 and 100: ");
                number = scanner.nextInt();
                
                if (number >= 1 && number <= 100) {
                    validInput = true;
                } else {
                    System.out.println("Number must be between 1 and 100!");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.next(); // Clear the invalid input
            }
        }
        
        System.out.println("You entered: " + number);
        scanner.close();
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Comments Section -->
            <section id="comments" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-comment mr-2"></i>Comments
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Comments are used to explain the code and make it more readable. Java supports three types of comments.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Types of Comments</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">/**
 * This is a Javadoc comment.
 * It documents the class and can be used to generate documentation.
 * @author Your Name
 * @version 1.0
 */
public class CommentsExample {
    
    // This is a single-line comment
    // It explains the following line of code
    
    private int value; // Instance variable to store a value
    
    /**
     * This is a multi-line Javadoc comment.
     * It documents the method.
     * @param x The first parameter
     * @param y The second parameter
     * @return The sum of x and y
     */
    public int add(int x, int y) {
        /* This is a multi-line comment
           that spans multiple lines
           and explains the calculation */
        int result = x + y;
        return result;
    }
    
    /*
     * Another multi-line comment style
     * used for longer explanations
     */
    public void displayValue() {
        System.out.println("Value: " + value); // Print the value
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Best Practices for Comments</h3>
                    <ul class="list-disc pl-6 space-y-2 text-gray-700">
                        <li>Write comments that explain why, not what</li>
                        <li>Keep comments up-to-date with the code</li>
                        <li>Use Javadoc for public classes and methods</li>
                        <li>Avoid obvious comments (e.g., // increment i)</li>
                        <li>Write comments in clear, simple language</li>
                    </ul>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Javadoc Tags</h3>
                    <div class="bg-gray-50 p-4 rounded-lg mt-4">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="border-b">
                                    <th class="text-left py-2">Tag</th>
                                    <th class="text-left py-2">Description</th>
                                    <th class="text-left py-2">Example</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b">
                                    <td class="py-2">@author</td>
                                    <td class="py-2">Specifies the author</td>
                                    <td class="py-2">@author John Doe</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">@param</td>
                                    <td class="py-2">Describes a method parameter</td>
                                    <td class="py-2">@param name The user's name</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">@return</td>
                                    <td class="py-2">Describes the return value</td>
                                    <td class="py-2">@return The calculated result</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">@throws</td>
                                    <td class="py-2">Describes an exception</td>
                                    <td class="py-2">@throws IOException If file not found</td>
                                </tr>
                                <tr class="border-b">
                                    <td class="py-2">@see</td>
                                    <td class="py-2">References another class or method</td>
                                    <td class="py-2">@see String#length()</td>
                                </tr>
                                <tr>
                                    <td class="py-2">@since</td>
                                    <td class="py-2">Specifies when introduced</td>
                                    <td class="py-2">@since 1.5</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <!-- First Program Section -->
            <section id="first" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-play mr-2"></i>First Program
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Let's write, compile, and run your first Java program - the classic "Hello, World!"</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Writing the Program</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        System.out.println("Welcome to Java Programming!");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Understanding the Code</h3>
                    <div class="bg-blue-50 p-4 rounded-lg mt-4">
                        <ul class="space-y-2 text-gray-700">
                            <li><strong>public class HelloWorld:</strong> Defines a class named HelloWorld</li>
                            <li><strong>public static void main(String[] args):</strong> The main method where program execution begins</li>
                            <li><strong>System.out.println():</strong> Prints the given text to the console</li>
                        </ul>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Compiling and Running</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-bash"># Save the file as HelloWorld.java

# Compile the program
javac HelloWorld.java

# Run the program
java HelloWorld

# Output:
# Hello, World!
# Welcome to Java Programming!</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Interactive Example</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.Scanner;

public class GreetingProgram {
    public static void main(String[] args) {
        // Create Scanner object for input
        Scanner scanner = new Scanner(System.in);
        
        // Ask for user's name
        System.out.print("Please enter your name: ");
        String name = scanner.nextLine();
        
        // Greet the user
        System.out.println("Hello, " + name + "!");
        System.out.println("This is your first interactive Java program!");
        
        // Close the scanner
        scanner.close();
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Classes Section -->
            <section id="classes" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-cube mr-2"></i>Classes & Objects
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Classes are blueprints for creating objects. Objects are instances of classes that contain data and behavior.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Defining a Class</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class Car {
    // Instance variables (attributes)
    private String brand;
    private String model;
    private int year;
    private double price;
    
    // Constructor
    public Car(String brand, String model, int year, double price) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.price = price;
    }
    
    // Getter methods
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public int getYear() { return year; }
    public double getPrice() { return price; }
    
    // Setter methods
    public void setPrice(double price) { 
        if (price > 0) {
            this.price = price; 
        }
    }
    
    // Instance method (behavior)
    public void displayInfo() {
        System.out.println(year + " " + brand + " " + model);
        System.out.println("Price: $" + price);
    }
    
    // Another method
    public void startEngine() {
        System.out.println("The " + brand + " " + model + " is starting...");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Creating and Using Objects</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class CarDemo {
    public static void main(String[] args) {
        // Create objects (instances) of Car class
        Car car1 = new Car("Toyota", "Camry", 2023, 25000.0);
        Car car2 = new Car("Honda", "Civic", 2023, 22000.0);
        Car car3 = new Car("Tesla", "Model 3", 2023, 45000.0);
        
        // Use object methods
        car1.displayInfo();
        car1.startEngine();
        
        System.out.println(); // Empty line
        
        car2.displayInfo();
        car2.startEngine();
        
        // Modify object state
        car3.setPrice(43000.0);
        car3.displayInfo();
        
        // Access object properties through getters
        System.out.println("\nCar 1 Brand: " + car1.getBrand());
        System.out.println("Car 2 Year: " + car2.getYear());
        System.out.println("Car 3 Price: $" + car3.getPrice());
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Class vs Object</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Class</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Blueprint or template</li>
                                <li>• Defines properties and methods</li>
                                <li>• Created once</li>
                                <li>• No memory allocation</li>
                                <li>• Example: Car class</li>
                            </ul>
                        </div>
                        <div class="bg-white p-4 rounded-lg shadow">
                            <h4 class="font-semibold text-indigo-600 mb-2">Object</h4>
                            <ul class="text-sm text-gray-600 space-y-1">
                                <li>• Instance of a class</li>
                                <li>• Has actual data values</li>
                                <li>• Created multiple times</li>
                                <li>• Memory allocated</li>
                                <li>• Example: My Toyota Camry</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Methods Section -->
            <section id="methods" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-function mr-2"></i>Methods
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Methods are blocks of code that perform specific tasks. They promote code reusability and organization.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Method Types</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class MethodTypes {
    
    // 1. Static method (belongs to class)
    public static void staticMethod() {
        System.out.println("This is a static method");
    }
    
    // 2. Instance method (belongs to object)
    public void instanceMethod() {
        System.out.println("This is an instance method");
    }
    
    // 3. Method with parameters
    public void greet(String name) {
        System.out.println("Hello, " + name + "!");
    }
    
    // 4. Method with return value
    public int add(int a, int b) {
        return a + b;
    }
    
    // 5. Method with multiple parameters
    public double calculateInterest(double principal, double rate, int time) {
        return (principal * rate * time) / 100;
    }
    
    // 6. Method with variable arguments (varargs)
    public int sum(int... numbers) {
        int total = 0;
        for (int num : numbers) {
            total += num;
        }
        return total;
    }
    
    // 7. Recursive method
    public int factorial(int n) {
        if (n <= 1) {
            return 1;
        }
        return n * factorial(n - 1);
    }
    
    public static void main(String[] args) {
        MethodTypes obj = new MethodTypes();
        
        // Calling static method
        staticMethod();
        
        // Calling instance method
        obj.instanceMethod();
        
        // Method with parameters
        obj.greet("Alice");
        
        // Method with return value
        int result = obj.add(5, 3);
        System.out.println("Sum: " + result);
        
        // Method with multiple parameters
        double interest = obj.calculateInterest(1000, 5, 2);
        System.out.println("Interest: $" + interest);
        
        // Varargs method
        int sum = obj.sum(1, 2, 3, 4, 5);
        System.out.println("Sum of numbers: " + sum);
        
        // Recursive method
        int fact = obj.factorial(5);
        System.out.println("Factorial of 5: " + fact);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Method Overloading</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class MethodOverloading {
    
    // Overloaded methods - same name, different parameters
    
    public void display() {
        System.out.println("No parameters");
    }
    
    public void display(int num) {
        System.out.println("Integer: " + num);
    }
    
    public void display(String text) {
        System.out.println("String: " + text);
    }
    
    public void display(int num, String text) {
        System.out.println("Integer: " + num + ", String: " + text);
    }
    
    public void display(String text, int num) {
        System.out.println("String: " + text + ", Integer: " + num);
    }
    
    public static void main(String[] args) {
        MethodOverloading obj = new MethodOverloading();
        
        obj.display();                    // No parameters
        obj.display(42);                  // Integer parameter
        obj.display("Hello");             // String parameter
        obj.display(100, "World");        // Two parameters
        obj.display("Java", 2023);        // Two parameters (different order)
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Constructors Section -->
            <section id="constructors" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-tools mr-2"></i>Constructors
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Constructors are special methods used to initialize objects. They have the same name as the class and no return type.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Types of Constructors</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class Student {
    private String name;
    private int age;
    private String major;
    private double gpa;
    
    // 1. Default constructor (no-argument)
    public Student() {
        this.name = "Unknown";
        this.age = 0;
        this.major = "Undeclared";
        this.gpa = 0.0;
        System.out.println("Default constructor called");
    }
    
    // 2. Parameterized constructor
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
        this.major = "Undeclared";
        this.gpa = 0.0;
        System.out.println("Parameterized constructor (2 params) called");
    }
    
    // 3. Full parameterized constructor
    public Student(String name, int age, String major, double gpa) {
        this.name = name;
        this.age = age;
        this.major = major;
        this.gpa = gpa;
        System.out.println("Full parameterized constructor called");
    }
    
    // 4. Copy constructor
    public Student(Student other) {
        this.name = other.name;
        this.age = other.age;
        this.major = other.major;
        this.gpa = other.gpa;
        System.out.println("Copy constructor called");
    }
    
    // Getter methods
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getMajor() { return major; }
    public double getGpa() { return gpa; }
    
    // Display method
    public void displayInfo() {
        System.out.println("Student Information:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Major: " + major);
        System.out.println("GPA: " + gpa);
        System.out.println();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Constructors</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class ConstructorDemo {
    public static void main(String[] args) {
        // Using default constructor
        Student student1 = new Student();
        student1.displayInfo();
        
        // Using parameterized constructor (2 params)
        Student student2 = new Student("Alice", 20);
        student2.displayInfo();
        
        // Using full parameterized constructor
        Student student3 = new Student("Bob", 21, "Computer Science", 3.8);
        student3.displayInfo();
        
        // Using copy constructor
        Student student4 = new Student(student3);
        student4.displayInfo();
        
        // Constructor chaining with 'this'
        System.out.println("--- Constructor Chaining ---");
        Employee emp1 = new Employee();
        Employee emp2 = new Employee("John Doe");
        Employee emp3 = new Employee("Jane Smith", 50000);
    }
}

class Employee {
    private String name;
    private double salary;
    
    // Default constructor
    public Employee() {
        this("Unknown Employee"); // Calls another constructor
        System.out.println("Employee default constructor");
    }
    
    // Constructor with name
    public Employee(String name) {
        this(name, 30000.0); // Calls the full constructor
        System.out.println("Employee constructor with name");
    }
    
    // Full constructor
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
        System.out.println("Employee full constructor");
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Inheritance Section -->
            <section id="inheritance" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-sitemap mr-2"></i>Inheritance
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Inheritance allows a class to inherit properties and methods from another class, promoting code reuse.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic Inheritance</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Parent class (Superclass)
public class Animal {
    protected String name;
    protected int age;
    
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public void eat() {
        System.out.println(name + " is eating");
    }
    
    public void sleep() {
        System.out.println(name + " is sleeping");
    }
    
    public void makeSound() {
        System.out.println(name + " makes a sound");
    }
    
    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

// Child class (Subclass)
public class Dog extends Animal {
    private String breed;
    
    public Dog(String name, int age, String breed) {
        super(name, age); // Call parent constructor
        this.breed = breed;
    }
    
    // Override parent method
    @Override
    public void makeSound() {
        System.out.println(name + " barks: Woof! Woof!");
    }
    
    // New method specific to Dog
    public void wagTail() {
        System.out.println(name + " is wagging its tail");
    }
    
    // Override displayInfo to include breed
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call parent method
        System.out.println("Breed: " + breed);
    }
}

// Another child class
public class Cat extends Animal {
    private boolean isIndoor;
    
    public Cat(String name, int age, boolean isIndoor) {
        super(name, age);
        this.isIndoor = isIndoor;
    }
    
    @Override
    public void makeSound() {
        System.out.println(name + " meows: Meow!");
    }
    
    public void climb() {
        System.out.println(name + " is climbing");
    }
    
    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Indoor cat: " + isIndoor);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Inheritance</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class InheritanceDemo {
    public static void main(String[] args) {
        // Create Dog object
        Dog dog = new Dog("Buddy", 3, "Golden Retriever");
        
        // Use inherited methods
        dog.eat();
        dog.sleep();
        dog.makeSound(); // Overridden method
        dog.wagTail();   // Dog-specific method
        dog.displayInfo();
        
        System.out.println();
        
        // Create Cat object
        Cat cat = new Cat("Whiskers", 2, true);
        
        // Use inherited methods
        cat.eat();
        cat.sleep();
        cat.makeSound(); // Overridden method
        cat.climb();     // Cat-specific method
        cat.displayInfo();
        
        System.out.println();
        
        // Polymorphism example
        Animal myDog = new Dog("Max", 4, "Labrador");
        Animal myCat = new Cat("Luna", 1, false);
        
        myDog.makeSound(); // Calls Dog's version
        myCat.makeSound(); // Calls Cat's version
        
        // Cannot access subclass-specific methods through parent reference
        // myDog.wagTail(); // This would cause compile error
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Polymorphism Section -->
            <section id="polymorphism" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-shapes mr-2"></i>Polymorphism
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Polymorphism allows objects of different classes to be treated as objects of a common superclass. It enables method overriding and overloading.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Runtime Polymorphism (Method Overriding)</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Abstract class demonstrating polymorphism
abstract class Shape {
    protected String color;
    
    public Shape(String color) {
        this.color = color;
    }
    
    // Abstract method to be overridden by subclasses
    public abstract double getArea();
    
    // Concrete method
    public void displayColor() {
        System.out.println("Shape color: " + color);
    }
    
    // Method that can be overridden
    public void draw() {
        System.out.println("Drawing a shape");
    }
}

class Circle extends Shape {
    private double radius;
    
    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }
    
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
    
    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " circle with radius " + radius);
    }
}

class Rectangle extends Shape {
    private double width;
    private double height;
    
    public Rectangle(String color, double width, double height) {
        super(color);
        this.width = width;
        this.height = height;
    }
    
    @Override
    public double getArea() {
        return width * height;
    }
    
    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " rectangle " + width + "x" + height);
    }
}

class Triangle extends Shape {
    private double base;
    private double height;
    
    public Triangle(String color, double base, double height) {
        super(color);
        this.base = base;
        this.height = height;
    }
    
    @Override
    public double getArea() {
        return 0.5 * base * height;
    }
    
    @Override
    public void draw() {
        System.out.println("Drawing a " + color + " triangle");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Polymorphism in Action</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class PolymorphismDemo {
    public static void main(String[] args) {
        // Create different shape objects
        Shape circle = new Circle("Red", 5.0);
        Shape rectangle = new Rectangle("Blue", 4.0, 6.0);
        Shape triangle = new Triangle("Green", 3.0, 4.0);
        
        // Array of shapes demonstrating polymorphism
        Shape[] shapes = {circle, rectangle, triangle};
        
        // Process all shapes polymorphically
        for (Shape shape : shapes) {
            shape.displayColor();
            shape.draw();
            System.out.println("Area: " + shape.getArea());
            System.out.println();
        }
        
        // Method demonstrating polymorphism
        drawShape(circle);
        drawShape(rectangle);
        drawShape(triangle);
    }
    
    // Method that accepts any Shape object
    public static void drawShape(Shape shape) {
        System.out.println("=== Drawing Shape ===");
        shape.draw();
        System.out.println("Area: " + shape.getArea());
        System.out.println("=====================");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Compile-time Polymorphism (Method Overloading)</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class Calculator {
    
    // Overloaded add methods
    public int add(int a, int b) {
        System.out.println("Adding two integers");
        return a + b;
    }
    
    public double add(double a, double b) {
        System.out.println("Adding two doubles");
        return a + b;
    }
    
    public int add(int a, int b, int c) {
        System.out.println("Adding three integers");
        return a + b + c;
    }
    
    public String add(String a, String b) {
        System.out.println("Concatenating two strings");
        return a + b;
    }
    
    // Overloaded multiply methods
    public int multiply(int a, int b) {
        return a * b;
    }
    
    public double multiply(double a, double b) {
        return a * b;
    }
    
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        
        // Method overloading in action
        System.out.println("5 + 3 = " + calc.add(5, 3));
        System.out.println("5.5 + 3.2 = " + calc.add(5.5, 3.2));
        System.out.println("1 + 2 + 3 = " + calc.add(1, 2, 3));
        System.out.println("Hello + World = " + calc.add("Hello", " World"));
        
        System.out.println("4 * 5 = " + calc.multiply(4, 5));
        System.out.println("4.5 * 5.5 = " + calc.multiply(4.5, 5.5));
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Encapsulation Section -->
            <section id="encapsulation" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-lock mr-2"></i>Encapsulation
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Encapsulation is the practice of bundling data (variables) and methods that operate on the data into a single unit (class).</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Encapsulated Class Example</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class BankAccount {
    // Private variables - encapsulated data
    private String accountNumber;
    private String accountHolderName;
    private double balance;
    private String pin;
    
    // Constructor
    public BankAccount(String accountNumber, String accountHolderName, String pin) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
        this.pin = pin;
    }
    
    // Public getters - controlled access to private data
    public String getAccountNumber() {
        return accountNumber;
    }
    
    public String getAccountHolderName() {
        return accountHolderName;
    }
    
    public double getBalance() {
        return balance;
    }
    
    // Public methods - controlled operations on data
    public boolean deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: $" + amount);
            System.out.println("New balance: $" + balance);
            return true;
        } else {
            System.out.println("Invalid deposit amount");
            return false;
        }
    }
    
    public boolean withdraw(double amount, String enteredPin) {
        // Validate PIN
        if (!this.pin.equals(enteredPin)) {
            System.out.println("Invalid PIN");
            return false;
        }
        
        // Check amount
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount");
            return false;
        }
        
        if (amount > balance) {
            System.out.println("Insufficient funds");
            return false;
        }
        
        // Process withdrawal
        balance -= amount;
        System.out.println("Withdrew: $" + amount);
        System.out.println("New balance: $" + balance);
        return true;
    }
    
    public boolean changePin(String oldPin, String newPin) {
        if (this.pin.equals(oldPin) && newPin.length() == 4) {
            this.pin = newPin;
            System.out.println("PIN changed successfully");
            return true;
        } else {
            System.out.println("Invalid PIN or new PIN must be 4 digits");
            return false;
        }
    }
    
    // Method to display account info (without showing PIN)
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolderName);
        System.out.println("Balance: $" + balance);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Encapsulated Class</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class EncapsulationDemo {
    public static void main(String[] args) {
        // Create a bank account object
        BankAccount account = new BankAccount("123456789", "John Doe", "1234");
        
        // Display account info
        account.displayAccountInfo();
        System.out.println();
        
        // Deposit money
        account.deposit(1000.0);
        account.deposit(500.0);
        System.out.println();
        
        // Withdraw money
        account.withdraw(200.0, "1234"); // Correct PIN
        account.withdraw(100.0, "0000"); // Wrong PIN
        System.out.println();
        
        // Try to access private variables directly (will cause compile error)
        // account.balance = 10000; // ERROR: balance has private access
        // account.pin = "5678";    // ERROR: pin has private access
        
        // Change PIN
        account.changePin("1234", "5678");
        account.changePin("1234", "0000"); // Wrong old PIN
        System.out.println();
        
        // Final account info
        account.displayAccountInfo();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Benefits of Encapsulation</h3>
                    <div class="bg-green-50 p-4 rounded-lg mt-4">
                        <ul class="list-disc pl-6 space-y-2 text-gray-700">
                            <li><strong>Data Hiding:</strong> Internal representation is hidden from the outside</li>
                            <li><strong>Control:</strong> Full control over data through getter/setter methods</li>
                            <li><strong>Flexibility:</strong> Can change internal implementation without affecting code that uses the class</li>
                            <li><strong>Security:</strong> Prevents unauthorized access and modification of data</li>
                            <li><strong>Maintainability:</strong> Easier to debug and maintain code</li>
                        </ul>
                    </div>
                </div>
            </section>

            <!-- Static Section -->
            <section id="static" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-bolt mr-2"></i>Static Members
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Static members belong to the class rather than to any specific instance. They are shared among all objects of the class.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Static Variables and Methods</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class Student {
    private String name;
    private int rollNumber;
    
    // Static variable - shared by all instances
    private static String schoolName = "ABC High School";
    private static int totalStudents = 0;
    private static final int MAX_STUDENTS = 100;
    
    // Static block - executed when class is loaded
    static {
        System.out.println("Student class loaded");
        System.out.println("School: " + schoolName);
        System.out.println("Maximum capacity: " + MAX_STUDENTS);
    }
    
    // Constructor
    public Student(String name, int rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
        totalStudents++; // Increment static counter
        System.out.println("Student " + name + " admitted");
    }
    
    // Instance method
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("School: " + schoolName);
    }
    
    // Static method - can be called without creating object
    public static String getSchoolName() {
        return schoolName;
    }
    
    public static int getTotalStudents() {
        return totalStudents;
    }
    
    public static boolean isAdmissionOpen() {
        return totalStudents < MAX_STUDENTS;
    }
    
    // Static method to change school name
    public static void changeSchoolName(String newName) {
        schoolName = newName;
        System.out.println("School name changed to: " + newName);
    }
    
    // Instance method using static variable
    public boolean canGraduate() {
        return totalStudents >= 50; // Example condition
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Static Members</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class StaticDemo {
    public static void main(String[] args) {
        // Access static methods without creating object
        System.out.println("School: " + Student.getSchoolName());
        System.out.println("Total Students: " + Student.getTotalStudents());
        System.out.println("Admission Open: " + Student.isAdmissionOpen());
        
        System.out.println("\n--- Admitting Students ---");
        
        // Create student objects
        Student s1 = new Student("Alice", 101);
        Student s2 = new Student("Bob", 102);
        Student s3 = new Student("Charlie", 103);
        
        // Display student info
        s1.displayInfo();
        System.out.println();
        
        // Static variable is shared
        System.out.println("Total Students after admission: " + Student.getTotalStudents());
        System.out.println("Admission Open: " + Student.isAdmissionOpen());
        
        // Change static variable
        Student.changeSchoolName("XYZ Academy");
        
        // All students see the updated school name
        s2.displayInfo();
        System.out.println();
        
        // Static import example
        System.out.println("PI value: " + Math.PI);
        System.out.println("Max of 10 and 20: " + Math.max(10, 20));
    }
}

// Another class with static members
class MathUtils {
    // Static constants
    public static final double PI = 3.14159265359;
    public static final double E = 2.71828182846;
    
    // Static methods
    public static int add(int a, int b) {
        return a + b;
    }
    
    public static int multiply(int a, int b) {
        return a * b;
    }
    
    // Static method for factorial
    public static long factorial(int n) {
        if (n < 0) return -1;
        if (n == 0 || n == 1) return 1;
        
        long result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Inner Classes Section -->
            <section id="inner" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-layer-group mr-2"></i>Inner Classes
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java allows defining a class within another class. These are called inner classes and provide better encapsulation.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Types of Inner Classes</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class OuterClass {
    private String outerField = "Outer field";
    private static String staticOuterField = "Static outer field";
    
    // 1. Member Inner Class (non-static)
    public class InnerClass {
        private String innerField = "Inner field";
        
        public void display() {
            // Can access both outer and inner members
            System.out.println(outerField); // Accessing outer private field
            System.out.println(innerField);
            System.out.println(staticOuterField);
            
            // Accessing outer class's this
            System.out.println("Outer this: " + OuterClass.this);
        }
    }
    
    // 2. Static Nested Class
    public static class StaticNestedClass {
        private String nestedField = "Nested field";
        
        public void display() {
            // Can only access static members of outer class
            System.out.println(staticOuterField);
            System.out.println(nestedField);
            
            // Cannot access non-static outer members
            // System.out.println(outerField); // ERROR!
        }
    }
    
    // 3. Local Inner Class (inside a method)
    public void methodWithLocalClass() {
        String localVar = "Local variable";
        
        // Local inner class
        class LocalClass {
            public void display() {
                System.out.println(outerField);
                System.out.println(localVar);
            }
        }
        
        LocalClass local = new LocalClass();
        local.display();
    }
    
    // 4. Anonymous Inner Class
    public void createAnonymousClass() {
        // Creating anonymous class that implements Runnable
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("Running anonymous class");
                System.out.println(outerField);
            }
        };
        
        // Using the anonymous class
        Thread thread = new Thread(runnable);
        thread.start();
    }
    
    // Method to create inner class instance
    public InnerClass createInner() {
        return new InnerClass();
    }
    
    // Static method to create static nested class instance
    public static StaticNestedClass createStaticNested() {
        return new StaticNestedClass();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Inner Classes</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class InnerClassDemo {
    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        
        // 1. Using Member Inner Class
        System.out.println("=== Member Inner Class ===");
        OuterClass.InnerClass inner = outer.new InnerClass();
        inner.display();
        
        // Alternative way
        OuterClass.InnerClass inner2 = outer.createInner();
        inner2.display();
        
        System.out.println();
        
        // 2. Using Static Nested Class
        System.out.println("=== Static Nested Class ===");
        OuterClass.StaticNestedClass nested = new OuterClass.StaticNestedClass();
        nested.display();
        
        // Alternative way
        OuterClass.StaticNestedClass nested2 = OuterClass.createStaticNested();
        nested2.display();
        
        System.out.println();
        
        // 3. Using Local Inner Class (called from method)
        System.out.println("=== Local Inner Class ===");
        outer.methodWithLocalClass();
        
        System.out.println();
        
        // 4. Using Anonymous Inner Class
        System.out.println("=== Anonymous Inner Class ===");
        outer.createAnonymousClass();
        
        // Another anonymous class example
        System.out.println("\n--- Another Anonymous Class ---");
        
        // Anonymous class extending a class
        Thread thread = new Thread() {
            @Override
            public void run() {
                System.out.println("Custom thread running");
            }
        };
        thread.start();
    }
}

// Example with practical inner class usage
class LinkedList {
    private Node head;
    private int size;
    
    // Private inner class - only accessible within LinkedList
    private class Node {
        Object data;
        Node next;
        
        Node(Object data) {
            this.data = data;
            this.next = null;
        }
    }
    
    public void add(Object data) {
        Node newNode = new Node(data);
        
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }
    
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
    
    public int getSize() {
        return size;
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Collections Section -->
            <section id="collections" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-box mr-2"></i>Collections Framework
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">The Java Collections Framework provides a set of interfaces and classes for storing and manipulating groups of data.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">List Interface</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;

public class ListExamples {
    public static void main(String[] args) {
        // ArrayList - dynamic array
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Cherry");
        arrayList.add("Date");
        
        System.out.println("ArrayList: " + arrayList);
        
        // Access elements
        System.out.println("Element at index 2: " + arrayList.get(2));
        
        // Modify element
        arrayList.set(1, "Blueberry");
        System.out.println("After modification: " + arrayList);
        
        // Remove element
        arrayList.remove(3);
        System.out.println("After removal: " + arrayList);
        
        // Check if element exists
        System.out.println("Contains 'Apple': " + arrayList.contains("Apple"));
        
        // Get size
        System.out.println("Size: " + arrayList.size());
        
        System.out.println("\n--- LinkedList ---");
        
        // LinkedList - doubly-linked list
        List<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        
        // LinkedList specific operations
        ((LinkedList<Integer>) linkedList).addFirst(5);
        ((LinkedList<Integer>) linkedList).addLast(35);
        
        System.out.println("LinkedList: " + linkedList);
        
        // Remove first and last
        ((LinkedList<Integer>) linkedList).removeFirst();
        ((LinkedList<Integer>) linkedList).removeLast();
        
        System.out.println("After removal: " + linkedList);
        
        System.out.println("\n--- Vector ---");
        
        // Vector - synchronized dynamic array
        Vector<String> vector = new Vector<>();
        vector.add("Red");
        vector.add("Green");
        vector.add("Blue");
        
        System.out.println("Vector: " + vector);
        System.out.println("Vector capacity: " + vector.capacity());
        
        // Iterate through list
        System.out.println("\n--- Iteration ---");
        for (String fruit : arrayList) {
            System.out.println("Fruit: " + fruit);
        }
        
        // Using Iterator
        System.out.println("\nUsing Iterator:");
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            System.out.println("Next: " + iterator.next());
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Set Interface</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;

public class SetExamples {
    public static void main(String[] args) {
        // HashSet - unordered, unique elements
        Set<String> hashSet = new HashSet<>();
        hashSet.add("Java");
        hashSet.add("Python");
        hashSet.add("C++");
        hashSet.add("Java"); // Duplicate, won't be added
        
        System.out.println("HashSet: " + hashSet);
        System.out.println("Size: " + hashSet.size());
        
        // Check element existence
        System.out.println("Contains 'Python': " + hashSet.contains("Python"));
        
        // Remove element
        hashSet.remove("C++");
        System.out.println("After removal: " + hashSet);
        
        System.out.println("\n--- TreeSet ---");
        
        // TreeSet - sorted, unique elements
        Set<Integer> treeSet = new TreeSet<>();
        treeSet.add(30);
        treeSet.add(10);
        treeSet.add(20);
        treeSet.add(40);
        treeSet.add(10); // Duplicate, won't be added
        
        System.out.println("TreeSet: " + treeSet);
        
        // TreeSet specific operations
        System.out.println("First element: " + ((TreeSet<Integer>) treeSet).first());
        System.out.println("Last element: " + ((TreeSet<Integer>) treeSet).last());
        System.out.println("Lower than 25: " + ((TreeSet<Integer>) treeSet).lower(25));
        System.out.println("Higher than 25: " + ((TreeSet<Integer>) treeSet).higher(25));
        
        System.out.println("\n--- LinkedHashSet ---");
        
        // LinkedHashSet - insertion order, unique elements
        Set<String> linkedHashSet = new LinkedHashSet<>();
        linkedHashSet.add("First");
        linkedHashSet.add("Second");
        linkedHashSet.add("Third");
        linkedHashSet.add("Second"); // Duplicate
        
        System.out.println("LinkedHashSet: " + linkedHashSet);
        
        // Set operations
        Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5));
        Set<Integer> set2 = new HashSet<>(Arrays.asList(4, 5, 6, 7, 8));
        
        // Union
        Set<Integer> union = new HashSet<>(set1);
        union.addAll(set2);
        System.out.println("\nUnion: " + union);
        
        // Intersection
        Set<Integer> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);
        System.out.println("Intersection: " + intersection);
        
        // Difference
        Set<Integer> difference = new HashSet<>(set1);
        difference.removeAll(set2);
        System.out.println("Difference (set1 - set2): " + difference);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Map Interface</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;

public class MapExamples {
    public static void main(String[] args) {
        // HashMap - key-value pairs, unordered
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Alice", 25);
        hashMap.put("Bob", 30);
        hashMap.put("Charlie", 35);
        hashMap.put("Alice", 26); // Updates Alice's age
        
        System.out.println("HashMap: " + hashMap);
        
        // Get value by key
        System.out.println("Alice's age: " + hashMap.get("Alice"));
        
        // Check if key exists
        System.out.println("Contains key 'Bob': " + hashMap.containsKey("Bob"));
        System.out.println("Contains value 30: " + hashMap.containsValue(30));
        
        // Get all keys
        System.out.println("Keys: " + hashMap.keySet());
        
        // Get all values
        System.out.println("Values: " + hashMap.values());
        
        // Remove entry
        hashMap.remove("Charlie");
        System.out.println("After removal: " + hashMap);
        
        System.out.println("\n--- TreeMap ---");
        
        // TreeMap - sorted by keys
        Map<String, String> treeMap = new TreeMap<>();
        treeMap.put("C", "Charlie");
        treeMap.put("A", "Alice");
        treeMap.put("B", "Bob");
        treeMap.put("D", "David");
        
        System.out.println("TreeMap: " + treeMap);
        
        // TreeMap specific operations
        System.out.println("First key: " + ((TreeMap<String, String>) treeMap).firstKey());
        System.out.println("Last key: " + ((TreeMap<String, String>) treeMap).lastKey());
        
        System.out.println("\n--- LinkedHashMap ---");
        
        // LinkedHashMap - insertion order
        Map<Integer, String> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put(3, "Three");
        linkedHashMap.put(1, "One");
        linkedHashMap.put(2, "Two");
        
        System.out.println("LinkedHashMap: " + linkedHashMap);
        
        // Iterate through map
        System.out.println("\n--- Map Iteration ---");
        
        // Using entrySet
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
        
        // Using keySet
        System.out.println("\nUsing keySet:");
        for (String key : hashMap.keySet()) {
            System.out.println(key + " => " + hashMap.get(key));
        }
        
        // Using forEach (Java 8+)
        System.out.println("\nUsing forEach:");
        hashMap.forEach((key, value) -> 
            System.out.println(key + " => " + value));
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Generics Section -->
            <section id="generics" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-code-branch mr-2"></i>Generics
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Generics enable types (classes and interfaces) to be parameters when defining classes, interfaces and methods.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Generic Classes</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Generic class with type parameter T
public class Box<T> {
    private T content;
    
    public Box() {
        this.content = null;
    }
    
    public Box(T content) {
        this.content = content;
    }
    
    public void setContent(T content) {
        this.content = content;
    }
    
    public T getContent() {
        return content;
    }
    
    public boolean isEmpty() {
        return content == null;
    }
    
    @Override
    public String toString() {
        return "Box containing: " + content;
    }
}

// Generic class with multiple type parameters
public class Pair<K, V> {
    private K key;
    private V value;
    
    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }
    
    public K getKey() { return key; }
    public V getValue() { return value; }
    
    public void setKey(K key) { this.key = key; }
    public void setValue(V value) { this.value = value; }
    
    @Override
    public String toString() {
        return "Pair[" + key + "=" + value + "]";
    }
}

// Generic class with bounded type parameter
public class NumberBox<T extends Number> {
    private T number;
    
    public NumberBox(T number) {
        this.number = number;
    }
    
    public void setNumber(T number) {
        this.number = number;
    }
    
    public T getNumber() {
        return number;
    }
    
    // Can use Number methods because T extends Number
    public double doubleValue() {
        return number.doubleValue();
    }
    
    public int intValue() {
        return number.intValue();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Using Generic Classes</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class GenericsDemo {
    public static void main(String[] args) {
        // Using Box with different types
        Box<String> stringBox = new Box<>("Hello Generics");
        Box<Integer> integerBox = new Box<>(42);
        Box<Double> doubleBox = new Box<>();
        
        doubleBox.setContent(3.14159);
        
        System.out.println(stringBox);
        System.out.println(integerBox);
        System.out.println(doubleBox);
        
        // Using Pair
        Pair<String, Integer> student = new Pair<>("Alice", 101);
        Pair<String, Double> product = new Pair<>("Laptop", 999.99);
        
        System.out.println(student);
        System.out.println(product);
        
        // Using NumberBox with bounded type
        NumberBox<Integer> intBox = new NumberBox<>(100);
        NumberBox<Double> doubleBox2 = new NumberBox<>(50.5);
        
        System.out.println("Integer box: " + intBox.getNumber());
        System.out.println("Double value: " + intBox.doubleValue());
        System.out.println("Double box: " + doubleBox2.getNumber());
        System.out.println("Int value: " + doubleBox2.intValue());
        
        // Type inference with diamond operator (Java 7+)
        Box<String> inferredBox = new Box<>("Type Inference");
        System.out.println(inferredBox);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Generic Methods</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class GenericMethods {
    
    // Generic method
    public static <T> void printArray(T[] array) {
        System.out.println("Array elements:");
        for (T element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
    
    // Generic method with multiple type parameters
    public static <K, V> void printPair(Pair<K, V> pair) {
        System.out.println("Key: " + pair.getKey() + ", Value: " + pair.getValue());
    }
    
    // Generic method with bounded type parameter
    public static <T extends Comparable<T>> T findMax(T[] array) {
        if (array == null || array.length == 0) {
            return null;
        }
        
        T max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i].compareTo(max) > 0) {
                max = array[i];
            }
        }
        return max;
    }
    
    // Generic method that returns generic type
    public static <T> T getFirst(List<T> list) {
        if (list == null || list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }
    
    // Wildcard example
    public static void printList(List<?> list) {
        System.out.println("List elements:");
        for (Object elem : list) {
            System.out.print(elem + " ");
        }
        System.out.println();
    }
    
    // Bounded wildcard
    public static double sumOfList(List<? extends Number> list) {
        double sum = 0.0;
        for (Number n : list) {
            sum += n.doubleValue();
        }
        return sum;
    }
    
    public static void main(String[] args) {
        // Using generic methods
        String[] stringArray = {"Apple", "Banana", "Cherry"};
        Integer[] intArray = {1, 2, 3, 4, 5};
        Double[] doubleArray = {1.1, 2.2, 3.3};
        
        printArray(stringArray);
        printArray(intArray);
        printArray(doubleArray);
        
        // Using findMax
        System.out.println("\nMax in string array: " + findMax(stringArray));
        System.out.println("Max in int array: " + findMax(intArray));
        System.out.println("Max in double array: " + findMax(doubleArray));
        
        // Using wildcard methods
        List<String> stringList = Arrays.asList("A", "B", "C");
        List<Integer> intList = Arrays.asList(10, 20, 30);
        
        printList(stringList);
        printList(intList);
        
        System.out.println("Sum of numbers: " + sumOfList(intList));
        System.out.println("Sum of doubles: " + sumOfList(Arrays.asList(1.5, 2.5, 3.5)));
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Threads Section -->
            <section id="threads" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-sync-alt mr-2"></i>Multithreading
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Multithreading allows concurrent execution of two or more parts of a program for maximum utilization of CPU.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Creating Threads</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Method 1: Extending Thread class
class MyThread extends Thread {
    private String name;
    
    public MyThread(String name) {
        this.name = name;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(name + " - Count: " + i);
            try {
                Thread.sleep(500); // Pause for 500ms
            } catch (InterruptedException e) {
                System.out.println(name + " interrupted");
            }
        }
        System.out.println(name + " finished");
    }
}

// Method 2: Implementing Runnable interface
class MyRunnable implements Runnable {
    private String name;
    
    public MyRunnable(String name) {
        this.name = name;
    }
    
    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(name + " - Count: " + i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(name + " interrupted");
            }
        }
        System.out.println(name + " finished");
    }
}

// Method 3: Using Lambda expression (Java 8+)
class LambdaThread {
    public static void createThreadWithLambda() {
        Thread thread = new Thread(() -> {
            for (int i = 1; i <= 5; i++) {
                System.out.println("Lambda Thread - Count: " + i);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    System.out.println("Lambda thread interrupted");
                }
            }
            System.out.println("Lambda thread finished");
        });
        thread.start();
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Thread Management</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class ThreadManagement {
    public static void main(String[] args) {
        // Create threads using different methods
        MyThread thread1 = new MyThread("Thread-1");
        Thread thread2 = new Thread(new MyRunnable("Thread-2"));
        
        // Set thread priorities
        thread1.setPriority(Thread.MAX_PRIORITY); // 10
        thread2.setPriority(Thread.MIN_PRIORITY); // 1
        
        // Start threads
        thread1.start();
        thread2.start();
        
        // Create and start lambda thread
        LambdaThread.createThreadWithLambda();
        
        // Main thread continues
        for (int i = 1; i <= 3; i++) {
            System.out.println("Main Thread - Count: " + i);
            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                System.out.println("Main thread interrupted");
            }
        }
        
        // Wait for threads to complete
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted while waiting");
        }
        
        System.out.println("All threads completed");
    }
}

// Thread synchronization example
class Counter {
    private int count = 0;
    
    // Synchronized method - only one thread can execute at a time
    public synchronized void increment() {
        count++;
    }
    
    // Synchronized block
    public void decrement() {
        synchronized(this) {
            count--;
        }
    }
    
    public synchronized int getCount() {
        return count;
    }
}

class CounterThread extends Thread {
    private Counter counter;
    private boolean increment;
    
    public CounterThread(Counter counter, boolean increment) {
        this.counter = counter;
        this.increment = increment;
    }
    
    @Override
    public void run() {
        for (int i = 0; i < 1000; i++) {
            if (increment) {
                counter.increment();
            } else {
                counter.decrement();
            }
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Thread Pool and Executor</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.concurrent.*;
import java.util.*;

public class ThreadPoolExample {
    public static void main(String[] args) {
        // Create a thread pool with 3 threads
        ExecutorService executor = Executors.newFixedThreadPool(3);
        
        // Submit tasks for execution
        for (int i = 1; i <= 5; i++) {
            final int taskId = i;
            executor.submit(() -> {
                System.out.println("Task " + taskId + " started by " + 
                    Thread.currentThread().getName());
                
                try {
                    Thread.sleep(1000); // Simulate work
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                System.out.println("Task " + taskId + " completed");
            });
        }
        
        // Submit a task that returns a value
        Future<Integer> future = executor.submit(() -> {
            int sum = 0;
            for (int i = 1; i <= 100; i++) {
                sum += i;
            }
            return sum;
        });
        
        try {
            // Get the result from Future
            Integer result = future.get(); // Blocks until result is available
            System.out.println("Sum of 1 to 100: " + result);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        
        // Shutdown the executor
        executor.shutdown();
        
        try {
            // Wait for tasks to complete
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
        
        System.out.println("All tasks completed");
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Lambda Section -->
            <section id="lambda" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-arrow-right mr-2"></i>Lambda Expressions
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Lambda expressions provide a clear and concise way to represent one method interface using an expression.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic Lambda Expressions</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;
import java.util.function.*;

public class LambdaBasics {
    public static void main(String[] args) {
        // 1. Lambda with no parameters
        Runnable runnable = () -> System.out.println("Hello from Lambda!");
        runnable.run();
        
        // 2. Lambda with one parameter
        Consumer<String> printer = str -> System.out.println(str);
        printer.accept("Lambda with one parameter");
        
        // 3. Lambda with multiple parameters
        BiFunction<Integer, Integer, Integer> adder = (a, b) -> a + b;
        System.out.println("Sum: " + adder.apply(5, 3));
        
        // 4. Lambda with statement block
        Comparator<String> comparator = (s1, s2) -> {
            System.out.println("Comparing: " + s1 + " and " + s2);
            return s1.compareTo(s2);
        };
        
        int result = comparator.compare("Apple", "Banana");
        System.out.println("Comparison result: " + result);
        
        // 5. Lambda with return statement
        Function<Integer, Integer> square = num -> {
            return num * num;
        };
        
        System.out.println("Square of 5: " + square.apply(5));
        
        // 6. Method reference alternative
        List<String> names = Arrays.asList("Alice", "Bob", "Charlie");
        
        // Using lambda
        names.forEach(name -> System.out.println(name));
        
        // Using method reference
        names.forEach(System.out::println);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Functional Interfaces</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.function.*;
import java.util.*;

public class FunctionalInterfaces {
    public static void main(String[] args) {
        // Predicate - returns boolean
        Predicate<Integer> isEven = num -> num % 2 == 0;
        System.out.println("Is 4 even? " + isEven.test(4));
        System.out.println("Is 5 even? " + isEven.test(5));
        
        // Consumer - consumes value, returns nothing
        Consumer<String> upperCasePrinter = str -> 
            System.out.println(str.toUpperCase());
        upperCasePrinter.accept("hello world");
        
        // Supplier - supplies value
        Supplier<Double> randomSupplier = () -> Math.random();
        System.out.println("Random number: " + randomSupplier.get());
        
        // Function - takes input, returns output
        Function<String, Integer> stringLength = str -> str.length();
        System.out.println("Length of 'Lambda': " + stringLength.apply("Lambda"));
        
        // UnaryOperator - single operand, returns same type
        UnaryOperator<String> addPrefix = str -> "Prefix_" + str;
        System.out.println(addPrefix.apply("Test"));
        
        // BinaryOperator - two operands, returns same type
        BinaryOperator<Integer> max = (a, b) -> Math.max(a, b);
        System.out.println("Max of 10 and 20: " + max.apply(10, 20));
        
        // Custom functional interface
        MathOperation addition = (a, b) -> a + b;
        MathOperation multiplication = (a, b) -> a * b;
        
        System.out.println("5 + 3 = " + addition.operate(5, 3));
        System.out.println("5 * 3 = " + multiplication.operate(5, 3));
    }
}

@FunctionalInterface
interface MathOperation {
    int operate(int a, int b);
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Lambdas with Collections</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;
import java.util.stream.*;

public class LambdaWithCollections {
    public static void main(String[] args) {
        List<Person> people = Arrays.asList(
            new Person("Alice", 25, "Engineering"),
            new Person("Bob", 30, "Marketing"),
            new Person("Charlie", 35, "Engineering"),
            new Person("Diana", 28, "HR"),
            new Person("Eve", 22, "Marketing")
        );
        
        // 1. Sort list using lambda
        System.out.println("Sorted by name:");
        people.sort((p1, p2) -> p1.getName().compareTo(p2.getName()));
        people.forEach(p -> System.out.println(p));
        
        // 2. Filter using lambda
        System.out.println("\nEngineering department:");
        List<Person> engineers = people.stream()
            .filter(p -> p.getDepartment().equals("Engineering"))
            .collect(Collectors.toList());
        engineers.forEach(System.out::println);
        
        // 3. Map using lambda
        System.out.println("\nNames only:");
        List<String> names = people.stream()
            .map(Person::getName)
            .collect(Collectors.toList());
        names.forEach(System.out::println);
        
        // 4. Reduce using lambda
        System.out.println("\nTotal age:");
        int totalAge = people.stream()
            .map(Person::getAge)
            .reduce(0, (sum, age) -> sum + age);
        System.out.println(totalAge);
        
        // 5. Group by using lambda
        System.out.println("\nGrouped by department:");
        Map<String, List<Person>> byDepartment = people.stream()
            .collect(Collectors.groupingBy(Person::getDepartment));
        
        byDepartment.forEach((dept, deptPeople) -> {
            System.out.println(dept + ":");
            deptPeople.forEach(p -> System.out.println("  " + p.getName()));
        });
        
        // 6. Remove if using lambda
        System.out.println("\nRemoving people younger than 25:");
        people.removeIf(p -> p.getAge() < 25);
        people.forEach(System.out::println);
    }
}

class Person {
    private String name;
    private int age;
    private String department;
    
    public Person(String name, int age, String department) {
        this.name = name;
        this.age = age;
        this.department = department;
    }
    
    // Getters
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getDepartment() { return department; }
    
    @Override
    public String toString() {
        return name + " (" + age + ", " + department + ")";
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Streams Section -->
            <section id="streams" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-water mr-2"></i>Stream API
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java Stream API provides a functional approach to processing collections of objects.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Stream Operations</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;
import java.util.stream.*;

public class StreamOperations {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        
        // 1. Filter - select elements based on condition
        List<Integer> evenNumbers = numbers.stream()
            .filter(n -> n % 2 == 0)
            .collect(Collectors.toList());
        System.out.println("Even numbers: " + evenNumbers);
        
        // 2. Map - transform elements
        List<Integer> squares = numbers.stream()
            .map(n -> n * n)
            .collect(Collectors.toList());
        System.out.println("Squares: " + squares);
        
        // 3. Filter and Map combined
        List<Integer> evenSquares = numbers.stream()
            .filter(n -> n % 2 == 0)
            .map(n -> n * n)
            .collect(Collectors.toList());
        System.out.println("Even squares: " + evenSquares);
        
        // 4. Distinct - remove duplicates
        List<Integer> withDuplicates = Arrays.asList(1, 2, 2, 3, 3, 3, 4, 4, 4, 4);
        List<Integer> distinct = withDuplicates.stream()
            .distinct()
            .collect(Collectors.toList());
        System.out.println("Distinct numbers: " + distinct);
        
        // 5. Sorted - sort elements
        List<Integer> unsorted = Arrays.asList(5, 2, 8, 1, 9, 3);
        List<Integer> sorted = unsorted.stream()
            .sorted()
            .collect(Collectors.toList());
        System.out.println("Sorted: " + sorted);
        
        // 6. Limit - get first n elements
        List<Integer> firstFive = numbers.stream()
            .limit(5)
            .collect(Collectors.toList());
        System.out.println("First 5: " + firstFive);
        
        // 7. Skip - skip first n elements
        List<Integer> afterFive = numbers.stream()
            .skip(5)
            .collect(Collectors.toList());
        System.out.println("After first 5: " + afterFive);
        
        // 8. Peek - perform action on each element (for debugging)
        List<Integer> processed = numbers.stream()
            .filter(n -> n > 5)
            .peek(n -> System.out.println("Filtered: " + n))
            .map(n -> n * 2)
            .peek(n -> System.out.println("Mapped: " + n))
            .collect(Collectors.toList());
        System.out.println("Final result: " + processed);
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Terminal Operations</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;
import java.util.stream.*;

public class TerminalOperations {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("java", "python", "javascript", "ruby", "go", "rust");
        
        // 1. forEach - perform action on each element
        System.out.println("All words:");
        words.stream().forEach(word -> System.out.println(word));
        
        // 2. toArray - convert stream to array
        String[] wordArray = words.stream().toArray(String[]::new);
        System.out.println("\nArray length: " + wordArray.length);
        
        // 3. collect - gather results
        List<String> upperCaseWords = words.stream()
            .map(String::toUpperCase)
            .collect(Collectors.toList());
        System.out.println("\nUppercase: " + upperCaseWords);
        
        // 4. Joining strings
        String joined = words.stream()
            .collect(Collectors.joining(", "));
        System.out.println("Joined: " + joined);
        
        // 5. count - count elements
        long count = words.stream()
            .filter(word -> word.length() > 4)
            .count();
        System.out.println("\nWords longer than 4 chars: " + count);
        
        // 6. reduce - combine elements
        Optional<String> longest = words.stream()
            .reduce((w1, w2) -> w1.length() > w2.length() ? w1 : w2);
        longest.ifPresent(w -> System.out.println("\nLongest word: " + w));
        
        // 7. min and max
        Optional<String> shortest = words.stream()
            .min(Comparator.comparingInt(String::length));
        shortest.ifPresent(w -> System.out.println("Shortest word: " + w));
        
        // 8. findFirst and findAny
        Optional<String> startsWithJ = words.stream()
            .filter(w -> w.startsWith("j"))
            .findFirst();
        startsWithJ.ifPresent(w -> System.out.println("\nFirst word starting with 'j': " + w));
        
        // 9. anyMatch, allMatch, noneMatch
        boolean anyStartsWithP = words.stream()
            .anyMatch(w -> w.startsWith("p"));
        System.out.println("\nAny word starts with 'p': " + anyStartsWithP);
        
        boolean allEndWithY = words.stream()
            .allMatch(w -> w.endsWith("y"));
        System.out.println("All words end with 'y': " + allEndWithY);
        
        boolean noneContainZ = words.stream()
            .noneMatch(w -> w.contains("z"));
        System.out.println("No words contain 'z': " + noneContainZ);
        
        // 10. Summary statistics
        IntSummaryStatistics stats = words.stream()
            .mapToInt(String::length)
            .summaryStatistics();
        
        System.out.println("\nLength statistics:");
        System.out.println("Count: " + stats.getCount());
        System.out.println("Min: " + stats.getMin());
        System.out.println("Max: " + stats.getMax());
        System.out.println("Average: " + stats.getAverage());
        System.out.println("Sum: " + stats.getSum());
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Parallel Streams</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;
import java.util.stream.*;

public class ParallelStreams {
    public static void main(String[] args) {
        // Create a large list
        List<Integer> largeList = new ArrayList<>();
        for (int i = 1; i <= 1_000_000; i++) {
            largeList.add(i);
        }
        
        // Sequential stream
        long startTime = System.currentTimeMillis();
        long sequentialSum = largeList.stream()
            .mapToLong(Integer::longValue)
            .sum();
        long sequentialTime = System.currentTimeMillis() - startTime;
        
        System.out.println("Sequential sum: " + sequentialSum);
        System.out.println("Sequential time: " + sequentialTime + "ms");
        
        // Parallel stream
        startTime = System.currentTimeMillis();
        long parallelSum = largeList.parallelStream()
            .mapToLong(Integer::longValue)
            .sum();
        long parallelTime = System.currentTimeMillis() - startTime;
        
        System.out.println("\nParallel sum: " + parallelSum);
        System.out.println("Parallel time: " + parallelTime + "ms");
        
        // Process list of objects
        List<Product> products = Arrays.asList(
            new Product("Laptop", 999.99, "Electronics"),
            new Product("Book", 19.99, "Education"),
            new Product("Phone", 699.99, "Electronics"),
            new Product("Chair", 149.99, "Furniture"),
            new Product("Table", 299.99, "Furniture")
        );
        
        // Parallel processing
        Map<String, List<Product>> byCategory = products.parallelStream()
            .collect(Collectors.groupingByConcurrent(Product::getCategory));
        
        System.out.println("\nProducts by category:");
        byCategory.forEach((category, items) -> {
            System.out.println(category + ":");
            items.forEach(p -> System.out.println("  " + p.getName()));
        });
        
        // Parallel filter and map
        List<String> expensiveProducts = products.parallelStream()
            .filter(p -> p.getPrice() > 100)
            .map(Product::getName)
            .collect(Collectors.toList());
        
        System.out.println("\nExpensive products: " + expensiveProducts);
    }
}

class Product {
    private String name;
    private double price;
    private String category;
    
    public Product(String name, double price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }
    
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Exceptions Section -->
            <section id="exceptions" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-exclamation-triangle mr-2"></i>Exception Handling
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Exception handling in Java helps manage runtime errors and maintain normal program flow.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Try-Catch-Finally</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class BasicExceptionHandling {
    public static void main(String[] args) {
        // Basic try-catch
        try {
            int result = 10 / 0; // This will throw ArithmeticException
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Caught arithmetic exception: " + e.getMessage());
        }
        
        // Multiple catch blocks
        try {
            String str = null;
            int length = str.length(); // NullPointerException
            int[] arr = new int[5];
            int value = arr[10]; // ArrayIndexOutOfBoundsException
        } catch (NullPointerException e) {
            System.out.println("Null pointer exception: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index out of bounds: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("General exception: " + e.getMessage());
        }
        
        // Finally block
        try {
            System.out.println("\nTrying to open resource...");
            // Simulate resource usage
            System.out.println("Resource in use");
            int result = 5 / 0; // This will cause an exception
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        } finally {
            System.out.println("Finally block - always executes");
            System.out.println("Resource closed");
        }
        
        // Try-with-resources (Java 7+)
        try (MyResource resource = new MyResource()) {
            System.out.println("\nUsing try-with-resources");
            resource.doSomething();
        } catch (Exception e) {
            System.out.println("Exception in try-with-resources: " + e.getMessage());
        }
        // Resource is automatically closed here
    }
}

class MyResource implements AutoCloseable {
    public MyResource() {
        System.out.println("Resource opened");
    }
    
    public void doSomething() {
        System.out.println("Doing something with resource");
    }
    
    @Override
    public void close() {
        System.out.println("Resource closed automatically");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Custom Exceptions</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Custom exception class
class InsufficientFundsException extends Exception {
    private double amount;
    
    public InsufficientFundsException(double amount) {
        super("Insufficient funds: " + amount);
        this.amount = amount;
    }
    
    public double getAmount() {
        return amount;
    }
}

// Another custom exception
class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

class BankAccount {
    private double balance;
    private String accountNumber;
    
    public BankAccount(String accountNumber, double initialBalance) {
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }
    
    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > balance) {
            throw new InsufficientFundsException(amount);
        }
        balance -= amount;
        System.out.println("Withdrew: $" + amount + ", New balance: $" + balance);
    }
    
    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance += amount;
        System.out.println("Deposited: $" + amount + ", New balance: $" + balance);
    }
    
    public double getBalance() {
        return balance;
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) throws InvalidAgeException {
        this.name = name;
        setAge(age);
    }
    
    public void setAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 150) {
            throw new InvalidAgeException("Age must be between 0 and 150");
        }
        this.age = age;
    }
    
    public int getAge() {
        return age;
    }
}

public class CustomExceptionDemo {
    public static void main(String[] args) {
        // Bank account example
        BankAccount account = new BankAccount("12345", 1000.0);
        
        try {
            account.withdraw(500.0);
            account.withdraw(600.0); // This will throw InsufficientFundsException
        } catch (InsufficientFundsException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Attempted to withdraw: $" + e.getAmount());
        }
        
        // Person age example
        try {
            Person person1 = new Person("Alice", 25);
            System.out.println("Created person with age: " + person1.getAge());
            
            Person person2 = new Person("Bob", -5); // This will throw InvalidAgeException
        } catch (InvalidAgeException e) {
            System.out.println("Error creating person: " + e.getMessage());
        }
        
        // Handling multiple exceptions
        try {
            account.deposit(-100); // IllegalArgumentException
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid deposit: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Throws and Throw</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;

public class ThrowsAndThrow {
    
    // Method that declares it throws exceptions
    public static void readFile(String filename) throws FileNotFoundException, IOException {
        FileInputStream fis = new FileInputStream(filename);
        // Read file operations
        fis.close();
    }
    
    // Method that throws an exception manually
    public static void validateAge(int age) {
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative");
        }
        if (age > 120) {
            throw new IllegalArgumentException("Age seems unrealistic");
        }
        System.out.println("Valid age: " + age);
    }
    
    // Method that re-throws an exception
    public static void processData(String data) throws Exception {
        try {
            // Process data
            if (data == null) {
                throw new NullPointerException("Data cannot be null");
            }
            System.out.println("Processing: " + data);
        } catch (NullPointerException e) {
            System.out.println("Caught in processData: " + e.getMessage());
            throw e; // Re-throw the exception
        }
    }
    
    // Chained exceptions
    public static void performOperation() throws Exception {
        try {
            // Some operation that might fail
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            // Wrap and throw new exception
            throw new Exception("Operation failed", e);
        }
    }
    
    public static void main(String[] args) {
        // Test validateAge
        try {
            validateAge(25);
            validateAge(-5);
        } catch (IllegalArgumentException e) {
            System.out.println("Validation error: " + e.getMessage());
        }
        
        // Test processData
        try {
            processData("Hello");
            processData(null);
        } catch (Exception e) {
            System.out.println("Error in main: " + e.getMessage());
        }
        
        // Test chained exceptions
        try {
            performOperation();
        } catch (Exception e) {
            System.out.println("Main error: " + e.getMessage());
            System.out.println("Cause: " + e.getCause().getMessage());
        }
        
        // Test readFile
        try {
            readFile("nonexistent.txt");
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("IO error: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Strings Section -->
            <section id="strings" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-font mr-2"></i>String Class
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Strings in Java are objects that represent sequences of characters. They are immutable.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">String Basics</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class StringBasics {
    public static void main(String[] args) {
        // Creating strings
        String str1 = "Hello";
        String str2 = new String("World");
        String str3 = "Hello"; // String literal reuse
        
        // String equality
        System.out.println("str1 == str3: " + (str1 == str3)); // true (same literal)
        System.out.println("str1 == str2: " + (str1 == str2)); // false (different objects)
        System.out.println("str1.equals(str3): " + str1.equals(str3)); // true
        System.out.println("str1.equals(str2): " + str1.equals(str2)); // false
        
        // String length
        String text = "Java Programming";
        System.out.println("\nLength: " + text.length());
        
        // Character access
        System.out.println("First character: " + text.charAt(0));
        System.out.println("Last character: " + text.charAt(text.length() - 1));
        
        // String concatenation
        String firstName = "John";
        String lastName = "Doe";
        String fullName = firstName + " " + lastName;
        System.out.println("\nFull name: " + fullName);
        
        // Using concat method
        String greeting = "Hello".concat(" ").concat("World");
        System.out.println("Greeting: " + greeting);
        
        // String immutability
        String original = "Hello";
        String modified = original.concat(" World");
        System.out.println("\nOriginal: " + original); // Still "Hello"
        System.out.println("Modified: " + modified); // "Hello World"
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">String Methods</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class StringMethods {
    public static void main(String[] args) {
        String text = "  Java Programming is Fun!  ";
        
        // Case conversion
        System.out.println("Original: '" + text + "'");
        System.out.println("Uppercase: " + text.toUpperCase());
        System.out.println("Lowercase: " + text.toLowerCase());
        
        // Trimming whitespace
        System.out.println("Trimmed: '" + text.trim() + "'");
        
        // Substring
        String sentence = "Java is powerful";
        System.out.println("\nSubstring (0-4): " + sentence.substring(0, 4));
        System.out.println("Substring (5): " + sentence.substring(5));
        
        // Replace
        System.out.println("Replace 'Java' with 'Python': " + 
            sentence.replace("Java", "Python"));
        System.out.println("Replace all 'a' with 'A': " + 
            sentence.replace('a', 'A'));
        
        // Contains and starts/ends with
        System.out.println("\nContains 'power': " + sentence.contains("power"));
        System.out.println("Starts with 'Java': " + sentence.startsWith("Java"));
        System.out.println("Ends with 'ful': " + sentence.endsWith("ful"));
        
        // Index operations
        String quote = "To be or not to be, that is the question";
        System.out.println("\nQuote: " + quote);
        System.out.println("Index of 'be': " + quote.indexOf("be"));
        System.out.println("Last index of 'be': " + quote.lastIndexOf("be"));
        System.out.println("Index of 'be' after 5: " + quote.indexOf("be", 5));
        
        // Split
        String data = "apple,banana,cherry,date";
        String[] fruits = data.split(",");
        System.out.println("\nSplit result:");
        for (String fruit : fruits) {
            System.out.println("- " + fruit);
        }
        
        // Value comparison (ignoring case)
        String str1 = "Hello";
        String str2 = "hello";
        System.out.println("\nEquals ignore case: " + str1.equalsIgnoreCase(str2));
        
        // Check if empty or blank
        String empty = "";
        String blank = "   ";
        System.out.println("Is empty: " + empty.isEmpty());
        System.out.println("Is blank: " + blank.isBlank());
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">StringBuilder and StringBuffer</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class MutableStrings {
    public static void main(String[] args) {
        // StringBuilder - not thread-safe, faster
        StringBuilder sb = new StringBuilder();
        sb.append("Hello");
        sb.append(" ");
        sb.append("World");
        sb.insert(5, " Beautiful");
        sb.delete(5, 15);
        System.out.println("StringBuilder: " + sb.toString());
        
        // StringBuffer - thread-safe, slower
        StringBuffer buffer = new StringBuffer("Java");
        buffer.append(" Programming");
        buffer.reverse();
        System.out.println("StringBuffer reversed: " + buffer.toString());
        
        // Performance comparison
        System.out.println("\n--- Performance Test ---");
        
        // Using String concatenation
        long start = System.currentTimeMillis();
        String str = "";
        for (int i = 0; i < 10000; i++) {
            str += i;
        }
        long stringTime = System.currentTimeMillis() - start;
        
        // Using StringBuilder
        start = System.currentTimeMillis();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            builder.append(i);
        }
        String result = builder.toString();
        long builderTime = System.currentTimeMillis() - start;
        
        System.out.println("String concatenation time: " + stringTime + "ms");
        System.out.println("StringBuilder time: " + builderTime + "ms");
        System.out.println("StringBuilder is " + (stringTime / builderTime) + "x faster");
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">String Formatting</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">public class StringFormatting {
    public static void main(String[] args) {
        // Using printf
        String name = "Alice";
        int age = 25;
        double salary = 50000.50;
        
        System.out.printf("Name: %s, Age: %d, Salary: %.2f%n", name, age, salary);
        
        // Using String.format
        String formatted = String.format("Name: %s, Age: %d", name, age);
        System.out.println("Formatted: " + formatted);
        
        // Number formatting
        double pi = 3.14159265359;
        System.out.printf("Pi (2 decimal places): %.2f%n", pi);
        System.out.printf("Pi (scientific): %e%n", pi);
        
        // Padding and alignment
        System.out.printf("%-10s | %5s | %10s%n", "Name", "Age", "Salary");
        System.out.printf("%-10s | %5d | %10.2f%n", "Alice", 25, 50000.50);
        System.out.printf("%-10s | %5d | %10.2f%n", "Bob", 30, 60000.75);
        
        // Date formatting
        import java.util.Date;
        Date now = new Date();
        System.out.printf("%nCurrent date: %tY-%tm-%td%n", now, now, now);
        System.out.printf("Current time: %tH:%tM:%tS%n", now, now, now);
        
        // Using Formatter class
        Formatter formatter = new Formatter();
        formatter.format("Hello %s!", "World");
        System.out.println("\nFormatter result: " + formatter.toString());
        formatter.close();
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Files Section -->
            <section id="files" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-file mr-2"></i>File I/O
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java provides extensive support for file I/O operations through various classes in the java.io package.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Reading and Writing Files</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;
import java.util.*;

public class FileOperations {
    public static void main(String[] args) {
        // Writing to a file using FileWriter
        try (FileWriter writer = new FileWriter("output.txt")) {
            writer.write("Hello, World!\n");
            writer.write("This is a test file.\n");
            writer.write("Java File I/O Example\n");
            System.out.println("Successfully wrote to output.txt");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
        
        // Reading from a file using FileReader
        System.out.println("\n--- Reading file ---");
        try (FileReader reader = new FileReader("output.txt");
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        
        // Using PrintWriter for formatted output
        try (PrintWriter printWriter = new PrintWriter("formatted.txt")) {
            printWriter.printf("%-15s %5s %10s%n", "Name", "Age", "Score");
            printWriter.printf("%-15s %5d %10.2f%n", "Alice", 25, 95.5);
            printWriter.printf("%-15s %5d %10.2f%n", "Bob", 30, 87.25);
            printWriter.printf("%-15s %5d %10.2f%n", "Charlie", 22, 92.75);
            System.out.println("\nSuccessfully wrote formatted.txt");
        } catch (IOException e) {
            System.out.println("Error writing formatted file: " + e.getMessage());
        }
        
        // Reading with Scanner
        System.out.println("\n--- Reading formatted file ---");
        try (Scanner scanner = new Scanner(new File("formatted.txt"))) {
            // Skip header
            if (scanner.hasNextLine()) {
                scanner.nextLine();
            }
            
            while (scanner.hasNext()) {
                String name = scanner.next();
                int age = scanner.nextInt();
                double score = scanner.nextDouble();
                System.out.printf("Name: %s, Age: %d, Score: %.2f%n", 
                    name, age, score);
            }
        } catch (IOException e) {
            System.out.println("Error reading formatted file: " + e.getMessage());
        }
        
        // Append to file
        try (FileWriter fw = new FileWriter("output.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            
            out.println("\n--- Appended content ---");
            out.println("This line was appended.");
            System.out.println("\nSuccessfully appended to output.txt");
        } catch (IOException e) {
            System.out.println("Error appending to file: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Binary File Operations</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;

public class BinaryFileOperations {
    public static void main(String[] args) {
        // Writing binary data
        try (DataOutputStream dos = new DataOutputStream(
                new FileOutputStream("data.bin"))) {
            
            dos.writeInt(42);
            dos.writeDouble(3.14159);
            dos.writeBoolean(true);
            dos.writeUTF("Hello Binary");
            System.out.println("Successfully wrote binary data");
        } catch (IOException e) {
            System.out.println("Error writing binary file: " + e.getMessage());
        }
        
        // Reading binary data
        System.out.println("\n--- Reading binary data ---");
        try (DataInputStream dis = new DataInputStream(
                new FileInputStream("data.bin"))) {
            
            int intValue = dis.readInt();
            double doubleValue = dis.readDouble();
            boolean boolValue = dis.readBoolean();
            String stringValue = dis.readUTF();
            
            System.out.println("Int: " + intValue);
            System.out.println("Double: " + doubleValue);
            System.out.println("Boolean: " + boolValue);
            System.out.println("String: " + stringValue);
        } catch (IOException e) {
            System.out.println("Error reading binary file: " + e.getMessage());
        }
        
        // Writing objects
        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("objects.ser"))) {
            
            Person person = new Person("John Doe", 30);
            oos.writeObject(person);
            
            List<String> list = new ArrayList<>();
            list.add("Item 1");
            list.add("Item 2");
            list.add("Item 3");
            oos.writeObject(list);
            
            System.out.println("\nSuccessfully wrote objects");
        } catch (IOException e) {
            System.out.println("Error writing objects: " + e.getMessage());
        }
        
        // Reading objects
        System.out.println("\n--- Reading objects ---");
        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream("objects.ser"))) {
            
            Person readPerson = (Person) ois.readObject();
            System.out.println("Person: " + readPerson);
            
            @SuppressWarnings("unchecked")
            List<String> readList = (List<String>) ois.readObject();
            System.out.println("List: " + readList);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading objects: " + e.getMessage());
        }
    }
}

// Serializable class for object I/O
class Person implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">File and Directory Operations</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;
import java.nio.file.*;
import java.util.*;

public class FileDirectoryOperations {
    public static void main(String[] args) {
        // Create directory
        File dir = new File("mydir");
        if (dir.mkdir()) {
            System.out.println("Directory created: " + dir.getName());
        } else {
            System.out.println("Directory already exists or creation failed");
        }
        
        // Create file in directory
        File file = new File(dir, "test.txt");
        try {
            if (file.createNewFile()) {
                System.out.println("File created: " + file.getName());
            }
        } catch (IOException e) {
            System.out.println("Error creating file: " + e.getMessage());
        }
        
        // Write to file
        try (PrintWriter writer = new PrintWriter(file)) {
            writer.println("This is a test file");
            writer.println("In a subdirectory");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
        
        // List directory contents
        System.out.println("\n--- Directory contents ---");
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) {
                    System.out.println("DIR: " + f.getName());
                } else {
                    System.out.println("FILE: " + f.getName() + 
                        " (" + f.length() + " bytes)");
                }
            }
        }
        
        // File information
        System.out.println("\n--- File information ---");
        System.out.println("Exists: " + file.exists());
        System.out.println("Is file: " + file.isFile());
        System.out.println("Is directory: " + file.isDirectory());
        System.out.println("Absolute path: " + file.getAbsolutePath());
        System.out.println("Can read: " + file.canRead());
        System.out.println("Can write: " + file.canWrite());
        System.out.println("Last modified: " + new Date(file.lastModified()));
        
        // Using NIO (New I/O) - Java 7+
        System.out.println("\n--- Using NIO ---");
        Path path = Paths.get("mydir", "test.txt");
        try {
            // Read all lines
            List<String> lines = Files.readAllLines(path);
            System.out.println("File content:");
            lines.forEach(System.out::println);
            
            // Get file attributes
            BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
            System.out.println("\nCreation time: " + attrs.creationTime());
            System.out.println("Last access time: " + attrs.lastAccessTime());
            System.out.println("Last modified time: " + attrs.lastModifiedTime());
            System.out.println("Size: " + attrs.size() + " bytes");
            
        } catch (IOException e) {
            System.out.println("NIO error: " + e.getMessage());
        }
        
        // Clean up (optional)
        if (file.delete()) {
            System.out.println("\nFile deleted: " + file.getName());
        }
        if (dir.delete()) {
            System.out.println("Directory deleted: " + dir.getName());
        }
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- JDBC Section -->
            <section id="jdbc" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-database mr-2"></i>JDBC
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">JDBC (Java Database Connectivity) provides an API for connecting and executing queries with databases.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic JDBC Operations</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.sql.*;

public class BasicJDBC {
    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/mydb";
    private static final String USER = "username";
    private static final String PASSWORD = "password";
    
    public static void main(String[] args) {
        // Load JDBC driver (not needed for JDBC 4.0+)
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e.getMessage());
            return;
        }
        
        // Establish connection
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("Connected to database successfully!");
            
            // Create table
            createTable(conn);
            
            // Insert records
            insertRecord(conn, "Alice", 25, "alice@example.com");
            insertRecord(conn, "Bob", 30, "bob@example.com");
            insertRecord(conn, "Charlie", 28, "charlie@example.com");
            
            // Read records
            readRecords(conn);
            
            // Update record
            updateRecord(conn, 2, "Robert", 31);
            
            // Delete record
            deleteRecord(conn, 3);
            
            // Read updated records
            System.out.println("\n--- After updates ---");
            readRecords(conn);
            
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
    
    private static void createTable(Connection conn) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "name VARCHAR(100) NOT NULL," +
                    "age INT," +
                    "email VARCHAR(100) UNIQUE)";
        
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            System.out.println("Table 'users' created or already exists");
        }
    }
    
    private static void insertRecord(Connection conn, String name, 
                                   int age, String email) throws SQLException {
        String sql = "INSERT INTO users (name, age, email) VALUES (?, ?, ?)";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, email);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) inserted");
        }
    }
    
    private static void readRecords(Connection conn) throws SQLException {
        String sql = "SELECT * FROM users";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("\n--- Users ---");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String email = rs.getString("email");
                
                System.out.printf("ID: %d, Name: %s, Age: %d, Email: %s%n",
                    id, name, age, email);
            }
        }
    }
    
    private static void updateRecord(Connection conn, int id, 
                                   String newName, int newAge) throws SQLException {
        String sql = "UPDATE users SET name = ?, age = ? WHERE id = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newName);
            pstmt.setInt(2, newAge);
            pstmt.setInt(3, id);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) updated");
        }
    }
    
    private static void deleteRecord(Connection conn, int id) throws SQLException {
        String sql = "DELETE FROM users WHERE id = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            
            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) deleted");
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">JDBC with Transaction Management</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.sql.*;

public class TransactionExample {
    private static final String URL = "jdbc:mysql://localhost:3306/bankdb";
    private static final String USER = "username";
    private static final String PASSWORD = "password";
    
    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            // Disable auto-commit for transaction management
            conn.setAutoCommit(false);
            
            try {
                // Transfer money from account 1 to account 2
                transferMoney(conn, 1, 2, 500.0);
                
                // If everything is successful, commit the transaction
                conn.commit();
                System.out.println("Transaction committed successfully!");
                
            } catch (SQLException e) {
                // If any error occurs, rollback the transaction
                conn.rollback();
                System.out.println("Transaction rolled back: " + e.getMessage());
            }
            
            // Restore auto-commit
            conn.setAutoCommit(true);
            
            // Check balances
            checkBalances(conn);
            
        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
    
    private static void transferMoney(Connection conn, int fromAccount, 
                                    int toAccount, double amount) throws SQLException {
        
        // Check if fromAccount has sufficient balance
        String checkSql = "SELECT balance FROM accounts WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(checkSql)) {
            pstmt.setInt(1, fromAccount);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    throw new SQLException("Insufficient balance in account " + fromAccount);
                }
            } else {
                throw new SQLException("Account " + fromAccount + " not found");
            }
        }
        
        // Deduct amount from fromAccount
        String debitSql = "UPDATE accounts SET balance = balance - ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(debitSql)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, fromAccount);
            int rows = pstmt.executeUpdate();
            
            if (rows == 0) {
                throw new SQLException("Failed to debit from account " + fromAccount);
            }
            System.out.println("Debited $" + amount + " from account " + fromAccount);
        }
        
        // Add amount to toAccount
        String creditSql = "UPDATE accounts SET balance = balance + ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(creditSql)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, toAccount);
            int rows = pstmt.executeUpdate();
            
            if (rows == 0) {
                throw new SQLException("Failed to credit to account " + toAccount);
            }
            System.out.println("Credited $" + amount + " to account " + toAccount);
        }
        
        // Record transaction
        String transactionSql = "INSERT INTO transactions (from_account, to_account, amount) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(transactionSql)) {
            pstmt.setInt(1, fromAccount);
            pstmt.setInt(2, toAccount);
            pstmt.setDouble(3, amount);
            pstmt.executeUpdate();
            System.out.println("Transaction recorded");
        }
    }
    
    private static void checkBalances(Connection conn) throws SQLException {
        String sql = "SELECT * FROM accounts";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("\n--- Account Balances ---");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double balance = rs.getDouble("balance");
                
                System.out.printf("Account %d (%s): $%.2f%n", id, name, balance);
            }
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Connection Pooling with HikariCP</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import com.zaxxer.hikari.*;
import java.sql.*;
import java.util.*;

public class ConnectionPoolExample {
    private static HikariDataSource dataSource;
    
    static {
        // Configure connection pool
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mysql://localhost:3306/mydb");
        config.setUsername("username");
        config.setPassword("password");
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(5);
        config.setConnectionTimeout(30000);
        config.setIdleTimeout(600000);
        config.setMaxLifetime(1800000);
        
        dataSource = new HikariDataSource(config);
    }
    
    public static void main(String[] args) {
        // Simulate multiple concurrent database operations
        List<Thread> threads = new ArrayList<>();
        
        for (int i = 0; i < 5; i++) {
            final int threadId = i;
            Thread thread = new Thread(() -> {
                try (Connection conn = dataSource.getConnection()) {
                    System.out.println("Thread " + threadId + " got connection");
                    
                    // Perform database operation
                    performOperation(conn, threadId);
                    
                    // Connection is automatically returned to pool when closed
                    System.out.println("Thread " + threadId + " returned connection");
                    
                } catch (SQLException e) {
                    System.out.println("Thread " + threadId + " error: " + e.getMessage());
                }
            });
            threads.add(thread);
            thread.start();
        }
        
        // Wait for all threads to complete
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        // Close connection pool
        dataSource.close();
        System.out.println("Connection pool closed");
    }
    
    private static void performOperation(Connection conn, int threadId) 
            throws SQLException {
        
        // Insert a record
        String sql = "INSERT INTO logs (thread_id, message, timestamp) VALUES (?, ?, NOW())";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, threadId);
            pstmt.setString(2, "Operation from thread " + threadId);
            pstmt.executeUpdate();
        }
        
        // Simulate some processing time
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Query records
        String querySql = "SELECT COUNT(*) as count FROM logs WHERE thread_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(querySql)) {
            pstmt.setInt(1, threadId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int count = rs.getInt("count");
                System.out.println("Thread " + threadId + " has " + count + " log entries");
            }
        }
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Networking Section -->
            <section id="networking" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-network-wired mr-2"></i>Networking
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Java provides extensive support for network programming through its java.net package.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">TCP Socket Programming</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;
import java.net.*;

// TCP Server
public class TCPServer {
    private static final int PORT = 8080;
    
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);
            
            while (true) {
                // Accept client connection
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());
                
                // Handle client in a separate thread
                new ClientHandler(clientSocket).start();
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }
    
    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private PrintWriter out;
        private BufferedReader in;
        
        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }
        
        @Override
        public void run() {
            try {
                // Setup streams
                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("Received: " + inputLine);
                    
                    // Process the message
                    String response = processMessage(inputLine);
                    out.println(response);
                    
                    // Exit condition
                    if ("bye".equalsIgnoreCase(inputLine)) {
                        break;
                    }
                }
            } catch (IOException e) {
                System.out.println("Error handling client: " + e.getMessage());
            } finally {
                try {
                    in.close();
                    out.close();
                    clientSocket.close();
                    System.out.println("Client disconnected");
                } catch (IOException e) {
                    System.out.println("Error closing connection: " + e.getMessage());
                }
            }
        }
        
        private String processMessage(String message) {
            if ("time".equalsIgnoreCase(message)) {
                return "Current time: " + new java.util.Date();
            } else if ("hello".equalsIgnoreCase(message)) {
                return "Hello from server!";
            } else if ("echo".equalsIgnoreCase(message)) {
                return "Echo: " + message;
            } else {
                return "Server received: " + message;
            }
        }
    }
}

// TCP Client
public class TCPClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 8080;
    
    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {
            
            System.out.println("Connected to server");
            System.out.println("Type messages (type 'bye' to exit):");
            
            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                // Send message to server
                out.println(userInput);
                
                // Receive response from server
                String response = in.readLine();
                System.out.println("Server: " + response);
                
                // Exit condition
                if ("bye".equalsIgnoreCase(userInput)) {
                    break;
                }
            }
        } catch (UnknownHostException e) {
            System.out.println("Unknown host: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">UDP Socket Programming</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.net.*;
import java.io.*;

// UDP Server
public class UDPServer {
    private static final int PORT = 9090;
    private static final int BUFFER_SIZE = 1024;
    
    public static void main(String[] args) {
        try (DatagramSocket serverSocket = new DatagramSocket(PORT)) {
            System.out.println("UDP Server started on port " + PORT);
            
            byte[] receiveBuffer = new byte[BUFFER_SIZE];
            
            while (true) {
                // Receive packet
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                serverSocket.receive(receivePacket);
                
                // Extract message and client info
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                
                System.out.println("Received from " + clientAddress + ":" + clientPort + " - " + message);
                
                // Process and send response
                String response = processMessage(message);
                byte[] sendBuffer = response.getBytes();
                
                DatagramPacket sendPacket = new DatagramPacket(
                    sendBuffer, sendBuffer.length, clientAddress, clientPort);
                serverSocket.send(sendPacket);
                
                System.out.println("Sent response: " + response);
            }
        } catch (IOException e) {
            System.out.println("UDP Server error: " + e.getMessage());
        }
    }
    
    private static String processMessage(String message) {
        if ("ping".equalsIgnoreCase(message)) {
            return "pong";
        } else if ("time".equalsIgnoreCase(message)) {
            return "Time: " + new java.util.Date();
        } else if ("uptime".equalsIgnoreCase(message)) {
            return "Server uptime: " + System.currentTimeMillis() + "ms";
        } else {
            return "Echo: " + message;
        }
    }
}

// UDP Client
public class UDPClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 9090;
    private static final int BUFFER_SIZE = 1024;
    
    public static void main(String[] args) {
        try (DatagramSocket clientSocket = new DatagramSocket();
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {
            
            InetAddress serverAddress = InetAddress.getByName(SERVER_HOST);
            byte[] sendBuffer;
            byte[] receiveBuffer = new byte[BUFFER_SIZE];
            
            System.out.println("UDP Client started");
            System.out.println("Type messages (type 'exit' to quit):");
            
            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                // Send message
                sendBuffer = userInput.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(
                    sendBuffer, sendBuffer.length, serverAddress, SERVER_PORT);
                clientSocket.send(sendPacket);
                
                // Exit condition
                if ("exit".equalsIgnoreCase(userInput)) {
                    break;
                }
                
                // Receive response
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                clientSocket.receive(receivePacket);
                
                String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Server: " + response);
            }
        } catch (IOException e) {
            System.out.println("UDP Client error: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">HTTP Client</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.io.*;
import java.net.*;
import java.util.*;

public class HTTPClient {
    public static void main(String[] args) {
        // GET request
        sendGetRequest("https://jsonplaceholder.typicode.com/posts/1");
        
        // POST request
        sendPostRequest("https://jsonplaceholder.typicode.com/posts");
    }
    
    private static void sendGetRequest(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            
            // Set request method
            connection.setRequestMethod("GET");
            
            // Set request headers
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "Java HTTP Client");
            
            // Get response code
            int responseCode = connection.getResponseCode();
            System.out.println("GET Response Code: " + responseCode);
            
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Read response
                BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
                
                String inputLine;
                StringBuilder response = new StringBuilder();
                
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                
                System.out.println("GET Response: " + response.toString());
                
            } else {
                System.out.println("GET request failed");
            }
            
        } catch (Exception e) {
            System.out.println("HTTP GET error: " + e.getMessage());
        }
    }
    
    private static void sendPostRequest(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            
            // Set request method
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "Java HTTP Client");
            
            // Enable output for POST
            connection.setDoOutput(true);
            
            // Create JSON payload
            String jsonPayload = "{\"title\": \"foo\", \"body\": \"bar\", \"userId\": 1}";
            
            // Send POST data
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            // Get response code
            int responseCode = connection.getResponseCode();
            System.out.println("\nPOST Response Code: " + responseCode);
            
            if (responseCode == HttpURLConnection.HTTP_CREATED) {
                // Read response
                BufferedReader in = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));
                
                String inputLine;
                StringBuilder response = new StringBuilder();
                
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();
                
                System.out.println("POST Response: " + response.toString());
            }
            
        } catch (Exception e) {
            System.out.println("HTTP POST error: " + e.getMessage());
        }
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Swing GUI Section -->
            <section id="swing" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-window-maximize mr-2"></i>GUI with Swing
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Swing is a GUI widget toolkit for Java. It provides a rich set of components for building desktop applications.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Basic Swing Application</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BasicSwingApp extends JFrame {
    private JLabel label;
    private JTextField textField;
    private JButton button;
    private JTextArea textArea;
    
    public BasicSwingApp() {
        // Set frame properties
        setTitle("Basic Swing Application");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create components
        label = new JLabel("Enter your name:");
        textField = new JTextField(20);
        button = new JButton("Greet");
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        
        // Add scroll pane to text area
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        // Set layout
        setLayout(new FlowLayout());
        
        // Add components to frame
        add(label);
        add(textField);
        add(button);
        add(scrollPane);
        
        // Add button click listener
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                if (!name.isEmpty()) {
                    String greeting = "Hello, " + name + "!\n";
                    textArea.append(greeting);
                    textField.setText("");
                } else {
                    JOptionPane.showMessageDialog(BasicSwingApp.this, 
                        "Please enter your name!", 
                        "Warning", 
                        JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        
        // Add key listener to text field
        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    button.doClick(); // Simulate button click
                }
            }
        });
    }
    
    public static void main(String[] args) {
        // Create and show GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BasicSwingApp().setVisible(true);
            }
        });
    }
}</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Advanced Swing Components</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class AdvancedSwingApp extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable table;
    private DefaultTableModel tableModel;
    private JList<String> list;
    private JCheckBox checkBox;
    private JRadioButton radioButton1, radioButton2;
    private JComboBox<String> comboBox;
    private JProgressBar progressBar;
    private JSlider slider;
    private JMenuBar menuBar;
    private JMenu fileMenu, editMenu;
    private JMenuItem newItem, openItem, saveItem, exitItem;
    private JMenuItem cutItem, copyItem, pasteItem;
    
    public AdvancedSwingApp() {
        setTitle("Advanced Swing Application");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Initialize components
        initComponents();
        
        // Create menu bar
        createMenuBar();
        
        // Add components to frame
        add(tabbedPane);
    }
    
    private void initComponents() {
        // Create tabbed pane
        tabbedPane = new JTabbedPane();
        
        // Tab 1: Table
        createTableTab();
        
        // Tab 2: Form Controls
        createFormControlsTab();
        
        // Tab 3: Progress
        createProgressTab();
    }
    
    private void createTableTab() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Create table model
        String[] columns = {"ID", "Name", "Age", "City"};
        tableModel = new DefaultTableModel(columns, 0);
        
        // Create table
        table = new JTable(tableModel);
        table.setAutoCreateRowSorter(true);
        
        // Add sample data
        addTableRow(1, "Alice", 25, "New York");
        addTableRow(2, "Bob", 30, "Los Angeles");
        addTableRow(3, "Charlie", 35, "Chicago");
        
        // Add scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        // Add button panel
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Row");
        JButton deleteButton = new JButton("Delete Row");
        
        addButton.addActionListener(e -> {
            int id = tableModel.getRowCount() + 1;
            addTableRow(id, "New Person", 20, "City");
        });
        
        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                tableModel.removeRow(selectedRow);
            }
        });
        
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        tabbedPane.addTab("Table", panel);
    }
    
    private void addTableRow(int id, String name, int age, String city) {
        Object[] row = {id, name, age, city};
        tableModel.addRow(row);
    }
    
    private void createFormControlsTab() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Check box
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Checkbox:"), gbc);
        gbc.gridx = 1;
        checkBox = new JCheckBox("Check me");
        panel.add(checkBox, gbc);
        
        // Radio buttons
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Radio Buttons:"), gbc);
        
        JPanel radioPanel = new JPanel();
        ButtonGroup radioGroup = new ButtonGroup();
        radioButton1 = new JRadioButton("Option 1");
        radioButton2 = new JRadioButton("Option 2");
        radioGroup.add(radioButton1);
        radioGroup.add(radioButton2);
        radioPanel.add(radioButton1);
        radioPanel.add(radioButton2);
        
        gbc.gridx = 1;
        panel.add(radioPanel, gbc);
        
        // Combo box
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Combo Box:"), gbc);
        gbc.gridx = 1;
        comboBox = new JComboBox<>(new String[]{"Item 1", "Item 2", "Item 3"});
        panel.add(comboBox, gbc);
        
        // List
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("List:"), gbc);
        gbc.gridx = 1;
        list = new JList<>(new String[]{"Apple", "Banana", "Cherry", "Date"});
        list.setVisibleRowCount(4);
        JScrollPane listScrollPane = new JScrollPane(list);
        panel.add(listScrollPane, gbc);
        
        // Slider
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("Slider:"), gbc);
        gbc.gridx = 1;
        slider = new JSlider(0, 100, 50);
        slider.setMajorTickSpacing(25);
        slider.setMinorTickSpacing(5);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        panel.add(slider, gbc);
        
        tabbedPane.addTab("Form Controls", panel);
    }
    
    private void createProgressTab() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Progress bar
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setValue(0);
        
        // Button to simulate progress
        JButton startButton = new JButton("Start Progress");
        startButton.addActionListener(e -> simulateProgress());
        
        panel.add(progressBar, BorderLayout.CENTER);
        panel.add(startButton, BorderLayout.SOUTH);
        
        tabbedPane.addTab("Progress", panel);
    }
    
    private void simulateProgress() {
        new Thread(() -> {
            for (int i = 0; i <= 100; i += 5) {
                final int progress = i;
                SwingUtilities.invokeLater(() -> {
                    progressBar.setValue(progress);
                    progressBar.setString(progress + "%");
                });
                
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    
    private void createMenuBar() {
        menuBar = new JMenuBar();
        
        // File menu
        fileMenu = new JMenu("File");
        newItem = new JMenuItem("New");
        openItem = new JMenuItem("Open");
        saveItem = new JMenuItem("Save");
        exitItem = new JMenuItem("Exit");
        
        fileMenu.add(newItem);
        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);
        
        // Edit menu
        editMenu = new JMenu("Edit");
        cutItem = new JMenuItem("Cut");
        copyItem = new JMenuItem("Copy");
        pasteItem = new JMenuItem("Paste");
        
        editMenu.add(cutItem);
        editMenu.add(copyItem);
        editMenu.add(pasteItem);
        
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        
        setJMenuBar(menuBar);
        
        // Add menu item listeners
        exitItem.addActionListener(e -> System.exit(0));
        
        newItem.addActionListener(e -> {
            tableModel.setRowCount(0);
            JOptionPane.showMessageDialog(this, "New document created!");
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AdvancedSwingApp().setVisible(true);
        });
    }
}</code></pre>
                    </div>
                </div>
            </section>

            <!-- Design Patterns Section -->
            <section id="patterns" class="content-section">
                <h2 class="text-3xl font-bold mb-4 text-indigo-600">
                    <i class="fas fa-th mr-2"></i>Design Patterns
                </h2>
                <div class="prose max-w-none">
                    <p class="text-gray-700 mb-4">Design patterns are reusable solutions to commonly occurring problems in software design. They represent best practices.</p>
                    
                    <h3 class="text-xl font-semibold mt-6 mb-3">Singleton Pattern</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Eager initialization
public class EagerSingleton {
    private static final EagerSingleton INSTANCE = new EagerSingleton();
    
    private EagerSingleton() {
        // Private constructor to prevent instantiation
    }
    
    public static EagerSingleton getInstance() {
        return INSTANCE;
    }
}

// Lazy initialization with thread safety
public class LazySingleton {
    private static LazySingleton instance;
    
    private LazySingleton() {
        // Private constructor
    }
    
    public static synchronized LazySingleton getInstance() {
        if (instance == null) {
            instance = new LazySingleton();
        }
        return instance;
    }
}

// Double-checked locking
public class DCLSingleton {
    private static volatile DCLSingleton instance;
    
    private DCLSingleton() {
        // Private constructor
    }
    
    public static DCLSingleton getInstance() {
        if (instance == null) {
            synchronized (DCLSingleton.class) {
                if (instance == null) {
                    instance = new DCLSingleton();
                }
            }
        }
        return instance;
    }
}

// Enum singleton (recommended approach)
public enum EnumSingleton {
    INSTANCE;
    
    public void doSomething() {
        System.out.println("Singleton is working!");
    }
}

// Demo
public class SingletonDemo {
    public static void main(String[] args) {
        // Get singleton instances
        LazySingleton s1 = LazySingleton.getInstance();
        LazySingleton s2 = LazySingleton.getInstance();
        
        System.out.println("Same instance? " + (s1 == s2));
        
        // Using enum singleton
        EnumSingleton.INSTANCE.doSomething();
    }
}</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Factory Pattern</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Shape interface
interface Shape {
    void draw();
}

// Concrete shapes
class Circle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}

class Rectangle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a rectangle");
    }
}

class Triangle implements Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a triangle");
    }
}

// Shape factory
class ShapeFactory {
    public Shape getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }
        
        switch (shapeType.toUpperCase()) {
            case "CIRCLE":
                return new Circle();
            case "RECTANGLE":
                return new Rectangle();
            case "TRIANGLE":
                return new Triangle();
            default:
                throw new IllegalArgumentException("Unknown shape type: " + shapeType);
        }
    }
}

// Demo
public class FactoryDemo {
    public static void main(String[] args) {
        ShapeFactory factory = new ShapeFactory();
        
        // Get shapes using factory
        Shape circle = factory.getShape("CIRCLE");
        Shape rectangle = factory.getShape("RECTANGLE");
        Shape triangle = factory.getShape("TRIANGLE");
        
        // Draw shapes
        circle.draw();
        rectangle.draw();
        triangle.draw();
    }
}</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Observer Pattern</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">import java.util.*;

// Observer interface
interface Observer {
    void update(String message);
}

// Subject interface
interface Subject {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}

// Concrete subject
class NewsAgency implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private String news;
    
    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }
    
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(news);
        }
    }
    
    public void setNews(String news) {
        this.news = news;
        System.out.println("News published: " + news);
        notifyObservers();
    }
}

// Concrete observers
class NewsChannel implements Observer {
    private String channelName;
    
    public NewsChannel(String channelName) {
        this.channelName = channelName;
    }
    
    @Override
    public void update(String message) {
        System.out.println(channelName + " received news: " + message);
    }
}

class Newspaper implements Observer {
    private String paperName;
    
    public Newspaper(String paperName) {
        this.paperName = paperName;
    }
    
    @Override
    public void update(String message) {
        System.out.println(paperName + " will publish: " + message);
    }
}

// Demo
public class ObserverDemo {
    public static void main(String[] args) {
        // Create subject
        NewsAgency newsAgency = new NewsAgency();
        
        // Create observers
        Observer channel1 = new NewsChannel("CNN");
        Observer channel2 = new NewsChannel("BBC");
        Observer paper = new Newspaper("New York Times");
        
        // Register observers
        newsAgency.registerObserver(channel1);
        newsAgency.registerObserver(channel2);
        newsAgency.registerObserver(paper);
        
        // Publish news
        newsAgency.setNews("Breaking: Java Design Patterns Tutorial Published!");
        
        // Remove an observer
        newsAgency.removeObserver(channel2);
        
        // Publish another news
        newsAgency.setNews("Update: Tutorial includes examples!");
    }
}</code></pre>
                    </div>

                    <h3 class="text-xl font-semibold mt-6 mb-3">Strategy Pattern</h3>
                    <div class="code-toolbar">
                        <button class="copy-button" onclick="copyCode(this)">Copy</button>
                        <pre><code class="language-java">// Strategy interface
interface PaymentStrategy {
    void pay(int amount);
}

// Concrete strategies
class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    
    public CreditCardPayment(String cardNumber) {
        this.cardNumber = cardNumber;
    }
    
    @Override
    public void pay(int amount) {
        System.out.println("Paid $" + amount + " using Credit Card (" + cardNumber + ")");
    }
}

class PayPalPayment implements PaymentStrategy {
    private String email;
    
    public PayPalPayment(String email) {
        this.email = email;
    }
    
    @Override
    public void pay(int amount) {
        System.out.println("Paid $" + amount + " using PayPal (" + email + ")");
    }
}

class CashPayment implements PaymentStrategy {
    @Override
    public void pay(int amount) {
        System.out.println("Paid $" + amount + " in cash");
    }
}

// Context class
class ShoppingCart {
    private PaymentStrategy paymentStrategy;
    
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }
    
    public void checkout(int amount) {
        if (paymentStrategy == null) {
            System.out.println("Please select a payment method!");
            return;
        }
        paymentStrategy.pay(amount);
    }
}

// Demo
public class StrategyDemo {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();
        
        // Use different payment strategies
        cart.setPaymentStrategy(new CreditCardPayment("1234-5678-9012-3456"));
        cart.checkout(100);
        
        cart.setPaymentStrategy(new PayPalPayment("user@example.com"));
        cart.checkout(50);
        
        cart.setPaymentStrategy(new CashPayment());
        cart.checkout(25);
    }
}</code></pre>
                    </div>
                </div>
            </section>

        </main>
    </div>

    <!-- Footer -->
    <footer class="gradient-bg text-white mt-12 py-8">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <p class="text-lg font-semibold">Java Programming Tutorial</p>
                    <p class="text-sm opacity-90">Complete guide to learning Java</p>
                </div>
                <div class="flex space-x-4">
                    <a href="#" class="hover:bg-white/20 p-2 rounded-lg transition">
                        <i class="fab fa-github text-xl"></i>
                    </a>
                    <a href="#" class="hover:bg-white/20 p-2 rounded-lg transition">
                        <i class="fab fa-linkedin text-xl"></i>
                    </a>
                    <a href="#" class="hover:bg-white/20 p-2 rounded-lg transition">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                </div>
            </div>
            <div class="mt-6 pt-6 border-t border-white/20 text-center">
                <p class="text-sm opacity-90">© 2024 Java Tutorial. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Progress tracking
        
        let completedTopics = completedFromDB;
        const totalTopics = totalFromDB;

        // Topic data for search
        const topicData = {
            'intro': { title: 'Introduction to Java', unit: 'Unit 1', keywords: ['java', 'introduction', 'programming', 'language', 'features', 'applications'] },
            'setup': { title: 'Setup & Installation', unit: 'Unit 1', keywords: ['setup', 'installation', 'jdk', 'ide', 'environment', 'verify'] },
            'syntax': { title: 'Basic Syntax', unit: 'Unit 1', keywords: ['syntax', 'structure', 'main', 'class', 'method', 'code'] },
            'variables': { title: 'Variables & Data Types', unit: 'Unit 1', keywords: ['variables', 'data types', 'primitive', 'reference', 'conversion', 'type'] },
            'operators': { title: 'Operators', unit: 'Unit 1', keywords: ['operators', 'arithmetic', 'comparison', 'logical', 'assignment', 'bitwise'] },
            'input': { title: 'User Input', unit: 'Unit 1', keywords: ['input', 'scanner', 'console', 'user', 'read', 'keyboard'] },
            'comments': { title: 'Comments', unit: 'Unit 1', keywords: ['comments', 'documentation', 'single', 'multi', 'javadoc'] },
            'first': { title: 'First Program', unit: 'Unit 1', keywords: ['hello world', 'first', 'program', 'compile', 'run'] },
            'classes': { title: 'Classes & Objects', unit: 'Unit 2', keywords: ['class', 'object', 'instance', 'field', 'property', 'attribute'] },
            'methods': { title: 'Methods', unit: 'Unit 2', keywords: ['method', 'function', 'parameter', 'argument', 'return', 'void'] },
            'constructors': { title: 'Constructors', unit: 'Unit 2', keywords: ['constructor', 'initialization', 'new', 'this', 'default', 'overloading'] },
            'inheritance': { title: 'Inheritance', unit: 'Unit 2', keywords: ['inheritance', 'extends', 'super', 'parent', 'child', 'subclass'] },
            'polymorphism': { title: 'Polymorphism', unit: 'Unit 2', keywords: ['polymorphism', 'overriding', 'overloading', 'dynamic', 'static'] },
            'encapsulation': { title: 'Encapsulation', unit: 'Unit 2', keywords: ['encapsulation', 'private', 'public', 'protected', 'getter', 'setter'] },
            'static': { title: 'Static Members', unit: 'Unit 2', keywords: ['static', 'class', 'variable', 'method', 'final', 'constant'] },
            'inner': { title: 'Inner Classes', unit: 'Unit 2', keywords: ['inner', 'nested', 'class', 'anonymous', 'local', 'static'] },
            'collections': { title: 'Collections Framework', unit: 'Unit 3', keywords: ['collections', 'list', 'set', 'map', 'arraylist', 'hashmap'] },
            'generics': { title: 'Generics', unit: 'Unit 3', keywords: ['generics', 'type', 'parameter', 'diamond', 'wildcard', 'bounded'] },
            'threads': { title: 'Multithreading', unit: 'Unit 3', keywords: ['thread', 'multithreading', 'runnable', 'synchronized', 'concurrent', 'parallel'] },
            'lambda': { title: 'Lambda Expressions', unit: 'Unit 3', keywords: ['lambda', 'expression', 'functional', 'interface', 'arrow', '->'] },
            'streams': { title: 'Stream API', unit: 'Unit 3', keywords: ['stream', 'api', 'filter', 'map', 'reduce', 'collect'] },
            'exceptions': { title: 'Exception Handling', unit: 'Unit 3', keywords: ['exception', 'try', 'catch', 'finally', 'throw', 'throws'] },
            'strings': { title: 'String Class', unit: 'Unit 4', keywords: ['string', 'immutable', 'concatenation', 'methods', 'format', 'builder'] },
            'files': { title: 'File I/O', unit: 'Unit 4', keywords: ['file', 'io', 'read', 'write', 'stream', 'reader', 'writer'] },
            'jdbc': { title: 'JDBC', unit: 'Unit 4', keywords: ['jdbc', 'database', 'connection', 'statement', 'resultset', 'driver'] },
            'networking': { title: 'Networking', unit: 'Unit 4', keywords: ['networking', 'socket', 'tcp', 'udp', 'client', 'server', 'url'] },
            'swing': { title: 'GUI with Swing', unit: 'Unit 4', keywords: ['swing', 'gui', 'jframe', 'jpanel', 'component', 'event'] },
            'patterns': { title: 'Design Patterns', unit: 'Unit 4', keywords: ['design patterns', 'singleton', 'factory', 'observer', 'strategy', 'adapter'] }
        };


        // Show content based on sidebar click
        function showContent(topicId) {
            // Hide all sections
            const sections = document.querySelectorAll('.content-section');
            sections.forEach(section => {
                section.classList.remove('active');
            });
            
            // Show selected section
            const selectedSection = document.getElementById(topicId);
            if (selectedSection) {
                selectedSection.classList.add('active');
            }
            
            // Update sidebar active state
            const sidebarItems = document.querySelectorAll('.sidebar-item');
            sidebarItems.forEach(item => {
                item.classList.remove('active');
            });
            
            // Add active class to clicked item
            const clickedItem = document.querySelector(`[data-topic="${topicId}"]`);
            if (clickedItem) {
                clickedItem.classList.add('active');
                
                // (Removed auto-mark so users must click the button)
            }
            
            // Update progress
            updateProgress();
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            // Clear search when navigating
            clearSearch();
        }

// Update progress indicators
function updateProgress() {

    let percentage = 0;

    if(totalTopics > 0){
        percentage = Math.min(100, Math.round((completedTopics / totalTopics) * 100));
    }

    document.getElementById('progressBar').style.width = percentage + '%';

    const circumference = 2 * Math.PI * 12;
    const offset = circumference - (percentage / 100) * circumference;
    document.getElementById('progressCircle').style.strokeDashoffset = offset;

    document.getElementById('progressText').textContent = percentage + '%';

    document.getElementById('completedCount').textContent = completedTopics;
    document.getElementById('totalCount').textContent = totalTopics;
}

        // Load saved progress
        function loadProgress() {
            if (saved) {
                completedTopics = new Set(JSON.parse(saved));
                completedTopics.forEach(topicId => {
                    const item = document.querySelector(`[data-topic="${topicId}"]`);
                    if (item) {
                        item.classList.add('topic-completed');
                    }
                });
                updateProgress();
            }
        }

        // Toggle sidebar (mobile)
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('hidden');
        }

        // Copy code functionality
        function copyCode(button) {
            const codeBlock = button.parentElement.querySelector('code');
            const text = codeBlock.textContent;
            
            navigator.clipboard.writeText(text).then(() => {
                const originalText = button.textContent;
                button.textContent = 'Copied!';
                button.style.background = '#10b981';
                
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.background = '#4f46e5';
                }, 2000);
            });
        }

        // Clear search
        function clearSearch() {
            const searchInput = document.getElementById('globalSearch');
            const clearButton = document.getElementById('clearSearch');
            const searchDropdown = document.getElementById('searchDropdown');
            
            searchInput.value = '';
            clearButton.classList.add('hidden');
            searchDropdown.classList.remove('active');
        }

        // Global search functionality
        function initializeGlobalSearch() {
            const searchInput = document.getElementById('globalSearch');
            const clearButton = document.getElementById('clearSearch');
            const searchDropdown = document.getElementById('searchDropdown');
            
            searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase().trim();
                
                // Show/hide clear button
                if (searchTerm) {
                    clearButton.classList.remove('hidden');
                } else {
                    clearButton.classList.add('hidden');
                }
                
                if (searchTerm.length < 2) {
                    searchDropdown.classList.remove('active');
                    return;
                }
                
                // Search through topics
                const results = [];
                
                for (const [topicId, data] of Object.entries(topicData)) {
                    const titleMatch = data.title.toLowerCase().includes(searchTerm);
                    const keywordMatch = data.keywords.some(keyword => 
                        keyword.toLowerCase().includes(searchTerm)
                    );
                    
                    if (titleMatch || keywordMatch) {
                        results.push({
                            topicId,
                            title: data.title,
                            unit: data.unit,
                            matchType: titleMatch ? 'title' : 'keyword'
                        });
                    }
                }
                
                // Display results
                if (results.length > 0) {
                    searchDropdown.innerHTML = results.map(result => `
                        <div class="search-result-item" onclick="navigateToTopic('${result.topicId}')">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="font-semibold text-gray-800">${highlightMatch(result.title, searchTerm)}</div>
                                    <div class="text-sm text-gray-500">${result.unit}</div>
                                </div>
                                <i class="fas fa-arrow-right text-gray-400"></i>
                            </div>
                        </div>
                    `).join('');
                    searchDropdown.classList.add('active');
                } else {
                    searchDropdown.innerHTML = `
                        <div class="no-results">
                            <i class="fas fa-search text-gray-300 text-2xl mb-2"></i>
                            <p>No topics found for "${searchTerm}"</p>
                        </div>
                    `;
                    searchDropdown.classList.add('active');
                }
            });
            
            // Hide dropdown when clicking outside
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchDropdown.contains(e.target)) {
                    searchDropdown.classList.remove('active');
                }
            });
        }

        // Initialize
document.addEventListener('DOMContentLoaded', function() {

    // 🔥 calculate percentage safely
    let percentage = 0;
    if(totalFromDB > 0){
        percentage = Math.min(100, Math.round((completedFromDB / totalFromDB) * 100));
    }

    // 🔥 update top progress text
    document.getElementById('progressText').textContent = percentage + '%';

    // 🔥 update circular progress
    const circumference = 2 * Math.PI * 12;
    const offset = circumference - (percentage / 100) * circumference;
    document.getElementById('progressCircle').style.strokeDashoffset = offset;

    // 🔥 update sidebar progress
    document.getElementById("completedCount").textContent = completedFromDB;
    document.getElementById("totalCount").textContent = totalFromDB;
    document.getElementById("progressBar").style.width = percentage + "%";

    // 🔥 apply completed ticks from DB
    completedTopicsFromDB.forEach(topic => {
        const el = document.querySelector(`[data-topic="${topic}"]`);
        if(el){
            el.classList.add('topic-completed');
        }
    });

    // 🔥 inject Mark as Complete buttons
    function injectCompletionButtons() {
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => {
            const topicId = section.id;
            const btnContainer = document.createElement('div');
            btnContainer.className = 'mt-10 pt-6 border-t border-gray-100 flex justify-end';
            const btn = document.createElement('button');
            btn.className = 'mark-complete-btn bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 flex items-center gap-2 shadow-sm';
            btn.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
            
            btn.onclick = () => {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                markTopicComplete(topicId);
            };
            
            btnContainer.appendChild(btn);
            section.appendChild(btnContainer);
        });
        
        completedTopicsFromDB.forEach(topic => {
            const section = document.getElementById(topic);
            if (section) {
                const btn = section.querySelector('.mark-complete-btn');
                if (btn) {
                    btn.classList.replace('bg-indigo-50', 'bg-green-500');
                    btn.classList.replace('text-indigo-600', 'text-white');
                    btn.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                    btn.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                    btn.disabled = true;
                    btn.classList.add('cursor-default');
                }
            }
        });
    }
    injectCompletionButtons();

    const sidebarItemsList = Array.from(document.querySelectorAll('.sidebar-item'));
    sidebarItemsList.forEach((item, index) => {
        if (index > completedTopics) {
            item.classList.add('opacity-50', 'pointer-events-none');
            const icon = item.querySelector('i');
            if (icon) {
                item.dataset.origIcon = icon.className;
                icon.className = 'fas fa-lock mr-2';
            }
        }
    });

    // 🔥 highlight code blocks
    Prism.highlightAll();

    // 🔥 set first item active (if nothing selected)
    const firstItem = document.querySelector('.sidebar-item');
    if (firstItem && !firstItem.classList.contains('topic-completed')) {
        firstItem.classList.add('active');
    }

    // 🔥 keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            document.getElementById('globalSearch').focus();
        }

        if (e.key === 'Escape') {
            const search = document.getElementById('globalSearch');
            if(search) search.value = "";
            document.activeElement.blur();
        }
    });

});

        // Smooth scroll for internal links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Navigate to topic from search
        function navigateToTopic(topicId) {
            showContent(topicId);
            clearSearch();
            
            // Update sidebar active state
            const sidebarItems = document.querySelectorAll('.sidebar-item');
            sidebarItems.forEach(item => {
                item.classList.remove('active');
            });
            
            const clickedItem = document.querySelector(`[data-topic="${topicId}"]`);
            if (clickedItem) {
                clickedItem.classList.add('active');
            }
        }

        // Highlight search match in text
        function highlightMatch(text, searchTerm) {
            const regex = new RegExp(`(${searchTerm})`, 'gi');
            return text.replace(regex, '<span class="search-highlight">$1</span>');
        }
                   
function markTopicComplete(topicName){

    fetch("http://localhost/eduspring/save_progress.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "course_id=2&topic_name=" + encodeURIComponent(topicName)
    })
    .then(res => res.text())
    .then(data => {
        console.log("Response:", data);

        if(data === "updated" || data === "already_completed"){
            if (data === "updated") {
                completedTopics++;
            }
            
            const el = document.querySelector(`[data-topic="${topicName}"]`);
            if (el) {
                el.classList.add('topic-completed');
            }
            
            const section = document.getElementById(topicName);
            if (section) {
                const btn = section.querySelector('.mark-complete-btn');
                if (btn) {
                    btn.classList.replace('bg-indigo-50', 'bg-green-500');
                    btn.classList.replace('text-indigo-600', 'text-white');
                    btn.classList.replace('hover:bg-indigo-600', 'hover:bg-green-600');
                    btn.innerHTML = '<i class="fas fa-check-double"></i> Completed';
                    btn.disabled = true;
                    btn.classList.add('cursor-default');
                }
            }
            
            updateProgress();

            // Unlock the next item visually
            const allSidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
            const currIdx = allSidebarItems.findIndex(i => i.getAttribute('data-topic') === topicName);
            if (currIdx >= 0 && currIdx < allSidebarItems.length - 1) {
                const nextItem = allSidebarItems[currIdx + 1];
                nextItem.classList.remove('opacity-50', 'pointer-events-none');
                const nextIcon = nextItem.querySelector('i');
                if (nextIcon && nextItem.dataset.origIcon) {
                    nextIcon.className = nextItem.dataset.origIcon;
                }
            }

            setTimeout(() => {
                const sidebarItems = Array.from(document.querySelectorAll('.sidebar-item'));
                const currentIndex = sidebarItems.findIndex(item => item.getAttribute('data-topic') === topicName);
                if (currentIndex >= 0 && currentIndex < sidebarItems.length - 1) {
                    const nextTopicId = sidebarItems[currentIndex + 1].getAttribute('data-topic');
                    showContent(nextTopicId);
                } else if (currentIndex === sidebarItems.length - 1) {
                    window.location.href = 'java_quiz_page.php';
                }
            }, 800);
        }
    })
    .catch(err => {
        console.error("Error:", err);
        const section = document.getElementById(topicName);
        if (section) {
            const btn = section.querySelector('.mark-complete-btn');
            if (btn) {
                btn.innerHTML = '<i class="fas fa-check-circle"></i> Mark as Complete';
            }
        }
    });
}

    </script>
</body>
</html>