<?php
session_start();
include("../../db.php");

// ✅ Login check
if(!isset($_SESSION['user_id'])){
    echo "Unauthorized";
    exit();
}

$user_id = $_SESSION['user_id'];

// ✅ Get course_id using slug (java)
$slug = "java";
$stmt = $conn->prepare("SELECT id FROM courses WHERE slug=?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$res = $stmt->get_result();

$course = $res->fetch_assoc();

if(!$course){
    die("❌ Course not found");
}

$course_id = $course['id'];

// ✅ Get user name
$userQuery = $conn->prepare("SELECT CONCAT(fname,' ',lname) AS name FROM users WHERE id=?");
$userQuery->bind_param("i", $user_id);
$userQuery->execute();
$userRes = $userQuery->get_result()->fetch_assoc();

if(!$userRes){
    die("❌ User not found");
}

$fullName = ucwords(strtolower($userRes['name']));

// ✅ Get latest quiz result
$resultQuery = $conn->prepare("
SELECT * FROM quiz_results 
WHERE user_id=? AND course_id=? 
ORDER BY id DESC LIMIT 1
");
$resultQuery->bind_param("ii", $user_id, $course_id);
$resultQuery->execute();
$result = $resultQuery->get_result()->fetch_assoc();

// ❌ No result
if(!$result){
    die("❌ No result found");
}

// ❌ Not passed
if($result['passed'] != 1){
    die("❌ Access Denied");
}

$percentage = $result['percentage'];

// ✅ Grade logic
$class = "";

if($percentage >= 91){
    $class = "First Class with Distinction";
}
elseif($percentage >= 81){
    $class = "First Class";
}
elseif($percentage >= 70){
    $class = "Second Class";
}
else{
    $class = "Fail";
}

// ✅ Date from DB
$date = date("F d, Y", strtotime($result['created_at']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learnify Certificate</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;800&family=Playfair+Display:wght@700&family=Great+Vibes&display=swap" rel="stylesheet">
    <style>
        :root {
            --royal-blue: #5d6eff;
            --dark-text: #1a202c;
            --gold-primary: #bf953f;
            --gold-secondary: #fcf6ba;
            --gold-tertiary: #b38728;
            --gold-quaternary: #fbf5b7;
            --gold-shadow: #aa771c;
        }

        @page {
            size: A4 landscape;
            margin: 0;
        }

        body {
            background-color: #f7fafc;
            font-family: 'Montserrat', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            padding: 0;
        }

        .certificate-container {
            width: 1000px; 
            height: 700px;
            background: #fff;
            position: relative;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            border: 15px solid white;
            outline: 2px solid var(--royal-blue);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .corner-accent {
            position: absolute;
            width: 160px;
            height: 160px;
            background: var(--royal-blue);
            z-index: 1;
        }
        .top-left { top: -80px; left: -80px; transform: rotate(45deg); }
        .bottom-right { bottom: -80px; right: -80px; transform: rotate(45deg); }

        .header {
            text-align: center;
            margin-top: 50px;
            z-index: 2;
        }

        .logo {
            font-weight: 800;
            font-size: 24px;
            letter-spacing: 3px;
            color: var(--dark-text);
        }

        .main-title {
            font-weight: 800;
            font-size: 52px;
            color: var(--royal-blue);
            margin: 15px 0;
            text-transform: uppercase;
        }

        .cert-content {
            text-align: center;
            z-index: 2;
            flex-grow: 1;
            padding: 0 60px;
        }

        .recipient-name {
            font-family: 'Playfair Display', serif;
            font-size: 50px;
            color: var(--dark-text);
            margin: 15px 0 5px 0;
            text-transform: uppercase;
        }

        .name-line {
            width: 500px;
            height: 2px;
            background: linear-gradient(to right, transparent, #cbd5e0, transparent);
            margin: 10px auto 20px auto;
        }

        .appreciation-text {
            font-size: 14px;
            color: #555;
            line-height: 1.6;
            width: 85%;
            margin: 15px auto;
            font-style: italic;
        }

        .medal-box {
            position: relative;
            width: 100px;
            height: 120px;
            margin: 0 auto;
            transform: translateY(28px); 
        }
        
        .ribbon {
            position: absolute;
            width: 40px;
            height: 80px;
            background: linear-gradient(to bottom, #d3222a, #8b0000);
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1;
            box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
            clip-path: polygon(0 0, 100% 0, 100% 100%, 50% 85%, 0 100%);
        }

        .gold-seal {
            position: absolute;
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--gold-primary), var(--gold-secondary), var(--gold-tertiary), var(--gold-quaternary), var(--gold-shadow));
            border-radius: 50%;
            top: 15px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 2;
            border: 2px solid var(--gold-shadow);
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .seal-inner {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            border: 1px dashed white;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            font-weight: 800;
            font-size: 14px;
            letter-spacing: 1px;
        }

        .footer {
            display: flex;
            justify-content: center;
            align-items: flex-end;
            padding: 0 100px 60px 100px; /* Increased bottom padding */
            z-index: 2;
            gap: 120px;
            margin-top: auto; /* Pushes footer to bottom */
        }

        .footer-info {
            text-align: center;
            min-width: 220px;
        }

        .footer-text {
            font-size: 13px;
            font-weight: 700;
            color: var(--dark-text);
            border-top: 1.5px solid #cbd5e0;
            padding-top: 8px;
            margin-top: 8px;
            text-transform: uppercase;
        }

        .controls { margin-top: 20px; position: absolute; bottom: 20px; }
        .btn-download {
            background: var(--royal-blue);
            color: white;
            padding: 16px 40px;
            border: none;
            border-radius: 50px;
            font-weight: bold;
            cursor: pointer;
        }

        @media print {
            .controls { display: none; }
            body { background: none; padding: 0; height: auto; }
            .certificate-container { 
                box-shadow: none; 
                border: 15px solid white; 
                width: 297mm; /* Exact A4 Landscape Width */
                height: 210mm; /* Exact A4 Landscape Height */
                margin: 0;
            }
            .footer {
                position: absolute;
                bottom: 60px;
                left: 0;
                right: 0;
            }
        }
    </style>
</head>
<body>

    <div class="certificate-container">
        <div class="corner-accent top-left"></div>
        <div class="corner-accent bottom-right"></div>

        <div class="header">
            <div class="logo">LEARNIFY</div>
            <h1 class="main-title">Certificate of Completion</h1>
        </div>

        <div class="cert-content">
            <p style="font-style: italic; color: #718096; font-size: 15px;">This is to proudly certify that</p>
            <h2 class="recipient-name"><?php echo $fullName; ?></h2>
            <div class="name-line"></div>
            
            <p style="font-style: italic; color: #718096; font-size: 15px;">has successfully completed the curriculum for</p>
            <h3 style="font-weight: 800; font-size: 30px; color: #111; margin: 10px 0;">
Programming in Java
</h3>

            <p class="appreciation-text">
                Recognized for demonstrating excellence in building complex applications and achieving required standards of proficiency. This accomplishment reflects a commitment to learning and mastery of the subject matter on the Learnify platform.
            </p>

            <div style="margin-top: 10px; font-size: 14px; color: var(--royal-blue); font-weight: bold;">
                Passing Score: <?php echo $percentage; ?>% | <?php echo $class; ?>
            </div>
        </div>

        <div class="footer">
            <div class="footer-info">
                <div style="font-size: 14px; color: #718096; margin-bottom: 5px; font-weight: bold;">
                    <?php echo $date; ?>
                </div>
                <div class="footer-text">Date of Issue</div>
            </div>
            
            <div class="medal-box">
                <div class="ribbon"></div>
                <div class="gold-seal">
                    <div class="seal-inner">GOLD</div>
                </div>
            </div>

            <div class="footer-info">
                <div style="font-family: 'Great Vibes', cursive; font-size: 28px; margin-bottom: 5px; color: var(--dark-text);">Team Learnify</div>
                <div class="footer-text">from the team of Learnify</div>
            </div>
        </div>
    </div>

    <div class="controls">
        <button class="btn-download" onclick="window.print()">Download Certificate</button>
    </div>

</body>
</html>