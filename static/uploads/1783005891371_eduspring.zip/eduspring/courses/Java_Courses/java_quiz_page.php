<?php
session_start();
include("../../db.php");

if(!isset($_SESSION['user_id'])){
    header("Location: ../signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$course_id = 2; // ✅ Java course id

$check = $conn->prepare("
SELECT * FROM quiz_results 
WHERE user_id=? AND course_id=? AND passed=1
");

$check->bind_param("ii", $user_id, $course_id);
$check->execute();
$res = $check->get_result();

$already_done = $res->num_rows > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Java Programming Quiz</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #3f51b5;
            --secondary-color: #f44336;
            --success-color: #4caf50;
            --warning-color: #ff9800;
            --danger-color: #f44336;
            --light-color: #f5f5f5;
            --dark-color: #212121;
            --text-color: #333;
            --border-color: #e0e0e0;
            --shadow: 0 2px 10px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 30px rgba(0,0,0,0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* Top Header Bar */
        .top-header {
            background: white;
            padding: 1rem 2rem;
            box-shadow: var(--shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .test-info {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .test-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .test-details {
            display: flex;
            gap: 1.5rem;
            font-size: 0.9rem;
        }

        .test-detail {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #666;
        }

        .test-detail i {
            color: var(--primary-color);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        #timer {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--light-color);
            border-radius: 20px;
            font-weight: bold;
        }

        #timer.warning {
            background: #fff3cd;
            color: #856404;
        }

        #timer.danger {
            background: #f8d7da;
            color: #721c24;
        }

        .help-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform 0.3s;
        }

        .help-btn:hover {
            transform: scale(1.1);
        }

        /* Main Content Area */
        .main-container {
            flex: 1;
            display: flex;
            padding: 2rem;
            gap: 2rem;
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
        }

        /* Question Area */
        .question-area {
            flex: 1;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .question-number {
            font-size: 1.2rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .question-type {
            background: var(--primary-color);
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }

        .question-text {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 2rem;
            color: var(--dark-color);
        }

        .answers-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .answer-option {
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .answer-option:hover {
            border-color: var(--primary-color);
            background: #f8f9ff;
            transform: translateX(5px);
        }

        .answer-option.selected {
            border-color: var(--primary-color);
            background: #e8eaf6;
        }

        .answer-marker {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: var(--light-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: var(--primary-color);
        }

        .answer-option.selected .answer-marker {
            background: var(--primary-color);
            color: white;
        }

        .answer-text {
            flex: 1;
        }

        /* Input Styles */
        .fill-blank-input, .code-input {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            transition: border-color 0.3s;
        }

        .fill-blank-input:focus, .code-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .code-input {
            min-height: 200px;
            font-family: 'Courier New', monospace;
            resize: vertical;
        }

        /* Rearrange Container */
        .rearrange-container {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .rearrange-item {
            padding: 1rem;
            background: var(--light-color);
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 2px solid transparent;
            transition: all 0.3s;
        }

        .rearrange-item:hover {
            border-color: var(--primary-color);
        }

        .rearrange-controls {
            display: flex;
            gap: 0.5rem;
        }

        .rearrange-controls button {
            width: 30px;
            height: 30px;
            border: none;
            background: var(--primary-color);
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .rearrange-controls button:hover:not(:disabled) {
            background: #303f9f;
        }

        .rearrange-controls button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        /* Right Sidebar - Question Navigator */
        .right-sidebar {
            width: 280px;
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow-lg);
            display: flex;
            flex-direction: column;
            height: fit-content;
            position: sticky;
            top: 100px;
        }

        .navigator-title {
            font-size: 1.1rem;
            font-weight: bold;
            margin-bottom: 1rem;
            color: var(--dark-color);
            text-align: center;
        }

        .navigator-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .nav-item {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--light-color);
            border: 2px solid var(--border-color);
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }

        .nav-item:hover {
            border-color: var(--primary-color);
            transform: scale(1.1);
        }

        .nav-item.current {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .nav-item.answered {
            background: var(--success-color);
            color: white;
            border-color: var(--success-color);
        }

        .navigator-legend {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding-top: 1rem;
            border-top: 1px solid var(--border-color);
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        .legend-box {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid var(--border-color);
        }

        .legend-box.current {
            background: var(--primary-color);
            border-color: var(--primary-color);
        }

        .legend-box.answered {
            background: var(--success-color);
            border-color: var(--success-color);
        }

        /* Bottom Navigation */
        .bottom-navigation {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-buttons {
            display: flex;
            gap: 1rem;
        }

        .nav-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-btn.prev {
            background: var(--light-color);
            color: var(--text-color);
        }

        .nav-btn.prev:hover:not(:disabled) {
            background: #e0e0e0;
        }

        .nav-btn.next {
            background: var(--primary-color);
            color: white;
        }

        .nav-btn.next:hover {
            background: #303f9f;
        }

        .nav-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .progress-container {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .progress-bar-container {
            width: 200px;
            height: 8px;
            background: var(--light-color);
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: var(--primary-color);
            transition: width 0.5s;
        }

        .progress-text {
            font-size: 0.9rem;
            color: #666;
        }

        /* Intro Screen */
        .intro-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .intro-card {
            background: white;
            border-radius: 16px;
            padding: 3rem;
            max-width: 600px;
            width: 90%;
            text-align: center;
            box-shadow: var(--shadow-lg);
        }

        .intro-icon {
            font-size: 4rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .intro-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .intro-description {
            color: #666;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .intro-instructions {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            text-align: left;
        }

        .intro-instructions h3 {
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .intro-instructions ul {
            list-style: none;
            padding-left: 0;
        }

        .intro-instructions li {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .intro-instructions li i {
            color: var(--success-color);
        }

        .start-btn {
            padding: 1rem 3rem;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }

        .start-btn:hover {
            background: #303f9f;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(63, 81, 181, 0.3);
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 2rem;
            left: 50%;
            transform: translateX(-50%) translateY(100px);
            background: var(--dark-color);
            color: white;
            padding: 1rem 2rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 1rem;
            opacity: 0;
            transition: all 0.3s;
            z-index: 1000;
        }

        .toast.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
        }

        .toast.success {
            background: var(--success-color);
        }

        .toast.error {
            background: var(--danger-color);
        }

        .toast.info {
            background: var(--primary-color);
        }

        /* Results Section */
        .results-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 3rem;
            box-shadow: var(--shadow-lg);
            text-align: center;
            max-width: 800px;
            margin: 2rem auto;
        }

        .results-icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
        }

        .results-title {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .results-score {
            font-size: 3rem;
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .results-message {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }

        .results-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--light-color);
            padding: 1.5rem;
            border-radius: 8px;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
        }

        .results-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .action-btn {
            padding: 0.8rem 1.5rem;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .action-btn.primary {
            background: var(--primary-color);
            color: white;
        }

        .action-btn.primary:hover {
            background: #303f9f;
        }

        .action-btn.secondary {
            background: var(--light-color);
            color: var(--text-color);
        }

        .action-btn.secondary:hover {
            background: #e0e0e0;
        }

        /* Review Section */
        .review-section {
            display: none;
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: var(--shadow-lg);
            max-width: 1000px;
            margin: 2rem auto;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border-color);
        }

        .review-title {
            font-size: 1.8rem;
            color: var(--dark-color);
        }

        .back-btn {
            padding: 0.6rem 1.2rem;
            background: var(--light-color);
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #e0e0e0;
        }

        .review-container {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .review-question {
            padding: 1.5rem;
            border-radius: 8px;
            border: 2px solid var(--border-color);
        }

        .review-question.correct {
            border-color: var(--success-color);
            background: #f1f8e9;
        }

        .review-question.incorrect {
            border-color: var(--danger-color);
            background: #ffebee;
        }

        .review-question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .review-question-number {
            font-weight: bold;
            color: var(--dark-color);
        }

        .review-status {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .review-status.correct {
            background: var(--success-color);
            color: white;
        }

        .review-status.incorrect {
            background: var(--danger-color);
            color: white;
        }

        .review-explanation {
            margin-top: 1rem;
            padding: 1rem;
            background: white;
            border-radius: 6px;
            border-left: 4px solid var(--primary-color);
        }

        .review-explanation-title {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .main-container {
                flex-direction: column;
            }

            .right-sidebar {
                width: 100%;
                position: static;
            }

            .navigator-grid {
                grid-template-columns: repeat(10, 1fr);
            }
        }

        @media (max-width: 768px) {
            .top-header {
                flex-direction: column;
                gap: 1rem;
            }

            .test-details {
                flex-direction: column;
                gap: 0.5rem;
            }

            .navigator-grid {
                grid-template-columns: repeat(8, 1fr);
            }

            .results-stats {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 480px) {
            .navigator-grid {
                grid-template-columns: repeat(6, 1fr);
            }

            .progress-bar-container {
                width: 100px;
            }

            .nav-buttons {
                flex-direction: column;
                width: 100%;
            }

            .nav-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
<?php if($already_done): ?>
<script>
alert("You already completed this quiz!");
window.location.href = "java_final_page.php";
</script>
<?php endif; ?>
</head>
<body>
    <!-- Top Header Bar -->
    <header class="top-header">
        <div class="test-info">
            <h1 class="test-title">Java Programming Quiz</h1>
            <div class="test-details">
                <div class="test-detail">
                    <i class="fas fa-question-circle"></i>
                    <span>50 Questions</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-clock"></i>
                    <span>90 Minutes</span>
                </div>
                <div class="test-detail">
                    <i class="fas fa-percentage"></i>
                    <span>70% to Pass</span>
                </div>
            </div>
        </div>
        <div class="header-actions">
            <div id="timer">
                <i class="fas fa-hourglass-half"></i>
                <span id="timerText">90:00</span>
            </div>
            <button class="help-btn" onclick="showHelp()">
                <i class="fas fa-question"></i>
            </button>
        </div>
    </header>

    <!-- Main Container -->
    <div class="main-container">
        <!-- Question Area -->
        <div class="question-area">
            <div class="question-header">
                <div class="question-number" id="questionNumber">Question 1</div>
                <div class="question-type" id="questionType">Multiple Choice</div>
            </div>
            <div class="question-text" id="questionText">
                Loading question...
            </div>
            <div class="answers-container" id="answersContainer">
                <!-- Answers will be loaded here -->
            </div>
        </div>

        <!-- Right Sidebar - Question Navigator -->
        <aside class="right-sidebar">
            <div class="navigator-title">Question Navigator</div>
            <div class="navigator-grid" id="navigatorGrid">
                <!-- Question numbers will be generated here -->
            </div>
            <div class="navigator-legend">
                <div class="legend-item">
                    <div class="legend-box"></div>
                    <span>Not Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box answered"></div>
                    <span>Answered</span>
                </div>
                <div class="legend-item">
                    <div class="legend-box current"></div>
                    <span>Current</span>
                </div>
            </div>
        </aside>
    </div>

    <!-- Bottom Navigation -->
    <footer class="bottom-navigation">
        <div class="nav-buttons">
            <button class="nav-btn prev" id="prevBtn" onclick="previousQuestion()">
                <i class="fas fa-arrow-left"></i>
                Previous
            </button>
            <button class="nav-btn next" id="nextBtn" onclick="nextQuestion()">
                Next
                <i class="fas fa-arrow-right"></i>
            </button>
        </div>
        <div class="progress-container">
            <div class="progress-bar-container">
                <div class="progress-bar" id="progressBar" style="width: 2%"></div>
            </div>
            <div class="progress-text" id="progressText">Question 1 of 50</div>
        </div>
    </footer>

    <!-- Intro Screen -->
    <div class="intro-screen" id="introScreen">
        <div class="intro-card">
            <div class="intro-icon">
                <i class="fas fa-code"></i>
            </div>
            <h2 class="intro-title">Java Programming Quiz</h2>
            <p class="intro-description">
                Test your knowledge of Java programming with this comprehensive quiz covering 
                core concepts, OOP, collections, and more.
            </p>
            <div class="intro-instructions">
                <h3>Instructions:</h3>
                <ul>
                    <li><i class="fas fa-check"></i> You have 90 minutes to complete 50 questions</li>
                    <li><i class="fas fa-check"></i> Minimum 70% score required to pass</li>
                    <li><i class="fas fa-check"></i> Questions include multiple choice, true/false, fill in the blank, code writing, and rearrange</li>
                    <li><i class="fas fa-check"></i> Use the question navigator on the right to jump between questions</li>
                    <li><i class="fas fa-check"></i> Your progress is automatically saved</li>
                    <li><i class="fas fa-check"></i> Stay on this page - leaving may result in automatic submission</li>
                </ul>
            </div>
            <button class="start-btn" onclick="startQuiz()">
                Start Quiz
            </button>
        </div>
    </div>

    <!-- Results Section -->
    <div class="results-section" id="resultsSection">
        <div class="results-icon" id="resultsIcon">
            <i class="fas fa-trophy"></i>
        </div>
        <h2 class="results-title" id="resultsTitle">Quiz Completed!</h2>
        <div class="results-score" id="resultsScore">85%</div>
        <p class="results-message" id="resultsMessage">Great job! You've passed the quiz!</p>
        
        <div class="results-stats">
            <div class="stat-card">
                <div class="stat-label">Correct Answers</div>
                <div class="stat-value" id="correctAnswers">42</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Incorrect Answers</div>
                <div class="stat-value" id="incorrectAnswers">8</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Time Taken</div>
                <div class="stat-value" id="timeTaken">45:32</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Accuracy</div>
                <div class="stat-value" id="accuracy">84%</div>
            </div>
        </div>
        
        <div class="results-actions">
            <button class="action-btn primary" onclick="reviewAnswers()">
                <i class="fas fa-eye"></i>
                Review Answers
            </button>
            <button class="action-btn secondary" onclick="retakeQuiz()">
                <i class="fas fa-redo"></i>
                Retake Quiz
            </button>
            <button class="action-btn secondary" onclick="downloadCertificate()">
                <i class="fas fa-download"></i>
                Download Certificate
            </button>
            <button class="action-btn secondary" onclick="shareResults()">
                <i class="fas fa-share"></i>
                Share Results
            </button>
        </div>
    </div>

    <!-- Review Section -->
    <div class="review-section" id="reviewSection">
        <div class="review-header">
            <h2 class="review-title">Answer Review</h2>
            <button class="back-btn" onclick="backToResults()">
                <i class="fas fa-arrow-left"></i>
                Back to Results
            </button>
        </div>
        <div class="review-container" id="reviewContainer">
            <!-- Review items will be generated here -->
        </div>
    </div>

    <!-- Toast Notification -->
    <div class="toast" id="toast">
        <i class="toast-icon fas fa-info-circle"></i>
        <span id="toastMessage">Notification message</span>
    </div>

    <script>
        // Quiz Data
        const quizData = [
            {
                id: 1,
                type: 'multiple',
                question: 'What is the default value of a boolean variable in Java?',
                options: ['true', 'false', 'null', '0'],
                correct: 1,
                explanation: 'The default value for a boolean variable in Java is false.'
            },
            {
                id: 2,
                type: 'multiple',
                question: 'Which of the following is not a Java keyword?',
                options: ['goto', 'const', 'volatile', 'String'],
                correct: 3,
                explanation: 'String is not a keyword in Java, it\'s a class. goto and const are reserved keywords but not used.'
            },
            {
                id: 3,
                type: 'truefalse',
                question: 'Java is a platform-independent language.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Java is platform-independent due to its "Write Once, Run Anywhere" (WORA) capability through the JVM.'
            },
            {
                id: 4,
                type: 'multiple',
                question: 'Which method must be implemented by all threads?',
                options: ['start()', 'run()', 'stop()', 'main()'],
                correct: 1,
                explanation: 'The run() method must be implemented by all threads. It contains the code that constitutes the new thread.'
            },
            {
                id: 5,
                type: 'multiple',
                question: 'What is the size of an int in Java?',
                options: ['8 bits', '16 bits', '32 bits', '64 bits'],
                correct: 2,
                explanation: 'An int in Java is 32 bits (4 bytes) in size, regardless of the platform.'
            },
            {
                id: 6,
                type: 'fillblank',
                question: 'The ______ keyword is used to declare a constant variable in Java.',
                correct: 'final',
                explanation: 'The final keyword is used to declare constants. Once assigned, their value cannot be changed.'
            },
            {
                id: 7,
                type: 'multiple',
                question: 'What is the purpose of the "final" keyword in Java?',
                options: [
                    'To mark a method as abstract',
                    'To prevent inheritance/class extension',
                    'To indicate a method is synchronized',
                    'To create a static method'
                ],
                correct: 1,
                explanation: 'The "final" keyword prevents inheritance when applied to a class, method overriding when applied to a method, and value changes when applied to a variable.'
            },
            {
                id: 8,
                type: 'multiple',
                question: 'Which collection class does not allow duplicate elements?',
                options: ['ArrayList', 'LinkedList', 'HashSet', 'Vector'],
                correct: 2,
                explanation: 'HashSet does not allow duplicate elements, as it implements the Set interface.'
            },
            {
                id: 9,
                type: 'multiple',
                question: 'What is the output of: System.out.println(10 % 3);',
                options: ['3', '1', '0', '3.33'],
                correct: 1,
                explanation: 'The % operator is the modulo operator. 10 % 3 = 1 (remainder of 10 divided by 3).'
            },
            {
                id: 10,
                type: 'multiple',
                question: 'Which exception is thrown when dividing by zero with integers?',
                options: ['ArithmeticException', 'NullPointerException', 'NumberFormatException', 'IOException'],
                correct: 0,
                explanation: 'ArithmeticException is thrown when attempting to divide an integer by zero.'
            },
            {
                id: 11,
                type: 'truefalse',
                question: 'Java supports multiple inheritance through classes.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Java does not support multiple inheritance through classes to avoid the "diamond problem". It supports multiple inheritance through interfaces.'
            },
            {
                id: 12,
                type: 'truefalse',
                question: 'The "abstract" keyword can be used with variables.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'The "abstract" keyword can only be used with classes and methods, not variables.'
            },
            {
                id: 13,
                type: 'truefalse',
                question: 'A Java constructor can have a return type.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Constructors do not have return types, not even void.'
            },
            {
                id: 14,
                type: 'truefalse',
                question: 'Static methods can access instance variables directly.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Static methods cannot access instance variables directly; they need an object reference.'
            },
            {
                id: 15,
                type: 'fillblank',
                question: 'Complete the code: public class Test extends ______ implements Runnable',
                correct: 'Object',
                explanation: 'All classes in Java implicitly extend Object if no other parent class is specified.'
            },
            {
                id: 16,
                type: 'fillblank',
                question: 'The ______ keyword is used to refer to the current object instance.',
                correct: 'this',
                explanation: 'The "this" keyword refers to the current object instance within a method or constructor.'
            },
            {
                id: 17,
                type: 'fillblank',
                question: 'Java uses ______ pass-by-value for all parameters.',
                correct: 'strictly',
                explanation: 'Java uses strictly pass-by-value. For objects, the reference value is passed.'
            },
            {
                id: 18,
                type: 'code',
                question: 'Write a Java method that checks if a number is prime.',
                correct: 'public static boolean isPrime(int n) { if (n <= 1) return false; for (int i = 2; i <= Math.sqrt(n); i++) { if (n % i == 0) return false; } return true; }',
                explanation: 'A prime number is only divisible by 1 and itself. We check divisibility up to sqrt(n) for efficiency.'
            },
            {
                id: 19,
                type: 'code',
                question: 'Write code to reverse a string without using built-in reverse functions.',
                correct: 'public static String reverseString(String str) { String reversed = ""; for (int i = str.length() - 1; i >= 0; i--) { reversed += str.charAt(i); } return reversed; }',
                explanation: 'We iterate from the end of the string to the beginning, building a new string.'
            },
            {
                id: 20,
                type: 'multiple',
                question: 'Which Java version introduced lambda expressions?',
                options: ['Java 7', 'Java 8', 'Java 9', 'Java 10'],
                correct: 1,
                explanation: 'Lambda expressions were introduced in Java 8 as part of Project Lambda.'
            },
            {
                id: 21,
                type: 'rearrange',
                question: 'Rearrange the following exception classes from most general (top) to most specific (bottom):',
                options: ['NullPointerException', 'Exception', 'RuntimeException', 'Throwable'],
                correct: ['Throwable', 'Exception', 'RuntimeException', 'NullPointerException'],
                explanation: 'Throwable is the root. Exception inherits from Throwable. RuntimeException inherits from Exception. NullPointerException inherits from RuntimeException.'
            },
            {
                id: 22,
                type: 'rearrange',
                question: 'Rearrange the collection interfaces in their correct hierarchy (top = root, bottom = leaf):',
                options: ['ArrayList', 'Iterable', 'Collection', 'List'],
                correct: ['Iterable', 'Collection', 'List', 'ArrayList'],
                explanation: 'Iterable is the root. Collection extends Iterable. List extends Collection. ArrayList implements List.'
            },
            {
                id: 23,
                type: 'multiple',
                question: 'Which keyword is used to handle exceptions in Java?',
                options: ['try-catch', 'handle', 'exception', 'resolve'],
                correct: 0,
                explanation: 'The try-catch block is used to handle exceptions in Java.'
            },
            {
                id: 24,
                type: 'truefalse',
                question: 'String objects in Java are stored in the String Pool.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'String literals are stored in a special memory area known as the String Pool.'
            },
            {
                id: 25,
                type: 'fillblank',
                question: 'The ______ interface provides a total ordering on some collection of objects. All elements in the collection must mutually implement this interface.',
                correct: 'Comparable',
                explanation: 'The Comparable interface is used to define the natural ordering of objects.'
            },
            {
                id: 26,
                type: 'multiple',
                question: 'Which of the following is NOT a core component of JDBC?',
                options: ['Connection', 'Statement', 'ResultSet', 'DatabaseContext'],
                correct: 3,
                explanation: 'DatabaseContext is not a standard JDBC component. Connection, Statement, and ResultSet are core components.'
            },
            {
                id: 27,
                type: 'truefalse',
                question: 'Garbage Collection in Java is guaranteed to run at a specific predictable time.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'Garbage Collection is automatic, but its execution time is not predictable or guaranteed.'
            },
            {
                id: 28,
                type: 'multiple',
                question: 'What design pattern restricts a class to have only one instance?',
                options: ['Factory', 'Singleton', 'Observer', 'Decorator'],
                correct: 1,
                explanation: 'The Singleton pattern restricts the instantiation of a class to a single object.'
            },
            {
                id: 29,
                type: 'fillblank',
                question: 'A ______ block is always executed whether an exception is handled or not.',
                correct: 'finally',
                explanation: 'The finally block contains crucial cleanup code and always runs after try/catch.'
            },
            {
                id: 30,
                type: 'code',
                question: 'Write a basic Singleton class declaration in Java.',
                correct: 'public class Singleton { private static Singleton instance; private Singleton() {} public static Singleton getInstance() { if (instance == null) instance = new Singleton(); return instance; } }',
                explanation: 'A Singleton needs a private constructor, a static instance variable, and a public static getter method.'
            },
            {
                id: 31,
                type: 'rearrange',
                question: 'Order the Maven build lifecycle phases from first to last:',
                options: ['package', 'compile', 'deploy', 'test', 'validate'],
                correct: ['validate', 'compile', 'test', 'package', 'deploy'],
                explanation: 'The standard Maven lifecycle order is validate, compile, test, package, verify, install, deploy.'
            },
            {
                id: 32,
                type: 'multiple',
                question: 'Which interface in the java.util.function package accepts an argument and produces no result?',
                options: ['Supplier', 'Predicate', 'Consumer', 'Function'],
                correct: 2,
                explanation: 'Consumer<T> represents an operation that accepts a single input argument and returns no result.'
            },
            {
                id: 33,
                type: 'truefalse',
                question: 'Java interfaces can contain private methods since Java 9.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Java 9 introduced private methods and private static methods in interfaces to share code between default methods.'
            },
            {
                id: 34,
                type: 'fillblank',
                question: 'The keyword ______ is used to call a parent class constructor.',
                correct: 'super',
                explanation: 'super() is used inside a child class constructor to invoke the parent class constructor.'
            },
            {
                id: 35,
                type: 'multiple',
                question: 'Which Spring annotation is used to inject dependencies automatically?',
                options: ['@Inject', '@Bean', '@Autowired', '@Component'],
                correct: 2,
                explanation: '@Autowired is the primary annotation in Spring for dependency injection.'
            },
            {
                id: 36,
                type: 'truefalse',
                question: 'ArrayList is thread-safe by default.',
                options: ['True', 'False'],
                correct: 1,
                explanation: 'ArrayList is not synchronized. Vector is the thread-safe equivalent, or Collections.synchronizedList can be used.'
            },
            {
                id: 37,
                type: 'rearrange',
                question: 'Order the following variable scopes from most restrictive to least restrictive:',
                options: ['Protected', 'Public', 'Private', 'Default (Package-private)'],
                correct: ['Private', 'Default (Package-private)', 'Protected', 'Public'],
                explanation: 'Private is only within the class. Default is package. Protected is package + subclasses. Public is everywhere.'
            },
            {
                id: 38,
                type: 'multiple',
                question: 'What is the return type of the hashCode() method?',
                options: ['long', 'int', 'String', 'Object'],
                correct: 1,
                explanation: 'hashCode() returns an integer (int) value representing the hash code of the object.'
            },
            {
                id: 39,
                type: 'fillblank',
                question: 'Java 8 streams are ______ evaluated, meaning computation is deferred until a terminal operation is invoked.',
                correct: 'lazily',
                explanation: 'Streams use lazy evaluation to optimize operations, processing elements only when a terminal operation demands it.'
            },
            {
                id: 40,
                type: 'multiple',
                question: 'Which of the following is NOT a valid Java comment style?',
                options: ['// comment', '/* comment */', '/** comment */', '<!-- comment -->'],
                correct: 3,
                explanation: '<!-- comment --> is an HTML/XML comment, not valid in Java.'
            },
            {
                id: 41,
                type: 'truefalse',
                question: 'You can catch multiple exceptions in a single catch block in Java 7+.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'Java 7 introduced the multi-catch feature: catch (IOException | SQLException e).'
            },
            {
                id: 42,
                type: 'rearrange',
                question: 'Order the steps for a basic JDBC database connection:',
                options: ['Execute query', 'Load driver (optional in newer JDBC)', 'Establish Connection', 'Process ResultSet', 'Create Statement'],
                correct: ['Load driver (optional in newer JDBC)', 'Establish Connection', 'Create Statement', 'Execute query', 'Process ResultSet'],
                explanation: 'Load driver -> Get connection -> Create statement -> Execute query -> Process ResultSet.'
            },
            {
                id: 43,
                type: 'fillblank',
                question: 'The ______ class in java.lang is the root of the class hierarchy.',
                correct: 'Object',
                explanation: 'Every class in Java has Object as a superclass.'
            },
            {
                id: 44,
                type: 'multiple',
                question: 'Which collection should you use if you want a queue that orders elements based on their natural ordering?',
                options: ['LinkedList', 'PriorityQueue', 'ArrayDeque', 'Stack'],
                correct: 1,
                explanation: 'PriorityQueue orders elements according to their natural ordering or a specified Comparator.'
            },
            {
                id: 45,
                type: 'truefalse',
                question: 'An interface can extend multiple interfaces.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'While classes can only extend one class, an interface can extend multiple interfaces using a comma-separated list.'
            },
            {
                id: 46,
                type: 'multiple',
                question: 'Which of the following creates a thread pool that reuses a fixed number of threads?',
                options: ['Executors.newFixedThreadPool(n)', 'Executors.newCachedThreadPool()', 'Executors.newSingleThreadExecutor()', 'Executors.newScheduledThreadPool(n)'],
                correct: 0,
                explanation: 'Executors.newFixedThreadPool(n) creates a thread pool that reuses a fixed number of threads operating off a shared unbounded queue.'
            },
            {
                id: 47,
                type: 'fillblank',
                question: 'To define a constant variable, use the keywords static and ______. (Enter one word)',
                correct: 'final',
                explanation: 'Constants in Java are typically defined using public static final.'
            },
            {
                id: 48,
                type: 'multiple',
                question: 'Which of the following statements about JPA is true?',
                options: ['JPA is a specific ORM implementation', 'JPA is an application server', 'JPA is a specification for ORM in Java', 'JPA replaces SQL entirely'],
                correct: 2,
                explanation: 'JPA (Java Persistence API) is a specification. Hibernate is a popular implementation of this specification.'
            },
            {
                id: 49,
                type: 'truefalse',
                question: 'The == operator compares object references, not object content, for non-primitive types.',
                options: ['True', 'False'],
                correct: 0,
                explanation: 'For objects, == checks if they refer to the exact same memory location. .equals() should be used for value equality.'
            },
            {
                id: 50,
                type: 'code',
                question: 'Write a lambda expression that takes an Integer x and returns its square.',
                correct: 'x -> x * x',
                explanation: 'A simple lambda expression omitting type declaration and return keyword for a single expression.'
            }
        ];

        // Quiz State
        let currentQuestion = 0;
        let userAnswers = {};
        let startTime = Date.now();
        let timerInterval;
        let timeRemaining = 90 * 60; // 90 minutes in seconds
        let quizCompleted = false;
        let isQuizStarted = false;
        let warningsCount = 0;
        const MAX_WARNINGS = 3;

        // Start Quiz
        function startQuiz() {
            document.getElementById('introScreen').style.display = 'none';
            isQuizStarted = true;
            initQuiz();
            startTimer();
        }

        // Initialize Quiz
        function initQuiz() {
            renderQuestion();
            renderNavigator();
            updateProgress();
        }

        // Render Question
        function renderQuestion() {
            const question = quizData[currentQuestion];
            
            // Update question info
            document.getElementById('questionNumber').textContent = `Question ${currentQuestion + 1}`;
            document.getElementById('questionType').textContent = getQuestionTypeText(question.type);
            document.getElementById('questionText').textContent = question.question;
            
            // Render answers based on question type
            const answersContainer = document.getElementById('answersContainer');
            answersContainer.innerHTML = '';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                question.options.forEach((option, index) => {
                    const answerOption = document.createElement('div');
                    answerOption.className = 'answer-option';
                    answerOption.onclick = () => selectAnswer(index);
                    
                    const isCorrect = userAnswers[question.id] === index;
                    if (isCorrect) {
                        answerOption.classList.add('selected');
                    }
                    
                    answerOption.innerHTML = `
                        <div class="answer-marker">${String.fromCharCode(65 + index)}</div>
                        <div class="answer-text">${option}</div>
                    `;
                    
                    answersContainer.appendChild(answerOption);
                });
            } else if (question.type === 'fillblank') {
                const input = document.createElement('input');
                input.type = 'text';
                input.className = 'fill-blank-input';
                input.placeholder = 'Type your answer here...';
                input.value = userAnswers[question.id] || '';
                input.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Answer saved!', 'success');
                };
                answersContainer.appendChild(input);
            } else if (question.type === 'code') {
                const textarea = document.createElement('textarea');
                textarea.className = 'code-input';
                textarea.placeholder = 'Write your code here...';
                textarea.value = userAnswers[question.id] || '';
                textarea.oninput = (e) => {
                    userAnswers[question.id] = e.target.value;
                    showToast('Code saved!', 'success');
                };
                answersContainer.appendChild(textarea);
            } else if (question.type === 'rearrange') {
                const container = document.createElement('div');
                container.className = 'rearrange-container';
                
                // Initialize user answer if not present
                if (!userAnswers[question.id]) {
                    userAnswers[question.id] = [...question.options];
                }
                
                const currentOrder = userAnswers[question.id];
                
                currentOrder.forEach((item, index) => {
                    const div = document.createElement('div');
                    div.className = 'rearrange-item';
                    div.innerHTML = `
                        <div class="rearrange-text">${item}</div>
                        <div class="rearrange-controls">
                            <button onclick="moveItem(${question.id}, ${index}, -1)" ${index === 0 ? 'disabled' : ''} title="Move Up"><i class="fas fa-chevron-up"></i></button>
                            <button onclick="moveItem(${question.id}, ${index}, 1)" ${index === currentOrder.length - 1 ? 'disabled' : ''} title="Move Down"><i class="fas fa-chevron-down"></i></button>
                        </div>
                    `;
                    container.appendChild(div);
                });
                answersContainer.appendChild(container);
            }
            
            // Update navigation buttons
            updateNavigationButtons();
        }

        // Get Question Type Text
        function getQuestionTypeText(type) {
            const types = {
                'multiple': 'Multiple Choice',
                'truefalse': 'True/False',
                'fillblank': 'Fill in the Blank',
                'code': 'Code Writing',
                'rearrange': 'Rearrange the Order'
            };
            return types[type] || 'Question';
        }

        // Select Answer
        function selectAnswer(index) {
            const question = quizData[currentQuestion];
            userAnswers[question.id] = index;
            
            // Update UI
            const answerOptions = document.querySelectorAll('.answer-option');
            answerOptions.forEach((option, i) => {
                option.classList.remove('selected');
                if (i === index) {
                    option.classList.add('selected');
                }
            });
            
            showToast('Answer selected!', 'success');
            updateNavigator();
        }

        // Move item for rearrange questions
        function moveItem(questionId, index, direction) {
            const arr = userAnswers[questionId];
            const temp = arr[index];
            arr[index] = arr[index + direction];
            arr[index + direction] = temp;
            renderQuestion();
            updateNavigator();
        }

        // Next Question
        function nextQuestion() {
            if (currentQuestion < quizData.length - 1) {
                currentQuestion++;
                renderQuestion();
                updateNavigator();
                updateProgress();
            } else {
                finishQuiz();
            }
        }

        // Previous Question
        function previousQuestion() {
            if (currentQuestion > 0) {
                currentQuestion--;
                renderQuestion();
                updateNavigator();
                updateProgress();
            }
        }

        // Update Navigation Buttons
        function updateNavigationButtons() {
            const prevBtn = document.getElementById('prevBtn');
            const nextBtn = document.getElementById('nextBtn');
            
            prevBtn.disabled = currentQuestion === 0;
            
            if (currentQuestion === quizData.length - 1) {
                nextBtn.innerHTML = '<i class="fas fa-flag-checkered"></i> Finish';
            } else {
                nextBtn.innerHTML = 'Next <i class="fas fa-arrow-right"></i>';
            }
        }

        // Update Progress
        function updateProgress() {
            const progress = ((currentQuestion + 1) / quizData.length) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressText').textContent = 
                `Question ${currentQuestion + 1} of ${quizData.length}`;
        }

        // Render Navigator
        function renderNavigator() {
            const navigatorGrid = document.getElementById('navigatorGrid');
            navigatorGrid.innerHTML = '';
            
            for (let i = 0; i < quizData.length; i++) {
                const navItem = document.createElement('div');
                navItem.className = 'nav-item';
                navItem.textContent = i + 1;
                
                if (i === currentQuestion) {
                    navItem.classList.add('current');
                }
                
                if (userAnswers[quizData[i].id] !== undefined) {
                    navItem.classList.add('answered');
                }
                
                navItem.onclick = () => goToQuestion(i);
                navigatorGrid.appendChild(navItem);
            }
        }

        // Update Navigator
        function updateNavigator() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach((item, index) => {
                item.classList.remove('current');
                if (index === currentQuestion) {
                    item.classList.add('current');
                }
                
                if (userAnswers[quizData[index].id] !== undefined) {
                    item.classList.add('answered');
                }
            });
        }

        // Go to Question
        function goToQuestion(index) {
            currentQuestion = index;
            renderQuestion();
            updateNavigator();
            updateProgress();
        }

        // Start Timer
        function startTimer() {
            timerInterval = setInterval(() => {
                timeRemaining--;
                updateTimerDisplay();
                
                if (timeRemaining <= 0) {
                    clearInterval(timerInterval);
                    finishQuiz();
                }
            }, 1000);
        }

        // Update Timer Display
        function updateTimerDisplay() {
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            const timerText = document.getElementById('timerText');
            const timer = document.getElementById('timer');
            
            timerText.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeRemaining <= 300) { // 5 minutes
                timer.classList.add('warning');
            }
            
            if (timeRemaining <= 60) { // 1 minute
                timer.classList.remove('warning');
                timer.classList.add('danger');
            }
        }

        // Finish Quiz
function finishQuiz() {
    if (quizCompleted) return;
    quizCompleted = true;

    clearInterval(timerInterval);

    const results = calculateResults();

    localStorage.setItem("quizSubmitted", "true");

    fetch('../../save_quiz.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            course_slug: "java",
            answers: userAnswers,                 // ✅ FIX
            score: results.correct,              // ✅ FIX
            total: results.total,                // ✅ FIX
            percentage: results.percentage,      // ✅ FIX
            passed: results.passed ? 1 : 0
        })
    })
    .then(res => res.text())
    .then(data => {
        console.log("SERVER RESPONSE:", data);
    })
    .catch(err => {
        console.log("Fetch error:", err);
    });

    // UI hide
    document.querySelector('.main-container').style.display = 'none';
    document.querySelector('.bottom-navigation').style.display = 'none';
    document.querySelector('.top-header').style.display = 'none';

    showResults(results);
}

        // Calculate Results
        function calculateResults() {
            let correct = 0;
            let total = quizData.length;
            
            quizData.forEach(question => {
                const userAnswer = userAnswers[question.id];
                
                if (question.type === 'multiple' || question.type === 'truefalse') {
                    if (userAnswer === question.correct) {
                        correct++;
                    }
                } else if (question.type === 'fillblank') {
                    if (userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase()) {
                        correct++;
                    }
                } else if (question.type === 'code') {
                    if (userAnswer && userAnswer.length > 10) {
                        correct++;
                    }
                } else if (question.type === 'rearrange') {
                    if (userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct)) {
                        correct++;
                    }
                }
            });
            
            const percentage = Math.round((correct / total) * 100);
            const timeTaken = Math.floor((Date.now() - startTime) / 1000);
            
            return {
                correct,
                incorrect: total - correct,
                total,
                percentage,
                timeTaken,
                passed: percentage >= 70
            };
        }

        // Show Results
        function showResults(results) {
            document.getElementById('resultsSection').style.display = 'block';
            
            // Update results UI
            const resultsIcon = document.getElementById('resultsIcon');
            const resultsTitle = document.getElementById('resultsTitle');
            const resultsScore = document.getElementById('resultsScore');
            const resultsMessage = document.getElementById('resultsMessage');
            
            if (results.percentage >= 90) {
                resultsIcon.innerHTML = '<i class="fas fa-trophy" style="color: #4caf50;"></i>';
                resultsTitle.textContent = 'Excellent!';
                resultsMessage.textContent = 'Outstanding performance! You\'re a Java expert!';
            } else if (results.percentage >= 70) {
                resultsIcon.innerHTML = '<i class="fas fa-star" style="color: #ff9800;"></i>';
                resultsTitle.textContent = 'Well Done!';
                resultsMessage.textContent = 'Great job! You\'ve passed the quiz!';
            } else {
                resultsIcon.innerHTML = '<i class="fas fa-redo" style="color: #f44336;"></i>';
                resultsTitle.textContent = 'Keep Practicing!';
                resultsMessage.textContent = 'You didn\'t pass this time, but don\'t give up!';
            }
            
            resultsScore.textContent = results.percentage + '%';

const certBtn = document.querySelector('button[onclick="downloadCertificate()"]');

if (results.passed) {
    certBtn.disabled = false;
} else {
    certBtn.disabled = true;
}
            
            // Update stats
            document.getElementById('correctAnswers').textContent = results.correct;
            document.getElementById('incorrectAnswers').textContent = results.incorrect;
            document.getElementById('timeTaken').textContent = formatTime(results.timeTaken);
            document.getElementById('accuracy').textContent = results.percentage + '%';
        }

        // Format Time
        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const secs = seconds % 60;
            return `${minutes}:${secs.toString().padStart(2, '0')}`;
        }

        // Review Answers
        function reviewAnswers() {
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'block';
            
            const reviewContainer = document.getElementById('reviewContainer');
            reviewContainer.innerHTML = '';
            
            quizData.forEach((question, index) => {
                const userAnswer = userAnswers[question.id];
                const isCorrect = checkAnswer(question, userAnswer);
                
                const reviewItem = document.createElement('div');
                reviewItem.className = `review-question ${isCorrect ? 'correct' : 'incorrect'}`;
                
                reviewItem.innerHTML = `
                    <div class="review-question-header">
                        <div class="review-question-number">Question ${index + 1}</div>
                        <div class="review-status ${isCorrect ? 'correct' : 'incorrect'}">
                            <i class="fas fa-${isCorrect ? 'check' : 'times'}"></i>
                            ${isCorrect ? 'Correct' : 'Incorrect'}
                        </div>
                    </div>
                    <p style="margin-bottom: 1rem;">${question.question}</p>
                    <div style="margin-bottom: 1rem;">
                        <strong>Your answer:</strong> ${formatUserAnswer(question, userAnswer)}
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <strong>Correct answer:</strong> ${formatCorrectAnswer(question)}
                    </div>
                    <div class="review-explanation">
                        <div class="review-explanation-title">Explanation</div>
                        ${question.explanation}
                    </div>
                `;
                
                reviewContainer.appendChild(reviewItem);
            });
        }

        // Check Answer
        function checkAnswer(question, userAnswer) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return userAnswer === question.correct;
            } else if (question.type === 'fillblank') {
                return userAnswer && userAnswer.toLowerCase().trim() === question.correct.toLowerCase();
            } else if (question.type === 'code') {
                return userAnswer && userAnswer.length > 10;
            } else if (question.type === 'rearrange') {
                return userAnswer && JSON.stringify(userAnswer) === JSON.stringify(question.correct);
            }
            return false;
        }

        // Format User Answer
        function formatUserAnswer(question, userAnswer) {
            if (!userAnswer) return 'Not answered';
            
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[userAnswer] || 'Invalid answer';
            } else if (question.type === 'fillblank') {
                return userAnswer;
            } else if (question.type === 'code') {
                return '<code>' + userAnswer.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + (userAnswer.length > 100 ? '...' : '') + '</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + userAnswer.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return userAnswer;
        }

        // Format Correct Answer
        function formatCorrectAnswer(question) {
            if (question.type === 'multiple' || question.type === 'truefalse') {
                return question.options[question.correct];
            } else if (question.type === 'fillblank') {
                return question.correct;
            } else if (question.type === 'code') {
                return '<code>' + question.correct.substring(0, 100).replace(/</g, '&lt;').replace(/>/g, '&gt;') + '...</code>';
            } else if (question.type === 'rearrange') {
                return '<ol style="margin-left: 20px;">' + question.correct.map(i => `<li>${i}</li>`).join('') + '</ol>';
            }
            return question.correct;
        }

        // Back to Results
        function backToResults() {
            document.getElementById('reviewSection').style.display = 'none';
            document.getElementById('resultsSection').style.display = 'block';
        }

        // Retake Quiz
        function retakeQuiz() {
            // Reset state
            currentQuestion = 0;
            userAnswers = {};
            startTime = Date.now();
            timeRemaining = 90 * 60;
            quizCompleted = false;
            warningsCount = 0;
            
            // Reset UI
            document.getElementById('resultsSection').style.display = 'none';
            document.getElementById('reviewSection').style.display = 'none';
            document.querySelector('.main-container').style.display = 'flex';
            document.querySelector('.bottom-navigation').style.display = 'flex';
            document.querySelector('.top-header').style.display = 'flex';
            
            // Restart
            initQuiz();
            startTimer();
        }

        // Download Certificate
function downloadCertificate() {
    window.location.href = "certificate_java.php?course=java";
}

        // Share Results
        function shareResults() {
            const results = calculateResults();
            const text = `I scored ${results.percentage}% on the Java Programming Quiz! 🎉`;
            
            if (navigator.share) {
                navigator.share({
                    title: 'Java Quiz Results',
                    text: text,
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(text);
                showToast('Results copied to clipboard!', 'success');
            }
        }

        // Show Help
        function showHelp() {
            showToast('Use the question navigator on the right to jump between questions. You have 90 minutes to complete the quiz.', 'info');
        }

        // Show Toast
        function showToast(message, type = 'info') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            const toastIcon = toast.querySelector('.toast-icon i');
            
            toastMessage.textContent = message;
            toast.className = `toast ${type} show`;
            
            // Update icon
            if (type === 'success') {
                toastIcon.className = 'fas fa-check-circle';
            } else if (type === 'error') {
                toastIcon.className = 'fas fa-times-circle';
            } else {
                toastIcon.className = 'fas fa-info-circle';
            }
            
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Prevent accidental page refresh
        window.addEventListener('beforeunload', function(e) {
            if (!quizCompleted && isQuizStarted && Object.keys(userAnswers).length > 0) {
                e.preventDefault();
                e.returnValue = 'Your quiz progress will be lost. Are you sure you want to leave?';
            }
        });

        // Handle visibility change for anti-cheat
        document.addEventListener("visibilitychange", () => {
            if (document.hidden && isQuizStarted && !quizCompleted) {
                warningsCount++;
                if (warningsCount >= MAX_WARNINGS) {
                    alert(`Warning ${warningsCount}/${MAX_WARNINGS}: Tab switch detected!\n\nMaximum warnings reached. The quiz will now be submitted automatically.`);
                    finishQuiz();
                } else {
                    alert(`Warning ${warningsCount}/${MAX_WARNINGS}: Tab switch detected!\n\nPlease stay on this page. Your quiz will be submitted if you leave again.`);
                }
            }
        });
    </script>
</body>
</html>