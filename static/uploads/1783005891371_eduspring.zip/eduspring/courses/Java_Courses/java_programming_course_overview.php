<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
die("DB connection failed");
}


if(!isset($_SESSION['user_email'])){
    header("Location: ../../signin.php");
    exit();
}

$email = $_SESSION['user_email'];

$stmtUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$stmtUser->bind_param("s", $email);
$stmtUser->execute();
$resUser = $stmtUser->get_result();

$userData = $resUser->fetch_assoc();

if(!$userData){
    die("User not found");
}

$user_id = $userData['id'];

$course_id = 2; // Java course id

$stmt = $conn->prepare("
SELECT progress_percent FROM course_progress 
WHERE user_id=? AND course_id=?
LIMIT 1
");

if(!$stmt){
    die("Prepare failed: " . $conn->error);
}

// 🔥 CHECK QUIZ PASSED (ADD THIS)
$quizQuery = $conn->prepare("
SELECT passed FROM quiz_results 
WHERE user_id=? AND course_id=? 
ORDER BY id DESC LIMIT 1
");
$quizQuery->bind_param("ii", $user_id, $course_id);
$quizQuery->execute();
$resQuiz = $quizQuery->get_result();

if($quiz = $resQuiz->fetch_assoc()){
    $quizPassed = $quiz['passed'] == 1;
} else {
    $quizPassed = false;
}

$stmt->bind_param("ii", $user_id, $course_id);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    $progressPercent = min(100, $row['progress_percent']);
} else {
    $progressPercent = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Java Developer Masterclass - Learnify</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        body { font-family: 'Inter', sans-serif; }
        
        .text-java {
            background: linear-gradient(135deg, #f59e0b, #ea580c);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .bg-java {
            background: linear-gradient(135deg, #f59e0b, #ea580c);
        }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

    <!-- Header -->
    <?php include '../../navbar.php'; ?>

    <!-- Hero Section -->
    <section class="bg-slate-900 py-16 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-96 h-96 bg-orange-600/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="container mx-auto px-4 max-w-6xl relative z-10">
            <div class="flex flex-col md:flex-row gap-8 items-center">
                <div class="flex-1">
                    <div class="inline-block bg-orange-500/20 border border-orange-500/30 text-orange-400 font-bold px-3 py-1 rounded-full text-xs mb-4 tracking-wide uppercase">
                        Most Popular Path
                    </div>
                    <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
                        Java Developer <span class="text-java">Masterclass</span>
                    </h1>
                    <p class="text-lg text-slate-400 mb-8 leading-relaxed max-w-2xl">
                        Take your programming skills to the enterprise level. Master Core Java, advanced object-oriented programming, data structures, multithreading, and more to become a certified professional.
                    </p>
                    <div class="flex flex-wrap gap-6">
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-clock text-orange-500"></i> 95 Hours Total
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-signal text-orange-500"></i> Beginner to Advanced
                        </div>
                        <div class="flex items-center gap-2 text-slate-300 font-medium">
                            <i class="fas fa-globe text-orange-500"></i> 100% Online & Self-paced
                        </div>
                    </div>
                </div>
                <div class="w-32 h-32 md:w-48 md:h-48 bg-white/5 rounded-3xl flex items-center justify-center border border-white/10 shadow-2xl backdrop-blur-sm transform rotate-3 hover:rotate-0 transition-transform duration-500">
                    <i class="fab fa-java text-7xl md:text-9xl text-java drop-shadow-lg"></i>
                </div>
            </div>
        </div>
    </section>

    <main class="flex-1 container mx-auto px-4 py-12 max-w-6xl">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <!-- Course Info Left Column -->
            <div class="lg:col-span-2 space-y-12">
                <!-- About -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">About this Course</h2>
                    <p class="text-gray-600 leading-relaxed mb-4">
                        This comprehensive learning path is engineered to take you from a programming novice to a highly capable Java software engineer. You'll understand how Java works under the hood, how to write clean, scalable code, and how to utilize the Java Collections Framework and Streams effectively.
                    </p>
                    <p class="text-gray-600 leading-relaxed">
                        By the end of this course, you will be fully prepared to tackle the final assessment and earn your auto-generated digital certification, proving your expertise to potential employers.
                    </p>
                </section>

                <!-- What You'll Learn (Coverage) -->
                <section>
                    <h2 class="text-2xl font-bold text-gray-900 mb-6">Course Coverage</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Java Syntax & Fundamentals</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Object-Oriented Programming (OOP)</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Collections Framework & Generics</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Multithreading & Concurrency</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Lambda Expressions & Stream API</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">JDBC & Database Connectivity</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Exception Handling & File I/O</span>
                        </div>
                        <div class="flex items-start gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm">
                            <i class="fas fa-check-circle text-green-500 mt-1"></i>
                            <span class="text-gray-700 font-medium text-sm">Swing GUI & Design Patterns</span>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Sticky Action Card Right Column -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-gray-100 p-8 sticky top-24">
                    <h3 class="text-xl font-bold text-gray-900 mb-6">Your Progress</h3>
                    
                    <!-- Progress Bar -->
                    <div class="mb-8">
                        <div class="flex justify-between text-sm font-bold mb-2">
                            <span class="text-gray-600">Course Completion</span>
                            <span id="progressText" class="text-orange-600">0%</span>
                        </div>
                        <div class="w-full bg-orange-50 rounded-full h-3">
                            <div id="progressBar" class="bg-java h-3 rounded-full transition-all duration-1000 ease-out shadow-sm" style="width: 0%"></div>
                        </div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="space-y-4">
                        <!-- 1. Learning Material -->
                        <a id="btnCourse" href="/eduspring/courses/Java_Courses/java_final_page.php" class="flex items-center justify-center w-full py-3.5 px-4 bg-java text-white font-bold rounded-xl shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all duration-300">
                            <i class="fas fa-play-circle mr-2 text-lg"></i> Start Learning
                        </a>
                        
                        <!-- 2. Quiz -->
                        <a id="btnQuiz" href="/eduspring/courses/Java_Courses/java_quiz_page.php" 
class="flex items-center justify-center w-full py-3.5 px-4 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed transition-all duration-300 pointer-events-none">
                            <i class="fas fa-tasks mr-2 text-lg"></i> Take Certification Quiz
                            
                        </a>
                        
                        <!-- 3. Certificate -->
                        <a id="btnCert" href="/eduspring/courses/Java_Courses/Certificate_Java.php" class="flex items-center justify-center w-full py-3.5 px-4 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed transition-all duration-300 pointer-events-none">
                            <i class="fas fa-certificate mr-2 text-lg"></i> Download Certificate
                            
                        </a>
                    </div>
                    
                    <!-- Status Message -->
                    <div id="statusMessage" class="mt-6 text-sm text-center text-gray-500 bg-gray-50 p-3 rounded-lg border border-gray-100 font-medium">
                        Complete the course material (100%) to unlock the certification quiz.
                    </div>
                </div>
            </div>

        </div>
    </main>

    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-8 mt-auto text-center">
        <div class="container mx-auto px-4">
            <p class="text-sm">© 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>

    <script>

document.addEventListener('DOMContentLoaded', () => {

    let progressPercent = Math.min(100, <?php echo $progressPercent; ?>);

    document.getElementById('progressBar').style.width = Math.min(progressPercent, 100) + '%';
    document.getElementById('progressText').textContent = progressPercent + '%';

    const btnCourse = document.getElementById('btnCourse');
    const btnQuiz = document.getElementById('btnQuiz');
    const btnCert = document.getElementById('btnCert');
    const statusMessage = document.getElementById('statusMessage');

    let quizPassed = <?php echo $quizPassed ? 'true' : 'false'; ?>;

    if (progressPercent > 0 && progressPercent < 100) {
        btnCourse.innerHTML = 'Continue Learning';
    } 
    else if (progressPercent >= 100) {

        btnCourse.innerHTML = 'Review Course Material';

        btnQuiz.href = "/eduspring/courses/Java_Courses/java_quiz_page.php";

        btnQuiz.classList.remove('bg-gray-100','text-gray-400','cursor-not-allowed','pointer-events-none');
        btnQuiz.classList.add('bg-java','text-white');

        statusMessage.innerHTML = "Course completed! You may now take the exam.";

if (quizPassed) {

    // ✅ ENABLE
    btnCert.classList.remove('bg-gray-100','text-gray-400','pointer-events-none');
    btnCert.classList.add('bg-java','text-white');
    btnCert.style.cursor = "pointer";

    btnCert.onclick = () => {
        window.location.href = "/eduspring/courses/Java_Courses/certificate_java.php";
    };

} else {

    // ❌ DISABLE (IMPORTANT 🔥)
    btnCert.classList.remove('bg-java','text-white');
    btnCert.classList.add('bg-gray-100','text-gray-400','pointer-events-none');
    btnCert.style.cursor = "not-allowed";

}
    }
});
    </script>
</body>
</html>