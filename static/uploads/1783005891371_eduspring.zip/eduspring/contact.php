<?php
session_start();

// OPTIONAL: DB connection (venumna use pannalam)
$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB failed");
}

$success = false;

if($_SERVER["REQUEST_METHOD"] == "POST"){

$fname = $_POST['firstName'];
$lname = $_POST['lastName'];
$email = $_POST['email'];
$message = $_POST['message'];

// OPTIONAL: DB save
$sql = "INSERT INTO contact_messages (first_name,last_name,email,message)
VALUES (?,?,?,?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss",$fname,$lname,$email,$message);
$stmt->execute();

$success = true;

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Learnify - Contact Us</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
/* ===============================
1. FORM CARD LIFT
================================= */
.bg-white.rounded-3xl {
    transition: 0.4s ease;
}

.bg-white.rounded-3xl:hover {
    transform: translateY(-10px) scale(1.01);
    box-shadow: 0 25px 60px rgba(0,0,0,0.15);
}

/* ===============================
2. BUTTON SHINE
================================= */
.btn-vibrant {
    position: relative;
    overflow: hidden;
}

.btn-vibrant::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(120deg, transparent, rgba(255,255,255,0.6), transparent);
    transition: 0.5s;
}

.btn-vibrant:hover::before {
    left: 100%;
}

.btn-vibrant:hover {
    transform: scale(1.05);
    box-shadow: 0 15px 35px rgba(34,193,195,0.5);
}

/* ===============================
3. ICON HOVER
================================= */
i {
    transition: 0.3s ease;
}

i:hover {
    transform: scale(1.2) rotate(5deg);
}

/* ===============================
4. INPUT FOCUS GLOW
================================= */
.input-field {
    transition: 0.3s ease;
}

.input-field:focus {
    transform: scale(1.03);
    border-color: #22c1c3;
    box-shadow: 0 0 15px rgba(34,193,195,0.4);
}

/* ===============================
5. POPUP MODAL
================================= */
.popup-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

.popup-box {
    background: white;
    padding: 30px;
    border-radius: 20px;
    text-align: center;
    width: 300px;
    animation: popupShow 0.4s ease;
}

.popup-box h3 {
    margin-bottom: 10px;
    color: #0f172a;
}

.popup-box p {
    color: #64748b;
    font-size: 14px;
}

.popup-box button {
    margin-top: 15px;
    padding: 8px 18px;
    border: none;
    border-radius: 20px;
    background: #22c1c3;
    color: white;
    cursor: pointer;
}

@keyframes popupShow {
    from {
        opacity: 0;
        transform: scale(0.7);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
}

        body { 
            font-family: 'Inter', sans-serif; 
            background-color: #f8fafc; 
            display: flex; 
            flex-direction: column; 
            min-height: 100vh; 
        }
        
        .text-vibrant {
            background: linear-gradient(135deg, #22c1c3 0%, #134e5e 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .btn-vibrant {
            background: linear-gradient(135deg, #22c1c3 0%, #134e5e 100%);
            transition: all 0.3s ease;
        }
        
        .btn-vibrant:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(34, 193, 195, 0.3);
        }
        
        .input-field {
            width: 100%;
            padding: 0.875rem 1.25rem;
            border: 2px solid #e2e8f0;
            border-radius: 0.75rem;
            background-color: #f8fafc;
            transition: all 0.3s ease;
            outline: none;
            box-sizing: border-box;
        }
        
        .input-field:focus {
            border-color: #22c1c3;
            background-color: #ffffff;
            box-shadow: 0 0 0 4px rgba(34, 193, 195, 0.1);
        }

        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* ===============================
HERO ANIMATED GRADIENT
================================= */
.hero-section {
    background: linear-gradient(-45deg, #0f172a, #134e5e, #22c1c3, #1e293b);
    background-size: 400% 400%;
    animation: gradientMove 10s ease infinite;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* ===============================
HEADING TYPING + GLOW
================================= */
.contact-heading {
    font-size: clamp(32px, 6vw, 48px);
    font-weight: 800;
    color: white;
    text-align: center;
    overflow: hidden;
    white-space: nowrap;
    width: 0;
    margin: 0 auto;

    border-right: 3px solid rgba(255,255,255,0.8);

    animation:
        typingCenter 2.5s steps(20, end) forwards,
        cursorBlink 0.8s infinite,
        glowText 2s ease-in-out infinite alternate;
}

/* typing */
@keyframes typingCenter {
    from { width: 0; }
    to { width: 16ch; } /* adjust if needed */
}

/* cursor blink */
@keyframes cursorBlink {
    50% { border-color: transparent; }
}

/* glow */
@keyframes glowText {
    from {
        text-shadow: 0 0 10px #22c1c3;
    }
    to {
        text-shadow: 0 0 25px #22c1c3, 0 0 40px #22c1c3;
    }
}

/* cursor remove after typing */
.contact-heading {
    animation-fill-mode: forwards;
}

.contact-heading.finished {
    border-right: none;
}

    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

<?php include 'navbar.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section relative py-24 overflow-hidden">
        <div class="absolute top-0 right-1/4 w-96 h-96 bg-[#22c1c3]/20 rounded-full mix-blend-screen filter blur-3xl opacity-50"></div>
        <div class="container mx-auto px-4 relative z-10 text-center">
<h1 class="contact-heading">
    Get in Touch</span>
</h1>
            <p class="text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
                Have questions about our courses, certification process, or enterprise plans? We're here to help you navigate your learning journey.
            </p>
        </div>
    </section>

    <!-- Main Content -->
    <main class="flex-1 container mx-auto px-4 py-16 max-w-6xl relative z-20 -mt-10">
        <div class="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-gray-100 overflow-hidden">
            <div class="grid grid-cols-1 lg:grid-cols-5">
                
                <!-- Contact Info Left Column -->
                <div class="lg:col-span-2 bg-slate-900 text-white p-10 md:p-12 relative overflow-hidden">
                    <div class="absolute -bottom-24 -right-24 w-64 h-64 bg-[#22c1c3]/20 rounded-full blur-3xl"></div>
                    <div class="absolute -top-10 -left-10 w-40 h-40 bg-[#134e5e]/40 rounded-full blur-2xl"></div>
                    
                    <div class="relative z-10 h-full flex flex-col">
                        <h3 class="text-2xl font-bold mb-2"><span class="text-vibrant">Contact Information</span></h3>
                        <p class="text-slate-400 mb-10 text-sm leading-relaxed">Fill out the form and our team will get back to you within 24 hours.</p>
                        
                        <div class="space-y-8 flex-1">
                            <div class="flex items-start gap-5">
                                <div class="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                                    <i class="fas fa-phone-alt text-[#22c1c3]"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-sm text-slate-300 uppercase tracking-wider mb-1">Phone</h4>
                                    <p class="font-medium">+91 9360951730</p>
                                    <p class="text-slate-400 text-sm">Mon-Fri from 8am to 5pm</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start gap-5">
                                <div class="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                                    <i class="fas fa-envelope text-[#22c1c3]"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-sm text-slate-300 uppercase tracking-wider mb-1">Email</h4>
                                    <p class="font-medium">support@learnify.com</p>
                                    <p class="text-slate-400 text-sm">Online support 24/7</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start gap-5">
                                <div class="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center shrink-0">
                                    <i class="fas fa-map-marker-alt text-[#22c1c3]"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-sm text-slate-300 uppercase tracking-wider mb-1">Office</h4>
                                    <p class="font-medium">west salem</p>
                                    <p class="text-slate-400 text-sm">Distributed Infrastructure</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Form Right Column -->
                <div class="lg:col-span-3 p-10 md:p-12 bg-white">
                    <form method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="firstName" class="block text-sm font-bold text-slate-700 mb-2">First Name</label>
                                <input type="text" name="firstName" id="firstName" class="input-field" required>
                            </div>
                            <div>
                                <label for="lastName" class="block text-sm font-bold text-slate-700 mb-2">Last Name</label>
                                <input type="text" name="lastName" id="lastName" class="input-field" required>
                            </div>
                        </div>
                        
                        <div>
                            <label for="email" class="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
                            <input type="email" name="email" id="email" class="input-field" required>
                        </div>
                        
                        <div>
                            <label for="message" class="block text-sm font-bold text-slate-700 mb-2">Message</label>
                            <textarea name="message" id="message" rows="5" class="input-field resize-none" required></textarea>
                        </div>
                        
                        <button type="submit" id="submitBtn" class="w-full btn-vibrant text-white font-bold py-4 px-8 rounded-xl shadow-lg flex items-center justify-center gap-2">
                            <span>Send Message</span>
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                    
                    <!-- Success Message (Hidden by default) -->
<?php if($success){ ?>
<script>
window.onload = function(){
    showPopup();
};
</script>
<?php } ?>
                </div>
            </div>
        </div>
    </main>

    <!-- POPUP -->
<div id="successPopup" class="popup-overlay">
    <div class="popup-box">
        <h3>🎉 Message Sent!</h3>
        <p>Your message was successfully submitted.</p>
        <button onclick="closePopup()">OK</button>
    </div>
</div>
    <!-- Footer -->
    <footer class="bg-slate-900 border-t border-slate-800 text-slate-400 py-12 mt-auto">
        <div class="container mx-auto px-4 text-center">
            <p class="text-sm text-slate-500">© 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>

<script>
function showPopup(){
    document.getElementById("successPopup").style.display = "flex";
}

function closePopup(){
    document.getElementById("successPopup").style.display = "none";
}

setTimeout(() => {
    document.querySelector('.contact-heading').style.borderRight = "none";
}, 2600);
</script>

</body>
</html>