<?php
session_start();

if(!isset($_SESSION['user_email'])){
    header("Location: signin.php");
    exit();
}

include 'db.php';

// Fetch user data
$email = $_SESSION['user_email'];
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile Settings</title>

<script src="https://cdn.tailwindcss.com"></script>

<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f1f5f9;
}

.content {
    max-width: 1000px;
    margin: 0 auto;
    padding: 40px;
}

.id-card-preview {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    color: white;
    padding: 30px;
    border-radius: 20px;
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 30px;
}

.avatar-upload {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    background: #22c1c3;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 35px;
    cursor: pointer;
    overflow: hidden;
}

.settings-grid {
    background: #ffffff;
    padding: 35px;
    border-radius: 24px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.05);
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

/* INPUT GROUP FIX (🔥 MAIN FIX) */
.input-group {
    display: flex;
    flex-direction: column;
    gap: 8px;   /* spacing between label & input */
}

/* FULL WIDTH FIELD */
.full-width {
    grid-column: span 2;
}

input {
    width: 100%;
    height: 48px;

    padding: 14px;              /* normal padding */
    text-indent: 10px;           /* 🔥 THIS IS THE REAL FIX */

    border-radius: 14px;
    border: 2px solid #e2e8f0;
    background: #f8fafc;

    font-size: 15px;
    box-sizing: border-box;
}

input::placeholder {
    color: #94a3b8;
}

.save-btn {
    grid-column: span 2;
    background: #22c1c3;
    color: white;
    padding: 16px;
    border-radius: 50px;
    font-weight: bold;
    transition: 0.3s;
}

.save-btn:hover {
    background: #0f172a;
}

.id-card-preview {
    background: linear-gradient(135deg, #0f172a, #1e293b);
    color: white;
    padding: 30px;
    border-radius: 24px;
    display: flex;
    align-items: center;
    gap: 25px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

/* watermark effect */
.id-card-preview::before {
    content: 'EDUSPRING VERIFIED';
    position: absolute;
    right: -20px;
    top: 20px;
    font-size: 40px;
    font-weight: bold;
    opacity: 0.05;
    transform: rotate(-15deg);
}

.profile-info h2 {
    margin: 0;
    font-size: 22px;
}

.verified-text {
    color: #22c1c3;
    margin: 5px 0;
    font-size: 14px;
    font-weight: 500;
}

.last-active {
    font-size: 13px;
    opacity: 0.7;
}
/* LABEL STYLE (🔥 BOLD + CLEAN) */
label {
    font-size: 14px;
    font-weight: 700;
    color: #475569;
}

/* INPUT STYLE (🔥 EXACT MATCH) */
input {
    padding: 14px;
    border-radius: 14px;
    border: 2px solid #e2e8f0;
    background: #f8fafc;
    font-size: 15px;
    transition: 0.3s;
}

/* focus effect (click pannumbothu blue glow) */
/* FOCUS EFFECT (🔥 BLUE GLOW) */
input:focus {
    border-color: #22c1c3;
    background: white;
    outline: none;
    box-shadow: 0 0 0 3px rgba(34, 193, 195, 0.2);
}

.settings-grid {
    background: #ffffff;
    padding: 35px;
    border-radius: 24px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.05);
}
.password-wrapper{
position:relative;
width:100%;
}

.password-tooltip{
position:absolute;
left:0;
top:55px;
width:220px;
background:#fff;
border-radius:10px;
padding:12px;
box-shadow:0 5px 15px rgba(0,0,0,0.2);
font-size:13px;
display:none;
z-index:10;
}

.password-tooltip p{
margin:4px 0;
transition:0.3s;
}

.password-wrapper:focus-within .password-tooltip{
display:block;
}

#toast{
transition: all 0.4s ease;
animation: slideDown 0.4s ease;
}

@keyframes slideDown{
from{
opacity:0;
transform:translate(-50%, -20px);
}
to{
opacity:1;
transform:translate(-50%, 0);
}
}
</style>
</head>

<body>

<?php include 'navbar.php'; ?>

<div class="content">

<h1 class="text-2xl font-bold mb-2">Profile Settings</h1>
<p class="text-gray-500 mb-6">Update your personal info and cloud preferences.</p>

<form action="update_profile.php" method="POST" enctype="multipart/form-data">

<input type="hidden" name="id" value="<?php echo $user['id']; ?>">

<!-- PROFILE CARD -->
<div class="id-card-preview">

<label class="avatar-upload">

<img id="profilePreview" 
     src="<?php echo $user['profile_pic'] ? 'uploads/'.$user['profile_pic'] : 'https://via.placeholder.com/90'; ?>" 
     class="w-full h-full object-cover">

<input type="file" name="profile_pic" id="profilePicInput" hidden>

</label>

<div class="profile-info">
    <h2 id="previewName"><?php echo $user['fname'] . " " . $user['lname']; ?></h2>

    <!-- VERIFIED TEXT -->
    <p class="verified-text">
        Verified Student • Sona College Cluster
    </p>

    <!-- LAST ACTIVE -->
    <p class="last-active">
        Last active: Today, <?php echo date("h:i A"); ?>
    </p>
</div>

</div>

<!-- FORM -->
<div class="settings-grid">

<div class="input-group">
<label>First Name</label>
<input type="text" name="fname" id="fname" value="<?php echo $user['fname']; ?>">
</div>

<div class="input-group">
<label>Last Name</label>
<input type="text" name="lname" value="<?php echo $user['lname']; ?>">
</div>

<div class="input-group">
<label>Email</label>
<input type="email" name="email" id="email"
value="<?php echo $user['email']; ?>"
onkeyup="checkAvailability('email')">
<span id="emailMsg"></span>
</div>

<div class="input-group">
<label>Phone</label>
<input type="text" name="phone" id="phone"
value="<?php echo $user['phone']; ?>"
onkeyup="checkAvailability('phone')">
<span id="phoneMsg"></span>
</div>

<div class="input-group full-width">
<label>Bio</label>
<input type="text" name="bio" value="<?php echo $user['bio']; ?>">
</div>

<!-- USERNAME -->
<div class="input-group">
<label>Username</label>
<input type="text" name="username" id="username" value="<?php echo $user['username']; ?>" onkeyup="checkAvailability('username')">
<span id="usernameMsg"></span>
</div>

<!-- DATE OF BIRTH -->
<div class="input-group">
<label>Date of Birth</label>
<input type="date" name="dob" value="<?php echo $user['dob']; ?>">
</div>

<!-- ADDRESS -->
<div class="input-group full-width">
<label>Address</label>
<input type="text" name="address" value="<?php echo $user['address']; ?>">
</div>

<!-- PASSWORD -->
<div class="input-group">
<label>Old Password</label>
<div class="password-wrapper">

    <div style="position:relative;">
        <input type="password" name="old_password" id="old_password" placeholder="Enter Old Password">
        <span onclick="toggleOldPassword()" style="position:absolute;right:12px;top:12px;cursor:pointer;">👁</span>
    </div>

</div>
</div>

<div class="input-group">
<label>New Password</label>
<div class="password-wrapper">

    <div style="position:relative;">
        <input type="password" name="password" id="new_password" placeholder="Enter New Password" onkeyup="checkPassword()">
        <span onclick="toggleNewPassword()" style="position:absolute;right:12px;top:12px;cursor:pointer;">👁</span>
    </div>

    <div class="password-tooltip">
        <b>Password must contain</b>

        <p id="upper">❌ 1 Uppercase letter</p>
        <p id="lower">❌ 1 Lowercase letter</p>
        <p id="number">❌ 1 Number</p>
        <p id="special">❌ 1 Special character</p>
        <p id="length">❌ Minimum 8 characters</p>

        <div style="height:8px;background:#eee;border-radius:10px;margin-top:8px;">
            <div id="strengthBar"
                style="height:8px;width:0%;background:red;border-radius:10px;transition:0.3s;">
            </div>
        </div>
    </div>

</div>
</div>

<div class="input-group">
<label>Confirm Password</label>
<div style="position:relative;">

<input type="password"
name="confirm_password" placeholder="Enter New Password Again To Change"
id="confirm_password"
onkeyup="checkMatch()">

<span onclick="toggleConfirmPassword()"
style="position:absolute;right:12px;top:12px;cursor:pointer;">👁</span>

</div>

<p id="matchMsg"></p>
</div>

<button type="submit" class="save-btn">Update Profile</button>

</div>

</form>

</div>

<div id="toast"
style="position:fixed;
top:20px;
left:50%;
transform:translateX(-50%);
padding:14px 20px;
border-radius:10px;
color:white;
font-weight:bold;
display:none;
z-index:999;">
</div>

<script>
// live name update
const fnameInput = document.getElementById('fname');
const previewName = document.getElementById('previewName');

fnameInput.addEventListener('input', () => {
    previewName.textContent = fnameInput.value;
});

function checkAvailability(type){

let value = document.getElementById(type).value;
let currentEmail = "<?php echo $_SESSION['user_email']; ?>";

fetch("check_user.php?type="+type+"&value="+value+"&current="+currentEmail)
.then(response=>response.text())
.then(data=>{

let msgBox = document.getElementById(type+"Msg");

if(data=="exists"){
msgBox.innerHTML = "❌ Already taken";
msgBox.style.color="red";
}else{
msgBox.innerHTML = "✅ Available";
msgBox.style.color="green";
}

});

}

const fileInput = document.getElementById("profilePicInput");
const preview = document.getElementById("profilePreview");

fileInput.addEventListener("change", function(){
    const file = this.files[0];

    if(file){
        const reader = new FileReader();

        reader.onload = function(e){
            preview.src = e.target.result;
        }

        reader.readAsDataURL(file);
    }
});

function toggleOldPassword(){
let pwd=document.getElementById("old_password");
pwd.type = (pwd.type==="password") ? "text" : "password";
}

function toggleNewPassword(){
let pwd=document.getElementById("new_password");
pwd.type = (pwd.type==="password") ? "text" : "password";
}

function toggleConfirmPassword(){
let pwd=document.getElementById("confirm_password");
pwd.type = (pwd.type==="password") ? "text" : "password";
}

function checkPassword(){

let pwd=document.getElementById("new_password").value;

let upper=/[A-Z]/.test(pwd);
let lower=/[a-z]/.test(pwd);
let number=/[0-9]/.test(pwd);
let special=/[\W_]/.test(pwd);
let length=pwd.length>=8;

document.getElementById("upper").innerHTML =
upper ? "✅ 1 Uppercase letter" : "❌ 1 Uppercase letter";

document.getElementById("lower").innerHTML =
lower ? "✅ 1 Lowercase letter" : "❌ 1 Lowercase letter";

document.getElementById("number").innerHTML =
number ? "✅ 1 Number" : "❌ 1 Number";

document.getElementById("special").innerHTML =
special ? "✅ 1 Special character" : "❌ 1 Special character";

document.getElementById("length").innerHTML =
length ? "✅ Minimum 8 characters" : "❌ Minimum 8 characters";

let strength=0;
if(upper) strength++;
if(lower) strength++;
if(number) strength++;
if(special) strength++;
if(length) strength++;

let bar=document.getElementById("strengthBar");

if(strength<=2){
bar.style.width="30%";
bar.style.background="red";
}
else if(strength<=4){
bar.style.width="65%";
bar.style.background="orange";
}
else{
bar.style.width="100%";
bar.style.background="green";
}

}

function checkMatch(){

let pwd=document.getElementById("new_password").value;
let confirm=document.getElementById("confirm_password").value;
let msg=document.getElementById("matchMsg");

if(confirm.length===0){
msg.innerHTML="";
return;
}

if(pwd===confirm){
msg.innerHTML="✅ Passwords match";
msg.style.color="green";
}else{
msg.innerHTML="❌ Passwords do not match";
msg.style.color="red";
}

}

// 🔥 TOAST LOGIC
const urlParams = new URLSearchParams(window.location.search);
const status = urlParams.get("status");

const toast = document.getElementById("toast");

if(status){

toast.style.display = "block";

if(status === "success"){
    toast.innerHTML = "✅ Profile Updated Successfully";
    toast.style.background = "green";
}
else if(status === "error"){
    toast.innerHTML = "❌ Update Failed";
    toast.style.background = "red";
}
else if(status === "duplicate"){
    toast.innerHTML = "❌ Username / Email / Phone already taken";
    toast.style.background = "red";
}

// auto hide
setTimeout(()=>{
    toast.style.display = "none";
},3000);

}
</script>

</body>
</html>