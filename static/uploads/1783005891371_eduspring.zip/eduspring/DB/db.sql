/*to delete all data*/
/*SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE certificates;
TRUNCATE TABLE quiz_answers;
TRUNCATE TABLE quiz_results;
TRUNCATE TABLE topic_progress;
TRUNCATE TABLE course_progress;
TRUNCATE TABLE enrollments;
TRUNCATE TABLE courses;
TRUNCATE TABLE contact_messages;
TRUNCATE TABLE users;

SET FOREIGN_KEY_CHECKS = 1;*/

CREATE DATABASE eduspring_db;

USE eduspring_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(100),
    lname VARCHAR(100),
    dob DATE,
    phone VARCHAR(15),
    address TEXT,
    username VARCHAR(100) UNIQUE,
    email VARCHAR(150) UNIQUE,
    password VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(150),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE users ADD role VARCHAR(20) DEFAULT 'user';

ALTER TABLE users ADD profile_pic VARCHAR(255) DEFAULT NULL;

ALTER TABLE users ADD bio TEXT;

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(150),
    description TEXT,
    instructor VARCHAR(150),
    duration VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO courses (course_name, description, instructor, duration) VALUES

('Python Programming',
 'Build scalable backend systems, automate tasks, and analyze data. Master Python, Django, Flask, and APIs.',
 'EduSpring Team',
 '110 Hours'),

('Java Programming',
 'Master enterprise application development. Dive deep into Core Java, Spring Boot, microservices, and database integration.',
 'EduSpring Team',
 '95 Hours'),

('Full-Stack Development',
 'Master frontend interfaces and backend APIs. Learn React, Node.js, and modern database management systems.',
 'EduSpring Team',
 '120 Hours');

select * from courses;

ALTER TABLE courses ADD slug VARCHAR(50);

UPDATE courses SET slug='python' WHERE id=1;
UPDATE courses SET slug='java' WHERE id=2;
UPDATE courses SET slug='fullstack' WHERE id=3;

CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE course_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    completed_topics INT DEFAULT 0,
    total_topics INT,
    progress_percent INT DEFAULT 0,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);


CREATE TABLE topic_progress (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    topic_name VARCHAR(100)
);

CREATE TABLE quiz_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    score INT,
    total INT,
    percentage INT,
    passed BOOLEAN,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE quiz_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    question_id INT,
    answer TEXT
);

CREATE TABLE certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    issued_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    certificate_url VARCHAR(255),
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

SET SQL_SAFE_UPDATES = 0;

UPDATE course_progress
SET completed_topics = total_topics
WHERE completed_topics > total_topics;

ALTER TABLE course_progress
ADD CONSTRAINT chk_progress 
CHECK (completed_topics <= total_topics);

ALTER TABLE enrollments 
ADD UNIQUE KEY unique_enrollment (user_id, course_id);

SET SQL_SAFE_UPDATES = 0;

SELECT user_id, course_id, question_id, COUNT(*) 
FROM quiz_answers 
GROUP BY user_id, course_id, question_id 
HAVING COUNT(*) > 1;

DELETE FROM quiz_answers
WHERE id NOT IN (
    SELECT * FROM (
        SELECT MIN(id)
        FROM quiz_answers
        GROUP BY user_id, course_id, question_id
    ) AS temp
);

ALTER TABLE quiz_answers 
ADD UNIQUE KEY unique_answer (user_id, course_id, question_id);

SET SQL_SAFE_UPDATES = 1;