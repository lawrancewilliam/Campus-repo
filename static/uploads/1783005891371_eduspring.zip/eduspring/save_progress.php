<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

if ($conn->connect_error) {
    die("DB Error: " . $conn->connect_error);
}

// ✅ Login check
if(!isset($_SESSION['user_email'])){
    echo "not_logged_in";
    exit();
}

// ✅ Validate POST
if(!isset($_POST['course_id']) || !isset($_POST['topic_name'])){
    echo "invalid_request";
    exit();
}

$email = $_SESSION['user_email'];

// 🔥 GET USER ID FROM EMAIL
$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$resUser = $getUser->get_result();

$userData = $resUser->fetch_assoc();

if(!$userData){
    echo "user_not_found";
    exit();
}

$user_id = $userData['id'];

$course_id = intval($_POST['course_id']);
$topic_name = trim($_POST['topic_name']);

if($course_id <= 0 || $topic_name == ""){
    echo "invalid_data";
    exit();
}

// ✅ STEP 1: check topic already completed
$check = $conn->prepare("
SELECT id FROM topic_progress 
WHERE user_id=? AND course_id=? AND topic_name=?
");
$check->bind_param("iis", $user_id, $course_id, $topic_name);
$check->execute();
$res = $check->get_result();

if($res->num_rows > 0){
    echo "already_completed";
    exit();
}

// ✅ STEP 2: insert topic
$insert = $conn->prepare("
INSERT INTO topic_progress (user_id, course_id, topic_name) 
VALUES (?, ?, ?)
");
$insert->bind_param("iis", $user_id, $course_id, $topic_name);

if(!$insert->execute()){
    echo "insert_failed";
    exit();
}

// ✅ STEP 3: count completed topics
$count = $conn->prepare("
SELECT COUNT(*) as total FROM topic_progress 
WHERE user_id=? AND course_id=?
");
$count->bind_param("ii", $user_id, $course_id);
$count->execute();
$row = $count->get_result()->fetch_assoc();

$completed = (int)$row['total'];

// ✅ STEP 4: get total topics
$totalQ = $conn->prepare("
SELECT total_topics FROM course_progress 
WHERE user_id=? AND course_id=?
");
$totalQ->bind_param("ii", $user_id, $course_id);
$totalQ->execute();
$row2 = $totalQ->get_result()->fetch_assoc();

$total = isset($row2['total_topics']) ? (int)$row2['total_topics'] : 0;

// ✅ STEP 5: calculate percentage
$percent = 0;
if($total > 0){
    $percent = round(($completed / $total) * 100);
}

// ✅ STEP 6: update progress
$update = $conn->prepare("
UPDATE course_progress 
SET completed_topics=?, progress_percent=? 
WHERE user_id=? AND course_id=?
");
$update->bind_param("iiii", $completed, $percent, $user_id, $course_id);

if(!$update->execute()){
    echo "update_failed";
    exit();
}

// ✅ SUCCESS
echo "updated";
?>