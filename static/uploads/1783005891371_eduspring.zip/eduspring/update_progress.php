<?php
session_start();

$conn = new mysqli("127.0.0.1","root","","eduspring_db",3306);

$email = $_SESSION['user_email'];

// get user id
$stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$user_id = $user['id'];

$topic = $_POST['topic'];

// check already completed
$check = $conn->prepare("
SELECT * FROM topic_progress 
WHERE user_id=? AND course_id=1 AND topic_name=?
");
$check->bind_param("is", $user_id, $topic);
$check->execute();
$r = $check->get_result();

if($r->num_rows == 0){

    // insert topic
    $insert = $conn->prepare("
    INSERT INTO topic_progress (user_id, course_id, topic_name)
    VALUES (?,1,?)
    ");
    $insert->bind_param("is", $user_id, $topic);
    $insert->execute();

    // increase completed topics
    $conn->query("
    UPDATE course_progress 
    SET completed_topics = completed_topics + 1 
    WHERE user_id=$user_id AND course_id=1
    ");

    // update percentage
    $conn->query("
    UPDATE course_progress 
    SET progress_percent = ROUND((completed_topics / total_topics) * 100)
    WHERE user_id=$user_id AND course_id=1
    ");
}
?>