<?php
session_start();
include("db.php");

// LOGIN CHECK (FIXED)
if(!isset($_SESSION['user_email'])){
    echo "Unauthorized";
    exit();
}

$email = $_SESSION['user_email'];

// GET USER ID
$getUser = $conn->prepare("SELECT id FROM users WHERE email=?");
$getUser->bind_param("s", $email);
$getUser->execute();
$resUser = $getUser->get_result();
$user = $resUser->fetch_assoc();

if(!$user){
    echo "User not found";
    exit();
}

$user_id = $user['id'];

// GET JSON DATA
$data = json_decode(file_get_contents("php://input"), true);

if(!$data){
    echo "Invalid JSON data";
    exit();
}

// GET COURSE SLUG
$slug = $data['course_slug'] ?? '';

if(empty($slug)){
    echo "Course not provided";
    exit();
}

// GET COURSE ID
$stmt = $conn->prepare("SELECT id FROM courses WHERE slug=?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$res = $stmt->get_result();
$course = $res->fetch_assoc();

if(!$course){
    echo "Course not found";
    exit();
}

$course_id = $course['id'];

// GET VALUES
$answers = $data['answers'];
$score = $data['score'];
$total = $data['total'];
$percentage = $data['percentage'];

// VALIDATION
if(!is_array($answers) || empty($answers)){
    echo "No answers received";
    exit();
}

// PREVENT REATTEMPT IF PASSED
$check = $conn->prepare("
SELECT id FROM quiz_results 
WHERE user_id=? AND course_id=? AND passed=1
");
$check->bind_param("ii", $user_id, $course_id);
$check->execute();
$res = $check->get_result();

if($res->num_rows > 0){
    echo "already_passed";
    exit();
}

// PASS LOGIC
$passed = ($percentage >= 70) ? 1 : 0;

// INSERT RESULT
$stmt = $conn->prepare("
INSERT INTO quiz_results(user_id, course_id, score, total, percentage, passed) 
VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->bind_param("iiiiii", $user_id, $course_id, $score, $total, $percentage, $passed);

if(!$stmt->execute()){
    echo "Insert failed";
    exit();
}

// CERTIFICATE GENERATION
if($passed == 1){

    $checkCert = $conn->prepare("
    SELECT id FROM certificates WHERE user_id=? AND course_id=?
    ");
    $checkCert->bind_param("ii", $user_id, $course_id);
    $checkCert->execute();
    $resCert = $checkCert->get_result();

    if($resCert->num_rows == 0){

        $cert_url = "certificate_" . $slug . ".php";

        $stmtCert = $conn->prepare("
        INSERT INTO certificates(user_id, course_id, certificate_url) 
        VALUES (?, ?, ?)
        ");
        $stmtCert->bind_param("iis", $user_id, $course_id, $cert_url);
        $stmtCert->execute();
    }
}

// SAVE ANSWERS (NO DUPLICATE)
foreach($answers as $question_id => $answer){

    $answer_str = is_array($answer) ? json_encode($answer) : (string)$answer;

    $stmt2 = $conn->prepare("
    REPLACE INTO quiz_answers(user_id, course_id, question_id, answer) 
    VALUES (?, ?, ?, ?)
    ");

    if($stmt2){
        $stmt2->bind_param("iiis", $user_id, $course_id, $question_id, $answer_str);
        $stmt2->execute();
    }
}

echo "success";
?>